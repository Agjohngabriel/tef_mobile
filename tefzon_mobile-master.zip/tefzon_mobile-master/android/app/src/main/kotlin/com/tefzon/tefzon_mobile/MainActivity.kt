package com.tefzon.tefzon_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
