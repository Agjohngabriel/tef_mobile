import 'package:flutter/material.dart';

import '../../helpers/constants/colors.dart';

class CustomButton extends StatelessWidget {
  const CustomButton(
      {Key? key,
      this.icon,
      required this.text,
      required this.onTap,
      this.color,
      this.isPrimary = true,
      this.isFilled = false,
      // this.hasBorder = true,
      this.customIcon,
      this.useCustomIcon = false})
      : super(key: key);

  final IconData? icon;
  final String text;
  final Function() onTap;
  final Color? color;
  final bool isPrimary;
  final bool isFilled;
  // final bool hasBorder;
  final Widget? customIcon;
  final bool useCustomIcon;

  @override
  Widget build(BuildContext context) {
    final useColor =
        color ?? (isPrimary ? AppColors.primary: AppColors.secondary);
    return MaterialButton(
      onPressed: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          useCustomIcon
              ? customIcon!
              : icon != null
                  ? Icon(icon,
                      color: isFilled ? AppColors.white : useColor, size: 24)
                  : const SizedBox(),
          if (icon != null || customIcon != null)
            const SizedBox(
              width: 10,
            ),
          Text(
            text,
            style: TextStyle(
              color: isFilled ? AppColors.white : useColor,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
        ],
      ),
      shape: RoundedRectangleBorder(
          borderRadius: const BorderRadius.all(
            Radius.circular(10),
          ),
          // TODO: remove has border check
          side:
              // hasBorder?
              BorderSide(width: 1, color: useColor)
          // : BorderSide.none
          ),
      minWidth: double.infinity,
      height: 50,
      color: isFilled ? useColor : null,
      elevation: 0,
    );
  }
}
