import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/model/fixture/livematch2.dart';
import 'package:tefzon_mobile/model/fixture/new_fixture.dart';

class FixtureGameWidget extends StatelessWidget {
  final NewFixture model;
  final int index;
  final List<NewFixture> fixList;
  const FixtureGameWidget(
      {Key? key,
      required this.model,
      required this.index,
      required this.fixList})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<NewFixture> reversedList = fixList.reversed.toList();

    Widget getDateDivider(String date) {
      if (index == 0) {
        return DateDivider(date: reversedList[index].date_time!);
      } else if (index > -1 &&
          reversedList[index - 1].date_time == reversedList[index].date_time) {
        return Container();
      } else {
        return DateDivider(date: reversedList[index].date_time!);
      }
    }

    return Column(
      children: [
        getDateDivider(model.date_time!),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            SizedBox(width: 100, child: Center(child: Text(model.localTeam!))),
            Row(
              children: [
                Image(image: NetworkImage(model.localTeamLogo!, scale: 4)),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      border: Border.all(width: 2, color: AppColors.grey)),
                  child: Text(DateFormat('hh:mm').format(
                    DateTime.parse(model.date_time!),
                  )),
                ),
                const SizedBox(
                  width: 10,
                ),
                Image(image: NetworkImage(model.visitorTeamLogo!, scale: 4)),
              ],
            ),
            SizedBox(
                width: 100, child: Center(child: Text(model.visitorTeam!))),
          ],
        ),
      ],
    );
  }
}

class DateDivider extends StatelessWidget {
  final String date;
  const DateDivider({
    super.key,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.symmetric(vertical: 7),
        margin: const EdgeInsets.only(bottom: 5),
        color: AppColors.grey,
        child: Center(
          child: Text(DateFormat('EEEE, d MMMM yyyy').format(
            DateTime.parse(date),
          )),
        ));
  }
}
