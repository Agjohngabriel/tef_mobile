import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';

class SquadPositionFetch extends StatelessWidget {
  final String title;
  final bool isActive;
  final VoidCallback onTap;
  SquadPositionFetch(
      {Key? key,
        required this.title,
        required this.isActive,
        required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: isActive ? AppColors.primary.withOpacity(0.4) : AppColors.white,
            borderRadius: const BorderRadius.all(Radius.circular(5))),
        child: Text(title),
      ),
    );
  }
}