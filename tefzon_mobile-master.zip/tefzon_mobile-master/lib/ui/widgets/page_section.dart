import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';

import '../../helpers/constants/colors.dart';

class PageSection extends StatelessWidget {
  const PageSection({
    Key? key,
    required this.title,
    this.subtitle,
    required this.child,
    this.useSmallTitle = true,
    this.seeAllChildren,
    this.optionsWidget,
    this.titleSize,
  }) : super(key: key);

  final String title;
  final String? subtitle;
  final Widget child;
  final Widget? optionsWidget;
  final double? titleSize;

  final bool useSmallTitle;

  final List<Widget>? seeAllChildren;

  @override
  Widget build(BuildContext context) {
    final _textTheme = Theme.of(context).textTheme;
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                title,
                style: _textTheme.subtitle1?.copyWith(
                    fontSize: titleSize ??
                        (useSmallTitle
                            ? context.widthPercent(0.05)
                            : context.widthPercent(0.055))),
              ),
              const Spacer(),
              if (optionsWidget != null) optionsWidget!,
              if (seeAllChildren != null)
                GestureDetector(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Text(
                        'See All',
                        style:
                        TextStyle(fontSize: 16, color: AppColors.primary),
                      ),
                      SizedBox(width: 2),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 14,
                        color: AppColors.primary,
                      )
                    ],
                  ),
                ),
            ],
          ),
          if (subtitle != null) const SizedBox(height: 5),
          if (subtitle != null)
            Text(
              subtitle!,
              style: _textTheme.caption
                  ?.copyWith(fontSize: useSmallTitle ? 14 : 18),
            ),
          const SizedBox(height: 15),
          child,
        ],
      ),
    );
  }
}
