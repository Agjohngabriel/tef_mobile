import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/assets.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';
import 'package:tefzon_mobile/model/squad.dart';
import 'package:tefzon_mobile/ui/views/select_squad/select_squad_viewmodel.dart';
import 'package:tefzon_mobile/ui/widgets/player_widget.dart';

import '../../helpers/constants/colors.dart';
import '../../services/api.dart';
import '../../services/core_services/squad_service.dart';
import '../views/my_squad/my_squad_viewmodel.dart';

class Pitch extends ViewModelWidget<SelectSquadViewModel> {
  List<GoalKeepers> goalKeepers;
  List<Defender> defender;
  List<MidFielders> midFielders;
  List<Forwards> forwards;
  List<Subs> subs;
  Pitch({
    required this.goalKeepers,
    required this.defender,
    required this.midFielders,
    required this.forwards,
    required this.subs,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, SelectSquadViewModel viewModel) {
    return Container(
      padding: EdgeInsets.all(20),
      width: double.infinity,
      decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage(AppAssets.pitch), fit: BoxFit.cover)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...goalKeepers.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  2 - goalKeepers.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 1),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...defender.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  5 - defender.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 2),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...midFielders.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  5 - midFielders.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 3),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...forwards.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  3 - forwards.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 4),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}

class OtherPitch extends ViewModelWidget<MySquadViewModel> {
  List<GoalKeepers> goalKeepers;
  List<Defender> defender;
  List<MidFielders> midFielders;
  List<Forwards> forwards;
  List<Subs> subs;
  OtherPitch({
    required this.goalKeepers,
    required this.defender,
    required this.midFielders,
    required this.forwards,
    required this.subs,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, MySquadViewModel viewModel) {
    return Container(
      padding: EdgeInsets.all(20),
      width: double.infinity,
      decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage(AppAssets.pitch), fit: BoxFit.cover)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...goalKeepers.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  2 - goalKeepers.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 1),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...defender.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  5 - defender.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 2),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...midFielders.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  5 - midFielders.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 3),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ...forwards.map((e) => PlayerWidget(
                    onTap: () => showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage:
                                        NetworkImage("${e.imagePath}"),
                                  ),
                                  title: Text("${e.playerName}"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData("select/captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .getData(
                                                "select/vice-captain/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Make Vice Captain"),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () async {
                                        await Api()
                                            .deleteData("remove/player/${e.id}")
                                            .then((value) {
                                          if (value.statusCode == 200) {
                                            locator<SquadService>()
                                                .fetchSquad();
                                            OneContext()
                                                .dialog
                                                .showDialog<void>(
                                                  barrierDismissible: true,
                                                  // false = user must tap button, true = tap outside dialog
                                                  builder: (BuildContext
                                                      dialogContext) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Success'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('Ok'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    dialogContext)
                                                                .pop(); // Dismiss alert dialog
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                          }
                                        });
                                        Navigator.pop(context);
                                      },
                                      child: Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        padding: EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            border: Border.all(
                                                color: AppColors.primary,
                                                width: 1)),
                                        child: Text("Remove"),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                    name: "${e.playerName}",
                    imagePath: "${e.imagePath}",
                    isCaptain: e.isCaptain == 1 ? true : false,
                    isViceCaptain: e.isViceCaptain == 1 ? true : false,
                  )),
              Row(
                children: List.generate(
                  3 - forwards.length,
                  (index) => PlayerWidget(
                    onTap: () => locator<GoRouter>()
                        .push(AppRoutes.pickPlayer, extra: 4),
                    name: "",
                    imagePath: "",
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
