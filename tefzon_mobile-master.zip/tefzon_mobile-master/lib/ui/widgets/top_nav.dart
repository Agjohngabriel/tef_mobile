import 'package:flutter/material.dart';

import '../../helpers/constants/colors.dart';

class TopNav extends StatelessWidget {
  final String title;
  final bool isActive;
  TopNav({Key? key, required this.title, this.isActive = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 10),
      width: 95,
      height: 30,
      decoration: BoxDecoration(
          color: isActive
              ? AppColors.primary.withOpacity(0.1)
              : AppColors.primary.withOpacity(0.9),
          borderRadius: BorderRadius.circular(10)),
      child: Center(
          child: Text(
        title,
        style: TextStyle(color: isActive ? AppColors.primary : AppColors.white),
      )),
    );
  }
}
