import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';

import '../../helpers/constants/colors.dart';


class CustomTabView extends StatelessWidget {
  const CustomTabView({
    Key? key,
    required this.index,
    required this.tabTitles,
    required this.tabViews,
    //TODO: This would cause issues on some screens. Will review later
    this.left = 10,
    this.right = 90,
  })  : assert(tabTitles.length == tabViews.length),
        assert(index < tabTitles.length && index >= 0),
        super(key: key);

  final int index;
  final double right;
  final double left;
  final List<String> tabTitles;
  final List<Widget> tabViews;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: index,
      length: tabTitles.length,
      child: Column(
        children: [
          TabBar(
            labelStyle:
                const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
            unselectedLabelStyle:
                context.textTheme.caption?.copyWith(fontSize: 14),
            padding: const EdgeInsets.symmetric(vertical: 10),
            indicator: UnderlineTabIndicator(
              // color: AppColors.white,
              borderSide: const BorderSide(width: 3, color: AppColors.primary),
              insets: EdgeInsets.only(
                // right: context.widthPercent(0.39),
                // left: context.widthPercent(0.035),
                right: right,
                left: left,
              ),
            ),
            labelColor: AppColors.primary,
            indicatorColor: AppColors.primary,
            unselectedLabelColor: AppColors.black,
            tabs: [
              for (String title in tabTitles)
                Tab(
                  child: SizedBox(
                    width: double.infinity,
                    child: Text(
                      title,
                      maxLines: 2,
                    ),
                  ),
                ),
            ],
          ),
          Expanded(
              child: TabBarView(
            children: [
              for (Widget view in tabViews)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  child: view,
                ),
            ],
          ))
        ],
      ),
    );
  }
}
