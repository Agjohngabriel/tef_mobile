import 'package:flutter/material.dart';


import '../../helpers/constants/colors.dart';

class CustomScrollableSheet extends StatelessWidget {
  final Widget child;
  const CustomScrollableSheet({Key? key, required this.child})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
        initialChildSize: 0.8,
        minChildSize: 0.8,
        builder: (BuildContext context, ScrollController scrollController) =>
            Column(
              children: [
                InkWell(
                  onTap: () => Navigator.pop(context),
                  child: const Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Icon(
                      Icons.close,
                      color: AppColors.white,
                      size: 20,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: const BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25),
                        topRight: Radius.circular(25)),
                  ),
                  child: child,
                ),
              ],
            ));
  }
}
