import 'package:flutter/material.dart';

import '../../helpers/constants/colors.dart';

class CustomContainer extends StatelessWidget {
  final String title;
  final VoidCallback function;
  const CustomContainer({Key? key, required this.title, required this.function})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: function,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: const BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.all(Radius.circular(9))),
        child: Center(
            child: Text(
          title,
          style: const TextStyle(
            color: AppColors.white,
            fontSize: 18,
            fontStyle: FontStyle.normal,
            letterSpacing: 0.5,
            fontWeight: FontWeight.w700,
          ),
        )),
      ),
    );
  }
}
