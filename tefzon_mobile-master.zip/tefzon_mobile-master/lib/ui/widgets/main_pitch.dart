import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/widgets/player_widget.dart';

import '../../helpers/constants/assets.dart';
import '../../helpers/constants/colors.dart';
import '../../model/squad.dart';
import '../views/starting_eleven/starting_eleven_viewmodel.dart';

class MainPitch extends ViewModelWidget<StartingElevenViewModel> {
  final Squad squad;
  const MainPitch({Key? key, required this.squad}) : super(key: key);

  @override
  Widget build(BuildContext context, StartingElevenViewModel viewModel) {
    return SizedBox(
        child: Stack(
      alignment: Alignment.topCenter,
      children: [
        Container(
          width: double.infinity,
          decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage(AppAssets.pitch), fit: BoxFit.cover)),
        ),
        squad.goalkeepers == null
            ? const SizedBox()
            : Positioned(
                top: context.heightPercent(0.18),
                child: Row(
                  children: [
                    ...?squad.goalkeepers
                        ?.map((e) => Stack(
                              children: [
                                PlayerWidget(
                                  onTap: (){},
                                  name: "${e.playerName}",
                                  imagePath: "${e.imagePath}",
                                ),
                                Positioned(
                                    right: 5,
                                    top: 0,
                                    child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.close,
                                        size: 25,
                                        color: AppColors.primaryOption3,
                                      ),
                                    )),
                              ],
                            ))
                        .toList(),
                  ],
                )),
        squad.defenders == null
            ? const SizedBox()
            : Positioned(
                top: context.heightPercent(0.29),
                child: Row(
                  children: [
                    ...?squad.defenders
                        ?.map((e) => Stack(
                              children: [
                                PlayerWidget(
                                  onTap: (){},
                                  name: "${e.playerName}",
                                  imagePath: "${e.imagePath}",
                                ),
                                Positioned(
                                    right: 5,
                                    top: 0,
                                    child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.close,
                                        size: 25,
                                        color: AppColors.primaryOption3,
                                      ),
                                    )),
                              ],
                            ))
                        .toList(),
                  ],
                )),
        squad.midfielders == null
            ? const SizedBox()
            : Positioned(
                top: context.heightPercent(0.39),
                child: Row(
                  children: [
                    ...?squad.midfielders
                        ?.map((e) => Stack(
                              children: [
                                PlayerWidget(
                                  onTap: (){},
                                  name: "${e.playerName}",
                                  imagePath: "${e.imagePath}",
                                ),
                                Positioned(
                                    right: 5,
                                    top: 0,
                                    child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.close,
                                        size: 25,
                                        color: AppColors.primaryOption3,
                                      ),
                                    )),
                              ],
                            ))
                        .toList(),
                  ],
                )),
        squad.forwards == null
            ? const SizedBox()
            : Positioned(
                top: context.heightPercent(0.49),
                child: Row(
                  children: [
                    ...?squad.forwards
                        ?.map((e) => Stack(
                              children: [
                                PlayerWidget(
                                  onTap: (){},
                                  name: "${e.playerName}",
                                  imagePath: "${e.imagePath}",
                                ),
                                Positioned(
                                    right: 5,
                                    top: 0,
                                    child: IconButton(
                                      onPressed: () {},
                                      icon: const Icon(
                                        Icons.close,
                                        size: 25,
                                        color: AppColors.primaryOption3,
                                      ),
                                    )),
                              ],
                            ))
                        .toList(),
                  ],
                )),
      ],
    ));
  }
}
