import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../helpers/constants/colors.dart';

enum ColoredTextPosition {
  start,
  end,
}

class TefzonAppBar extends StatelessWidget implements PreferredSizeWidget {
  const TefzonAppBar({
    Key? key,
    this.useXIcon = true,
    this.coloredText = '',
    required this.text,
    this.leading,
    this.coloredTextPosition = ColoredTextPosition.start,
    this.actions,
  }) : super(key: key);

  /// When true the back button will be an X icon, otherwise it will be a back arrow.
  final bool useXIcon;

  /// Determines the position of the coloured text
  final ColoredTextPosition coloredTextPosition;

  /// returns the default previous icon if null
  final Widget? leading;

  final String coloredText;
  final String text;

  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: coloredTextPosition == ColoredTextPosition.start
          ? Text.rich(
              TextSpan(
                  text: coloredText,
                  children: [
                    TextSpan(
                      text: text,
                      style: const TextStyle(color: Colors.black),
                    ),
                  ],
                  style: const TextStyle(color: AppColors.primary)),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            )
          : Text.rich(
              TextSpan(
                  text: text,
                  children: [
                    TextSpan(
                      text: coloredText,
                      style: const TextStyle(color: AppColors.primary),
                    ),
                  ],
                  style: const TextStyle(color: Colors.black)),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
      leading: leading ??
          IconButton(
            icon: Icon(
              useXIcon ? Icons.close : Icons.arrow_back,
              color: Colors.black,
              size: 30,
            ),
            onPressed: () => context.pop(),
          ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      actions: actions,
    );
  }

  @override
  Size get preferredSize =>
      const Size(double.infinity, 56); //using 56 cause that's flutter's default
}
