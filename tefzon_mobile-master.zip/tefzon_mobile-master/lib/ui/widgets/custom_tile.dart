import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';

class CustomMenuTile extends StatelessWidget {
  const CustomMenuTile({
    Key? key,
    required this.title,
    this.leading,
    this.trailing,
    this.subtitle,
    required this.onTap,
    this.contentPadding,
    this.minLeadingWidth,
    this.leadingWidget,
  }) : super(key: key);

  final String title;
  final Widget? leading;
  final Widget? trailing;
  final String? subtitle;
  final Function() onTap;
  final EdgeInsetsGeometry? contentPadding;
  final double? minLeadingWidth;
  final Widget? leadingWidget;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding:
          contentPadding ?? const EdgeInsets.symmetric(horizontal: 7),
      minLeadingWidth: minLeadingWidth ?? 15,
      onTap: onTap,
      leading: leadingWidget ??
          SizedBox(
            width: 20,
            child: leading,
          ),
      title: Text(title, maxLines: 1),
      subtitle: subtitle == null ? null : Text(subtitle!),
      trailing: trailing ??
          const Icon(
            Icons.arrow_forward_ios_rounded,
            color: AppColors.primary,
          ),
    );
  }
}
