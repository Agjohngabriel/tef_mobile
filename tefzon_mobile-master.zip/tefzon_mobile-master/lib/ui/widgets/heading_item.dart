import 'package:flutter/material.dart';

class HeadingItems extends StatelessWidget {
  final String title;
  HeadingItems({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          Row(
            children: const [Text("See all"), Icon(Icons.arrow_forward)],
          ),
        ],
      ),
    );
  }
}