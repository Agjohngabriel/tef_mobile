import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../helpers/constants/colors.dart';

class PlayerWidget extends StatelessWidget {
  final String name;
  final String imagePath;
  final VoidCallback onTap;
  final bool isCaptain;
  final bool isViceCaptain;
  const PlayerWidget(
      {Key? key,
      required this.name,
      required this.imagePath,
      required this.onTap,
      this.isCaptain = false,
      this.isViceCaptain = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            margin: const EdgeInsets.only(right: 5),
            child: Column(
              children: [
                imagePath.isEmpty
                    ? Container(
                        width: 70,
                        height: 60,
                        child: SvgPicture.asset("asset/images/player.svg"),
                      )
                    : Container(
                        width: 60,
                        height: 70,
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: NetworkImage(imagePath))),
                      ),
                name.isEmpty
                    ? SizedBox()
                    : Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(color: AppColors.black),
                        child: Center(
                          child: Text(
                            name.split(" ").first,
                            style: const TextStyle(
                              color: AppColors.white,
                            ),
                          ),
                        ),
                      ),
                isCaptain
                    ? Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(color: Colors.red),
                        child: Center(
                          child: Text(
                            "Captain",
                            style: const TextStyle(
                              color: AppColors.white,
                            ),
                          ),
                        ),
                      )
                    : SizedBox(),
                isViceCaptain
                    ? Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(color: Colors.red),
                        child: Center(
                          child: Text(
                            "Vice Captain",
                            style: const TextStyle(
                              color: AppColors.white,
                            ),
                          ),
                        ),
                      )
                    : SizedBox()
              ],
            ),
          ),
          name.isEmpty
              ? Positioned.fill(
                  child: Align(
                      alignment: Alignment.center,
                      child: Icon(
                        Icons.add,
                        color: AppColors.primary,
                      )))
              : SizedBox()
        ],
      ),
    );
  }
}
