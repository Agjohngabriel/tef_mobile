import 'package:flutter/material.dart';
import 'package:stacked_services/stacked_services.dart';

import '../../app/locator.dart';
import '../../helpers/constants/enum.dart';

void setupDialogUi() {
  final dialogService = locator<DialogService>();

  final builders = {
    DialogType.basic: (context, sheetRequest, completer) => _BasicDialog(
          request: sheetRequest,
          completer: completer,
          key: null,
        ),
  };

  dialogService.registerCustomDialogBuilders(builders);
}

class _BasicDialog extends StatelessWidget {
  final DialogRequest request;
  final Function(DialogResponse) completer;
  const _BasicDialog({Key? key, required this.request, required this.completer})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Dialog(
      child: Center(),
    );
  }
}
