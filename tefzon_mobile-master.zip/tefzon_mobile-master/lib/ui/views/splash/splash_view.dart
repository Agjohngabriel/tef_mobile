import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/assets.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:tefzon_mobile/ui/views/splash/splash_viewmodel.dart';

import '../../../helpers/constants/colors.dart';

class SplashView extends StatelessWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SplashViewModel>.reactive(
      onModelReady: (model) {
        model.startTime();
      },
      builder: (context, model, child) => Scaffold(
        backgroundColor: AppColors.backgroundGrey,
        body: Center(
            child: Image.asset(AppAssets.logo, width: context.widthPercent(0.6),)),
      ),
      viewModelBuilder: () => SplashViewModel(),
    );
  }
}
