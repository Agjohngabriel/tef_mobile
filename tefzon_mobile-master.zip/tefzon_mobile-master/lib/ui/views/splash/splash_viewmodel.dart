import 'dart:async';

import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';

import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';

class SplashViewModel extends BaseViewModel {
  final _router = locator<GoRouter>();
  final _sharedStorage = locator<SharedStorage>();

  double iconSize = 50;
  startTime() async {
    iconSize = 350;
    notifyListeners();

    const duration = Duration(seconds: 3);

    // TODO: refactor flow
    return Timer(duration, goToDashboard);
  }

  void goToDashboard() {
    if (_sharedStorage.hasLoggedIn) {
      _router.go(AppRoutes.home);
    } else {
      _router.go(AppRoutes.login);
    }
  }
}
