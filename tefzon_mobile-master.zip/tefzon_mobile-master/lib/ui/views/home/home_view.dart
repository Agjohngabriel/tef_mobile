import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/ui/views/account/account_view.dart';

import '../../../app/locator.dart';
import '../dashboard/dashboard_view.dart';
import '../league_view/league_view.dart';
import 'home_viewmodel.dart';

class HomeView extends StatelessWidget {
  const HomeView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<HomeViewModel>.reactive(
        viewModelBuilder: () => locator<HomeViewModel>(),
        disposeViewModel: false,
        onModelReady: (model) {
          model.fetchUser;
        },
        initialiseSpecialViewModelsOnce: true,
        builder: (context, model, child) => Scaffold(
              body: getViewForIndex(model.currentIndex),
              bottomNavigationBar: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                backgroundColor: AppColors.backgroundGrey,
                selectedItemColor: AppColors.primary,
                showSelectedLabels: true,
                showUnselectedLabels: true,
                currentIndex: model.currentIndex,
                onTap: model.setIndex,
                items: const [
                  BottomNavigationBarItem(
                      icon: Icon(Icons.home_filled), label: "Home"),
                  BottomNavigationBarItem(
                      icon: Icon(Icons.sports_volleyball_outlined),
                      label: "League"),
                  BottomNavigationBarItem(
                      icon: Icon(Icons.person), label: "Account"),
                ],
              ),
            ));
  }

  Widget getViewForIndex(int index) {
    switch (index) {
      case 0:
        return const DashboardView();
      case 1:
        return const LeagueView();
      default:
        return const AccountView();
    }
  }
}
