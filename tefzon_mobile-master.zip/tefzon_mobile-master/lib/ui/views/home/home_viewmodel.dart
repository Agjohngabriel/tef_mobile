import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';
import 'package:tefzon_mobile/services/core_services/user_services.dart';

class HomeViewModel extends IndexTrackingViewModel {
  final _userService = locator<UserService>();
  final _sharedStorage = locator<SharedStorage>();
  void fetchUser() {
    var user = _sharedStorage.user;
    _userService.getUser(user!);
  }
}
