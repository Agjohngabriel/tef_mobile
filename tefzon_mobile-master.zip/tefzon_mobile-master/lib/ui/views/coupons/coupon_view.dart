import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';


import '../../../helpers/constants/colors.dart';

import 'package:stacked/stacked.dart';

import 'coupon_viewmodel.dart';

class CouponView extends StatelessWidget {
  const CouponView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CouponViewModel>.reactive(
      builder: (context, model, child) => Scaffold(
        backgroundColor: AppColors.white,
        body: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Image.asset(
              //   AppAssets.couponEmpty,
              //   scale: 3,
              // ),
              SizedBox(
                height: context.heightPercent(0.07),
              ),
              Text(
                "Currently, there is no voucher defined for your account.",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: AppColors.text60,
                    fontSize: context.widthPercent(0.045),
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.w800),
              ),
              const SizedBox(
                height: 20,
              ),
              Text(
                  "You can take a look at the campaigns of the restaurants in your disctrict to order with discounts.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: AppColors.textgrey,
                      fontSize: context.widthPercent(0.032),
                      fontWeight: FontWeight.w600)),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
      ),
      viewModelBuilder: () => CouponViewModel(),
    );
  }
}
