import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';

import '../../../app/locator.dart';

class CouponViewModel extends BaseViewModel {
  final _router = locator<GoRouter>();

  void goToRestaurantsList() {
    _router.pop();
  }
}
