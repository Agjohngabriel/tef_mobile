import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:tefzon_mobile/model/leagues.dart';
import 'package:tefzon_mobile/ui/views/league_view/private_leagues/private_league_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/league_view/public_leagues/public_leagues_viewmodel.dart';

import '../../../../helpers/constants/colors.dart';
import '../../../widgets/custom_buttons.dart';
import '../league_view.dart';

class PublicLeagueView extends StatelessWidget {
  const PublicLeagueView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PublicLeagueViewModel>.reactive(
        viewModelBuilder: () => PublicLeagueViewModel(),
        builder: (context, model, child) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: model.hasError
                  ? Container(
                      color: Colors.red,
                      alignment: Alignment.center,
                      child: const Text(
                        'An error has occered while running the future',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 50,
                          margin: EdgeInsets.symmetric(
                              horizontal: context.widthPercent(0.05)),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  child: TextFormField(
                                    decoration: const InputDecoration(
                                        hintText: "Join league by code"),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    "Join",
                                  ))
                            ],
                          ),
                        ),
                        // const SizedBox(
                        //   height: 20,
                        // ),
                        // Padding(
                        //   padding: EdgeInsets.symmetric(
                        //       horizontal: context.widthPercent(0.05)),
                        //   child: const Text(
                        //     "List of Live leagues",
                        //   ),
                        // ),
                        const SizedBox(
                          height: 20,
                        ),
                        model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : model.data!.isEmpty
                                ? const Center(
                                    child: Text(
                                        "No Leagues Available at the moment"),
                                  )
                                : Expanded(
                                    child: ListView(
                                      children: [
                                        ...model.data!.map<Widget>((e) =>
                                            PublicLeagueCard(
                                                e: e, publicModel: model)),
                                      ],
                                    ),
                                  ),
                      ],
                    ),
            ));
  }
}

class PublicLeagueCard extends StatelessWidget {
  bool isPublic;
  String? code;
  final LeagueModel e;
  final PublicLeagueViewModel? publicModel;
  final PrivateLeagueViewModel? privateModel;
  PublicLeagueCard(
      {super.key,
      required this.e,
      this.publicModel,
      this.code,
      this.privateModel,
      this.isPublic = true});

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.symmetric(
          horizontal: context.widthPercent(0.05),
          vertical: context.widthPercent(0.02),
        ),
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: context.widthPercent(0.05),
            vertical: context.widthPercent(0.03),
          ),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(blurRadius: 3, color: Colors.grey.shade300)
              ]),
          child: Row(
            children: [
              RotatedBox(
                quarterTurns: -45,
                child: Container(
                    decoration: BoxDecoration(
                        color: Colors.amber,
                        borderRadius: BorderRadius.circular(10)),
                    padding: EdgeInsets.symmetric(vertical: 3, horizontal: 10),
                    child: Text(e.entryType!)),
              ),
              SizedBox(
                width: context.widthPercent(0.05),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    e.name!,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                  ),
                  Text(
                    e.duration!,
                    style: TextStyle(color: Colors.grey),
                  )
                ],
              ),
              Expanded(child: Container()),
              TextButton(
                  // onPressed: () {
                  //   isPublic
                  //       ? publicModel!.joinPublic(id: e.id)
                  //       : privateModel!.joinPrivate(id: e.id, code: code!);
                  // },
                  //
                  onPressed: () => showDialog(
                      context: context,
                      builder: (BuildContext context) => Dialog(
                            backgroundColor: Colors.transparent,
                            insetPadding: EdgeInsets.symmetric(
                                vertical: 250, horizontal: 20),
                            child: Container(
                                margin: EdgeInsets.only(bottom: 8),
                                decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey.shade300,
                                          blurRadius: 10,
                                          spreadRadius: 1)
                                    ],
                                    gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          AppColors.primaryOption2,
                                          AppColors.primary.withOpacity(0.9),
                                          AppColors.primaryOption2,
                                        ]),
                                    borderRadius: BorderRadius.circular(25)),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      //title
                                      padding:
                                          EdgeInsets.symmetric(vertical: 8),
                                      width: context.widthPercent(0.5),
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.vertical(
                                              bottom: Radius.circular(10))),
                                      child: Center(
                                          child: Text(
                                        e.name!,
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            color: AppColors.primary),
                                      )),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: context.widthPercent(
                                            0.05,
                                          ),
                                          right: context.widthPercent(
                                            0.05,
                                          ),
                                          top: context.widthPercent(
                                            0.02,
                                          )),
                                      child: Column(
                                        children: [
                                          RowText(
                                              title: "Type", caption: e.type!),
                                          Divider(
                                            color: Colors.white30,
                                            thickness: 1,
                                          ),
                                          RowText(
                                              title: "Status",
                                              caption: e.status!),
                                          Divider(
                                            color: Colors.white30,
                                            thickness: 1,
                                          ),
                                          RowText(
                                              title: "Duration",
                                              caption: e.duration!),
                                          Divider(
                                            color: Colors.white30,
                                            thickness: 1,
                                          ),
                                          RowText(
                                              title: "Participation",
                                              caption:
                                                  e.participants.toString()),
                                          SizedBox(
                                            height: 14,
                                          )
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                        child: Row(
                                      children: [
                                        Expanded(
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius: BorderRadius.only(
                                                    bottomLeft:
                                                        Radius.circular(20))),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text("Start"),
                                                    SizedBox(
                                                      width: 3,
                                                    ),
                                                    Icon(
                                                      Icons.calendar_month,
                                                      size: 14,
                                                    )
                                                  ],
                                                ),
                                                Text(
                                                  DateFormat('dd-MM-yyyy')
                                                      .format(e.start!),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: 1,
                                          color: AppColors.primaryOption2,
                                        ),
                                        Expanded(
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius: BorderRadius.only(
                                                    bottomRight:
                                                        Radius.circular(20))),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text("End"),
                                                    SizedBox(
                                                      width: 3,
                                                    ),
                                                    Icon(
                                                      Icons.calendar_month,
                                                      size: 14,
                                                    )
                                                  ],
                                                ),
                                                Text(
                                                  DateFormat('dd-MM-yyyy')
                                                      .format(e.end!),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    )),
                                    InkWell(
                                      onTap: () {
                                        Navigator.of(context).pop();
                                        isPublic
                                            ? publicModel!.joinPublic(id: e.id)
                                            : privateModel!.joinPrivate(
                                                id: e.id, code: code!);
                                      },
                                      child: Container(
                                        //title
                                        padding:
                                            EdgeInsets.symmetric(vertical: 8),
                                        width: context.widthPercent(0.5),
                                        decoration: BoxDecoration(
                                            color: AppColors.primary,
                                            borderRadius: BorderRadius.vertical(
                                                bottom: Radius.circular(10))),
                                        child: Center(
                                            child: Text(
                                          "Join League",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              color: AppColors.white),
                                        )),
                                      ),
                                    ),
                                  ],
                                )),
                          )),
                  child: Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey, width: 1)),
                    child: Text("Join League"),
                  ))
            ],
          ),
        )

        // ListTile(
        //   leading:
        //       Text('${e.entryType}'),
        //   subtitle:
        //       Text('${e.duration}'),
        //   contentPadding:
        //       EdgeInsets.zero,
        //   title: Text('${e.name}'),
        //   trailing: TextButton(
        //       onPressed: () => model
        //           .joinPublic(id: e.id),
        //       child: const Text(
        //         "Join League",
        //       )),
        // )

        );
  }
}
