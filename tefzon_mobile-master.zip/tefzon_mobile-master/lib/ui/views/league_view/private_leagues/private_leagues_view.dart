import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/ui/views/league_view/private_leagues/private_league_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/league_view/public_leagues/public_leagues_views.dart';

import '../../../../helpers/constants/colors.dart';

class PrivateLeagueView extends StatelessWidget {
  const PrivateLeagueView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PrivateLeagueViewModel>.reactive(
        viewModelBuilder: () => PrivateLeagueViewModel(),
        builder: (context, model, child) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: model.hasError
                  ? Container(
                      color: Colors.red,
                      alignment: Alignment.center,
                      child: const Text(
                        'An error has occered while running the future',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 50,
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  child: TextFormField(
                                    decoration: const InputDecoration(
                                        hintText: "Join league by code"),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    "Join",
                                  ))
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          "List of Live leagues",
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : model.data!.isEmpty
                                ? const Center(
                                    child: Text(
                                        "No Leagues Available at the moment"),
                                  )
                                : Expanded(
                                    child: ListView(
                                      children: [
                                        ...model.data!.map<Widget>((e) => Container(
                                            margin: const EdgeInsets.all(10),
                                            child: PublicLeagueCard(
                                              e: e,
                                              privateModel: model,
                                              code: e.code,
                                            )

                                            // ListTile(
                                            //   leading: Text('${e.entryType}'),
                                            //   subtitle: Text('${e.duration}'),
                                            //   contentPadding: EdgeInsets.zero,
                                            //   title: Text('${e.name}'),
                                            //   trailing: TextButton(
                                            //       onPressed: () =>
                                            //           model.joinPrivate(
                                            //               code: "${e.code}",
                                            //               id: e.id),
                                            //       child: const Text(
                                            //         "Join League",
                                            //       )),
                                            // )

                                            ))
                                      ],
                                    ),
                                  ),
                      ],
                    ),
            ));
  }
}
