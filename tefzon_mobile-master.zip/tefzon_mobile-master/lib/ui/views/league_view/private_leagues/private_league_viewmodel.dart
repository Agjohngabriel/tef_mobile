import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';

import '../../../../app/locator.dart';
import '../../../../model/leagues.dart';
import '../../../../services/api.dart';

class PrivateLeagueViewModel extends FutureViewModel<List<LeagueModel>> {
  final _api = locator<Api>();
  void joinPrivate({required int? id, required String? code}) async {
    setBusy(true);
    final data = {"id": id, "code": code};
    await _api.postData("join/private/league", data).then((value) {
      print(value.statusCode);
      if (value.statusCode == 200) {
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      } else if (value.statusCode == 422) {
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: Text(jsonDecode(value.body)["message"]),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
  }

  Future<List<LeagueModel>> getPrivate() async {
    var favourites = <LeagueModel>[];
    var response = await _api.getData('private-leagues');
    var parsed = json.decode(response.body) as List<dynamic>;
    for (var favourite in parsed) {
      favourites.add(LeagueModel.fromJson(favourite));
    }

    return favourites;
  }

  @override
  Future<List<LeagueModel>> futureToRun() => getPrivate();
}
