import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/league_view/league_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/league_view/private_leagues/private_leagues_view.dart';
import 'package:tefzon_mobile/ui/views/league_view/public_leagues/public_leagues_views.dart';
import 'package:tefzon_mobile/ui/widgets/custom_buttons.dart';

class LeagueView extends StatefulWidget {
  const LeagueView({Key? key}) : super(key: key);

  @override
  State<LeagueView> createState() => _LeagueViewState();
}

class _LeagueViewState extends State<LeagueView> {
  int activeIndex = 0;
  List tabeData = ["Public League", "Private league"];

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LeagueViewModel>.reactive(
        viewModelBuilder: () => LeagueViewModel(),
        onModelReady: (model) => model.fetchPlayersLeague(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.backgroundGrey,
              appBar: AppBar(
                backgroundColor: AppColors.backgroundGrey,
                title: Center(
                    child: Text(
                  "Choose a league type to join",
                  style: context.textTheme.headline6,
                  textAlign: TextAlign.center,
                )),
              ),
              body: RefreshIndicator(
                onRefresh: () => model.fetchPlayersLeague(),
                child: ListView(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 8.0, top: 8.0, right: 14.0, bottom: 14.0),
                      child: Text(
                        "My Leagues",
                        style: context.textTheme.headlineSmall?.copyWith(
                            color: AppColors.black,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                    model.isBusy
                        ? const Center(
                            child: SpinKitThreeBounce(
                            color: AppColors.primary,
                          ))
                        : model.leagues.isEmpty
                            ? const SizedBox()
                            : SizedBox(
                                height: context.heightPercent(0.24),
                                width: context.widthPercent(0.9),
                                child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: model.leagues.length,
                                    itemBuilder: (context, index) {
                                      var item = model.leagues[index];
                                      return Container(
                                          width: 300,
                                          margin: EdgeInsets.only(
                                              bottom: 8, right: 20),
                                          decoration: BoxDecoration(
                                              boxShadow: [
                                                BoxShadow(
                                                    color: Colors.grey.shade300,
                                                    blurRadius: 10,
                                                    spreadRadius: 1)
                                              ],
                                              gradient: LinearGradient(
                                                  begin: Alignment.topLeft,
                                                  end: Alignment.bottomRight,
                                                  colors: [
                                                    AppColors.primaryOption2,
                                                    AppColors.primary
                                                        .withOpacity(0.9),
                                                    AppColors.primaryOption2,
                                                  ]),
                                              borderRadius:
                                                  BorderRadius.circular(25)),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                //title
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 8),
                                                width:
                                                    context.widthPercent(0.5),
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.vertical(
                                                            bottom:
                                                                Radius.circular(
                                                                    10))),
                                                child: Center(
                                                    child: Text(
                                                  item.name!,
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      color: AppColors.primary),
                                                )),
                                              ),
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    left: context.widthPercent(
                                                      0.05,
                                                    ),
                                                    right: context.widthPercent(
                                                      0.05,
                                                    ),
                                                    top: context.widthPercent(
                                                      0.02,
                                                    )),
                                                child: Column(
                                                  children: [
                                                    RowText(
                                                        title: "Type",
                                                        caption: item.type!),
                                                    Divider(
                                                      color: Colors.white30,
                                                      thickness: 1,
                                                    ),
                                                    RowText(
                                                        title: "Status",
                                                        caption: item.status!),
                                                    Divider(
                                                      color: Colors.white30,
                                                      thickness: 1,
                                                    ),
                                                    RowText(
                                                        title: "Duration",
                                                        caption:
                                                            item.duration!),
                                                    Divider(
                                                      color: Colors.white30,
                                                      thickness: 1,
                                                    ),
                                                    RowText(
                                                        title: "Participation",
                                                        caption: item
                                                            .participants
                                                            .toString()),
                                                    SizedBox(
                                                      height: 14,
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                  child: Row(
                                                children: [
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                          20))),
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceAround,
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Text("Start"),
                                                              SizedBox(
                                                                width: 3,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .calendar_month,
                                                                size: 14,
                                                              )
                                                            ],
                                                          ),
                                                          Text(
                                                            DateFormat(
                                                                    'dd-MM-yyyy')
                                                                .format(item
                                                                    .start!),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    width: 1,
                                                    color: AppColors
                                                        .primaryOption2,
                                                  ),
                                                  Expanded(
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                              BorderRadius.only(
                                                                  bottomRight: Radius
                                                                      .circular(
                                                                          20))),
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceAround,
                                                        children: [
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Text("End"),
                                                              SizedBox(
                                                                width: 3,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .calendar_month,
                                                                size: 14,
                                                              )
                                                            ],
                                                          ),
                                                          Text(
                                                            DateFormat(
                                                                    'dd-MM-yyyy')
                                                                .format(
                                                                    item.end!),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              )),
                                            ],
                                          ));
                                    })),
                    const SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: EdgeInsets.all(context.widthPercent(0.05)),
                      child: CustomButton(
                        text: "Create League",
                        onTap: model.createLeague,
                        isFilled: true,
                        isPrimary: true,
                        color: AppColors.primaryOption2,
                      ),
                    ),
                    // Padding(
                    //   padding: EdgeInsets.only(
                    //     left: context.widthPercent(0.05),
                    //     right: context.widthPercent(0.05),
                    //   ),
                    //   child: Text(
                    //     "Join Leagues",
                    //     style: context.textTheme.headline5
                    //         ?.copyWith(color: AppColors.black),
                    //   ),
                    // ),
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: BorderRadius.circular(10)),
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 3),
                                child: TextFormField(
                                  decoration: const InputDecoration(
                                      border: InputBorder.none,
                                      hintText: "Search League"),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 16.5),
                              decoration: BoxDecoration(
                                  color: AppColors.grey.withOpacity(0.5),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Icon(
                                Icons.search,
                                color: AppColors.primaryOption2,
                              )),
                        ],
                      ),
                    ),
                    Container(
                      width: context.widthPercent(1),
                      margin: EdgeInsets.only(top: 20),
                      height: context.widthPercent(0.12),
                      padding: EdgeInsets.symmetric(
                          horizontal: context.widthPercent(0.05)),
                      color: Colors.grey.shade100,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ...List.generate(
                            2,
                            (index) => Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    activeIndex = index;
                                  });
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      color: activeIndex == index
                                          ? AppColors.primaryOption2
                                          : Colors.white,
                                      borderRadius: BorderRadius.horizontal(
                                        right: index == 0
                                            ? Radius.circular(0)
                                            : Radius.circular(30),
                                        left: index == 0
                                            ? Radius.circular(30)
                                            : Radius.circular(0),
                                      )),
                                  child: Center(
                                      child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        index == 1
                                            ? Icons.lock
                                            : Icons.visibility,
                                        size: 17,
                                        color: activeIndex != index
                                            ? AppColors.primaryOption2
                                            : Colors.white,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        tabeData[index],
                                        style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          color: activeIndex != index
                                              ? AppColors.primaryOption2
                                              : Colors.white,
                                        ),
                                      ),
                                    ],
                                  )),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        activeIndex == 0
                            ? Container(
                                width: context.widthPercent(1),
                                height: context.heightPercent(0.4),
                                child: PublicLeagueView())
                            : Container(
                                width: context.widthPercent(1),
                                height: context.heightPercent(0.4),
                                child: PrivateLeagueView())
                      ],
                    )

                    // DefaultTabController(
                    //   initialIndex: model.index,
                    //   length: 2,
                    //   child: Column(
                    //     children: [
                    //       TabBar(
                    //         labelStyle: const TextStyle(
                    //             fontWeight: FontWeight.w600, fontSize: 14),
                    //         unselectedLabelStyle: context.textTheme.caption
                    //             ?.copyWith(fontSize: 14),
                    //         padding: const EdgeInsets.symmetric(vertical: 10),
                    //         indicator: const UnderlineTabIndicator(
                    //           // color: AppColors.white,
                    //           borderSide: BorderSide(
                    //               width: 3, color: AppColors.primary),
                    //           insets: EdgeInsets.only(
                    //             right: 150,
                    //             left: 10,
                    //           ),
                    //         ),
                    //         labelColor: AppColors.primary,
                    //         indicatorColor: AppColors.primary,
                    //         unselectedLabelColor: AppColors.black,
                    //         tabs: const [
                    //           Tab(
                    //             child: SizedBox(
                    //               width: double.infinity,
                    //               child: Text(
                    //                 "Public League",
                    //                 maxLines: 2,
                    //               ),
                    //             ),
                    //           ),
                    //           Tab(
                    //             child: SizedBox(
                    //               width: double.infinity,
                    //               child: Text(
                    //                 "Private League",
                    //                 maxLines: 2,
                    //               ),
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //       const SizedBox(
                    //         height: 450,
                    //         child: TabBarView(
                    //           children: [
                    //             PublicLeagueView(),
                    //             PrivateLeagueView(),
                    //           ],
                    //         ),
                    //       )
                    //     ],
                    //   ),
                    // ),
                  ],
                ),
              ),
            )));
  }
}

class RowText extends StatelessWidget {
  final String title;
  final String caption;
  const RowText({super.key, required this.title, required this.caption});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(color: Colors.white),
        ),
        Text(
          caption.toUpperCase(),
          style: TextStyle(color: Colors.white),
        ),
      ],
    );
  }
}
