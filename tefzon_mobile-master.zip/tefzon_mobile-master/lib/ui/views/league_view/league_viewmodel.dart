import 'dart:convert';

import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';
import 'package:tefzon_mobile/model/leagues.dart';

import '../../../services/api.dart';

class LeagueViewModel extends FutureViewModel<List<LeagueModel>> {
  final _api = locator<Api>();
  final _router = locator<GoRouter>();
  int index = 0;
  var leagues = <LeagueModel>[];

  Future<List<LeagueModel>> fetchPlayersLeague() async {
    setBusy(true);
    leagues.clear();
    var response = await _api.getData("user/leagues");
    print(json.decode(response.body)["data"]);
    var parsed = json.decode(response.body)["data"] as List<dynamic>;
    for (var leaguw in parsed) {
      leagues.add(LeagueModel.fromJson(leaguw));
    }
    setBusy(false);
    return leagues;
  }

  void createLeague() {
    _router.push(AppRoutes.createLeague);
  }

  @override
  Future<List<LeagueModel>> futureToRun() => fetchPlayersLeague();
}
