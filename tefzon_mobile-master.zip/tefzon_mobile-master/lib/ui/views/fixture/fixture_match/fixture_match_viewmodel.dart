import 'package:stacked/stacked.dart';

class
    FixtureMatchViewModel extends BaseViewModel{

}