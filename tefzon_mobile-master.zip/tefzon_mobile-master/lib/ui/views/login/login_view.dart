import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:tefzon_mobile/helpers/constants/assets.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:tefzon_mobile/ui/views/login/login_viewmodel.dart';

import '../../../helpers/constants/colors.dart';
import '../../../helpers/utils/custom_editing_controller.dart';
import '../../../helpers/utils/validator.dart';
import 'login_view.form.dart';

@FormView(
  fields: [
    FormTextField(
      name: 'email',
      validator: FormValidators.emailValidator,
    ),
    FormTextField(
        name: 'password',
        validator: FormValidators.passwordValidator,
        customTextEditingController:
            CustomEditingController.getCustomEditingController),
  ],
  autoTextFieldValidation: false,
)
class LoginView extends StatelessWidget with $LoginView {
  LoginView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LoginViewModel>.reactive(
        viewModelBuilder: () => LoginViewModel(),
        onModelReady: (model) {
          // #3: Listen to text updates by calling listenToFormUpdated(model);
          listenToFormUpdated(model);
        },
        disposeViewModel: true,
        builder: (context, model, child) => SafeArea(
              top: false,
              bottom: false,
              child: Scaffold(
                resizeToAvoidBottomInset: false,
                backgroundColor: AppColors.white,
                body: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: Form(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: context.heightPercent(0.12),
                        ),
                        Center(
                          child: Image.asset(
                            AppAssets.logo,
                            width: context.widthPercent(0.6),
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.08),
                        ),
                        Center(
                          child: Text(
                            "Sign in to get started",
                            style: TextStyle(
                                color: AppColors.black,
                                letterSpacing: 0.4,
                                fontSize: context.widthPercent(0.05),
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.04),
                        ),
                        SizedBox(
                          child: TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              errorText: model.emailValidationMessage,
                              hintText: 'Enter Email Address',
                              hintStyle: TextStyle(
                                color: AppColors.black50,
                                fontSize: context.widthPercent(0.04),
                                fontStyle: FontStyle.normal,
                                letterSpacing: 0.5,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.03),
                        ),
                        SizedBox(
                          child: TextFormField(
                            controller: passwordController,
                            obscureText: model.isVisible,
                            keyboardType: TextInputType.visiblePassword,
                            decoration: InputDecoration(
                              errorText: model.passwordValidationMessage,
                              hintText: 'Enter Password',
                              suffixIcon: IconButton(
                                icon: Icon(
                                  // Based on passwordVisible state choose the icon
                                  model.isVisible
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: AppColors.primary,
                                ),
                                onPressed: model.toggleVisibility,
                              ),
                              hintStyle: TextStyle(
                                color: AppColors.black50,
                                fontSize: context.widthPercent(0.04),
                                fontStyle: FontStyle.normal,
                                letterSpacing: 0.5,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.03),
                        ),
                        const Align(
                            alignment: Alignment.centerRight,
                            child: Text("Forgot password?")),
                        SizedBox(
                          height: context.heightPercent(0.03),
                        ),
                        model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : InkWell(
                                onTap: model.saveData,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 10),
                                  decoration: const BoxDecoration(
                                      color: AppColors.primary,
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(9))),
                                  child: Center(
                                      child: Text(
                                    "Sign In",
                                    style: TextStyle(
                                      color: AppColors.white,
                                      fontSize: context.widthPercent(0.04),
                                      fontStyle: FontStyle.normal,
                                      letterSpacing: 0.5,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  )),
                                ),
                              ),
                        SizedBox(
                          height: context.heightPercent(0.02),
                        ),
                        GestureDetector(
                          onTap: model.signUp,
                          child: Text(
                            "Create Account",
                            style: TextStyle(
                                color: AppColors.blue,
                                letterSpacing: 0.4,
                                fontSize: context.widthPercent(0.04),
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.05),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: context.heightPercent(0.001),
                              width: context.widthPercent(0.3),
                              decoration: const BoxDecoration(
                                  color: AppColors.blue,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(6))),
                            ),
                            const SizedBox(
                              width: 19,
                            ),
                            Center(
                              child: Text(
                                'Or',
                                style: TextStyle(
                                  color: AppColors.blue,
                                  fontSize: context.widthPercent(0.04),
                                  fontStyle: FontStyle.normal,
                                  letterSpacing: 0.5,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 19,
                            ),
                            Container(
                              height: context.heightPercent(0.001),
                              width: context.widthPercent(0.3),
                              // width: MediaQuery.of(context).size.width / 2.6,
                              decoration: const BoxDecoration(
                                  color: AppColors.blue,
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(6))),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: context.heightPercent(0.04),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          decoration: BoxDecoration(
                              color: AppColors.white,
                              border: Border.all(color: AppColors.blue),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(9))),
                          child: Row(
                            children: [
                              Image(
                                image:
                                    const AssetImage("asset/images/google.png"),
                                width: context.widthPercent(0.08),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              const Text(
                                "Sign in with Google",
                                style: TextStyle(
                                  color: AppColors.blue,
                                  fontSize: 18,
                                  fontStyle: FontStyle.normal,
                                  letterSpacing: 0.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: context.heightPercent(0.025),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
  }
}
