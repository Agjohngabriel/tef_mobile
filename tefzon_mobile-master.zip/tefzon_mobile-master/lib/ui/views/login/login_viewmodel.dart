import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/app_keys.dart';
import 'package:tefzon_mobile/services/core_services/auth_service.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';

import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';
import 'login_view.form.dart';

class LoginViewModel extends FormViewModel {
  final _router = locator<GoRouter>();
  final _auth = locator<AuthService>();
  final _sharedStorage = locator<SharedStorage>();
  bool isVisible = false;

  void toggleVisibility() {
    isVisible ? isVisible = false : isVisible = true;
    notifyListeners();
  }
  void signIn() {
    _router.push(AppRoutes.home);
  }

  void signUp() {
    _router.push(AppRoutes.register);
  }

  Future saveData() async {
    final result = await runBusyFuture(_auth.login({
      "email": emailValue,
      "password": passwordValue,
    }), throwException: true);

    if (result.isSuccess) {
      _sharedStorage.saveToDisk(AppKeys.LoggedInKey, true);
      _router.go(AppRoutes.home);
    } else if (result.statsCode == 422) {
      var e = jsonDecode(result.message);
      if (result.message.contains("errors")) {
        setEmailValidationMessage(e["errors"]["email"][0]);
        if (kDebugMode) {
          print(emailValidationMessage);
        }
      }
      if (result.message.contains("message")) {
        setPasswordValidationMessage(e["message"]);
        if (kDebugMode) {
          print(passwordValidationMessage);
        }
      }
    }
  }

  @override
  void setFormStatus() {}
}
