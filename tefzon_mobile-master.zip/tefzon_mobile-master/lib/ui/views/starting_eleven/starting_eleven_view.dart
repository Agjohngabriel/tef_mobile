import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:tefzon_mobile/ui/views/starting_eleven/starting_eleven_viewmodel.dart';
import 'package:tefzon_mobile/ui/widgets/player_widget.dart';

import '../../../helpers/constants/assets.dart';
import '../../../helpers/constants/colors.dart';

class StartingEleven extends StatelessWidget {
  const StartingEleven({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<StartingElevenViewModel>.reactive(
        viewModelBuilder: () => StartingElevenViewModel(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
                backgroundColor: AppColors.primary,
                appBar: AppBar(
                  title: const Text("Starting Eleven"),
                  elevation: 0,
                  backgroundColor: Colors.deepPurpleAccent,
                ),
                floatingActionButton: model.squad?.subs?.length == 4
                    ? IconButton(
                        onPressed: model.chooseCaptain,
                        icon: Container(
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                              color: AppColors.white,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(15))),
                          child: const Icon(
                            Icons.arrow_forward,
                            color: AppColors.primary,
                          ),
                        ),
                      )
                    : SizedBox(),
                body: RefreshIndicator(
                  onRefresh: () async {
                    await model.getSquad;
                  },
                  child: Stack(
                    children: [
                      SizedBox(
                          child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Container(
                            width: double.infinity,
                            decoration: const BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(AppAssets.pitch),
                                    fit: BoxFit.cover)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    const Text(
                                      "Choose your starting players from the list",
                                      style: TextStyle(color: AppColors.white),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    SizedBox(
                                      height: context.heightPercent(0.2),
                                      width: context.widthPercent(0.9),
                                      child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        children: [
                                          ...?model.squad?.subs?.map((e) =>
                                              PlayerWidget(
                                                  onTap: () => model
                                                      .addToSquad(e.playerId),
                                                  name: "${e.playerName}",
                                                  imagePath: "${e.imagePath}"))
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                model.squad?.goalkeepers == null
                                    ? const SizedBox()
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          ...?model.squad?.goalkeepers
                                              ?.map((e) => Stack(
                                                    children: [
                                                      PlayerWidget(
                                                        onTap: () {},
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                        isCaptain:
                                                            e.isCaptain == 1
                                                                ? true
                                                                : false,
                                                        isViceCaptain:
                                                            e.isViceCaptain == 1
                                                                ? true
                                                                : false,
                                                      ),
                                                      Positioned(
                                                          right: 5,
                                                          top: 0,
                                                          child: IconButton(
                                                            onPressed: () =>
                                                                model.addToSquad(
                                                                    e.playerId),
                                                            icon: const Icon(
                                                              Icons.close,
                                                              size: 25,
                                                              color: AppColors
                                                                  .primaryOption3,
                                                            ),
                                                          )),
                                                    ],
                                                  ))
                                              .toList(),
                                        ],
                                      ),
                                model.squad?.defenders == null
                                    ? const SizedBox()
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          ...?model.squad?.defenders
                                              ?.map((e) => Stack(
                                                    children: [
                                                      PlayerWidget(
                                                        onTap: () {},
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                        isCaptain:
                                                            e.isCaptain == 1
                                                                ? true
                                                                : false,
                                                        isViceCaptain:
                                                            e.isViceCaptain == 1
                                                                ? true
                                                                : false,
                                                      ),
                                                      Positioned(
                                                          right: 5,
                                                          top: 0,
                                                          child: IconButton(
                                                            onPressed: () =>
                                                                model.addToSquad(
                                                                    e.playerId),
                                                            icon: const Icon(
                                                              Icons.close,
                                                              size: 25,
                                                              color: AppColors
                                                                  .primaryOption3,
                                                            ),
                                                          )),
                                                    ],
                                                  ))
                                              .toList(),
                                        ],
                                      ),
                                model.squad?.midfielders == null
                                    ? const SizedBox()
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          ...?model.squad?.midfielders
                                              ?.map((e) => Stack(
                                                    children: [
                                                      PlayerWidget(
                                                        onTap: () {},
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                        isCaptain:
                                                            e.isCaptain == 1
                                                                ? true
                                                                : false,
                                                        isViceCaptain:
                                                            e.isViceCaptain == 1
                                                                ? true
                                                                : false,
                                                      ),
                                                      Positioned(
                                                          right: 5,
                                                          top: 0,
                                                          child: IconButton(
                                                            onPressed: () =>
                                                                model.addToSquad(
                                                                    e.playerId),
                                                            icon: const Icon(
                                                              Icons.close,
                                                              size: 25,
                                                              color: AppColors
                                                                  .primaryOption3,
                                                            ),
                                                          )),
                                                    ],
                                                  ))
                                              .toList(),
                                        ],
                                      ),
                                model.squad?.forwards == null
                                    ? const SizedBox()
                                    : Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          ...?model.squad?.forwards
                                              ?.map((e) => Stack(
                                                    children: [
                                                      PlayerWidget(
                                                        onTap: () {},
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                        isCaptain:
                                                            e.isCaptain == 1
                                                                ? true
                                                                : false,
                                                        isViceCaptain:
                                                            e.isViceCaptain == 1
                                                                ? true
                                                                : false,
                                                      ),
                                                      Positioned(
                                                          right: 5,
                                                          top: 0,
                                                          child: IconButton(
                                                            onPressed: () =>
                                                                model.addToSquad(
                                                                    e.playerId),
                                                            icon: const Icon(
                                                              Icons.close,
                                                              size: 25,
                                                              color: AppColors
                                                                  .primaryOption3,
                                                            ),
                                                          )),
                                                    ],
                                                  ))
                                              .toList(),
                                        ],
                                      ),
                              ],
                            ),
                          ),
                        ],
                      )),
                      Positioned.fill(
                        child: model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : const SizedBox(),
                      ),
                    ],
                  ),
                ))));
  }
}
