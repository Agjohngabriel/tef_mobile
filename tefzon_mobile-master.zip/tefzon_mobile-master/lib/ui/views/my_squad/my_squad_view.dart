import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import '../../../helpers/constants/assets.dart';
import '../../../helpers/constants/colors.dart';
import '../../widgets/pitch.dart';
import '../../widgets/player_widget.dart';
import 'my_squad_viewmodel.dart';

class MySquad extends StatelessWidget {
  const MySquad({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder.reactive(
        viewModelBuilder: () => MySquadViewModel(),
        onModelReady: (model) => model.getSquad(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.primary,
              appBar: AppBar(
                title: const Text("My Squad"),
                elevation: 0,
                backgroundColor: Colors.deepPurpleAccent,
              ),
              body: Stack(
                children: [
                  OtherPitch(
                    goalKeepers: model.goalkeepers,
                    defender: model.defenders,
                    midFielders: model.midfielders,
                    forwards: model.forwards,
                    subs: model.subs,
                  ),
                  Positioned.fill(
                    child: model.isBusy
                        ? const Center(
                            child: SpinKitThreeBounce(
                            color: AppColors.primary,
                          ))
                        : const SizedBox(),
                  ),
                ],
              ),
            )));
  }
}
