import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/app_bar.dart';
import '../about_app/widgets/about_app_tile.dart';
import 'live_support_view_model.dart';

class LiveSupportView extends StatelessWidget {
  const LiveSupportView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LiveSupportViewModel>.nonReactive(
        viewModelBuilder: () => LiveSupportViewModel(),
        builder: (context, model, child) => Scaffold(
              backgroundColor: AppColors.white,
              appBar: const TefzonAppBar(
                text: "Live Support",
                useXIcon: false,
              ),
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 35,
                    ),
                    AboutAppTile(
                      title: 'I want to update my squad.',
                      onTap: () => model.goToQaView(),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    AboutAppTile(
                      title: 'I want to change my password.',
                      onTap: () {},
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    AboutAppTile(
                      title: 'I want to unsubscribe from the newsletter.',
                      onTap: () {},
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    AboutAppTile(
                      title: 'I have a question about how Tefzon works.',
                      onTap: () {},
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    AboutAppTile(
                      title: 'I want to unsubscribe from game e-mails.',
                      onTap: () {},
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    AboutAppTile(
                      title: 'I want to freeze my account temporarily',
                      onTap: () {},
                    ),
                  ],
                ),
              ),
            ));
  }
}
