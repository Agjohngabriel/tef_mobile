import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';

import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';

class LiveSupportViewModel extends BaseViewModel{
  final _router = locator<GoRouter>();

  void goToQaView() {
    _router.push(AppRoutes.qAViews);
  }

}