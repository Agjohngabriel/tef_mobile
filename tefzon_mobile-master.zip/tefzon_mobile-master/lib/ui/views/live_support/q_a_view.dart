import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_buttons.dart';
import 'live_support_view_model.dart';

class QAViews extends StatelessWidget {
  const QAViews({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LiveSupportViewModel>.nonReactive(
        viewModelBuilder: () => LiveSupportViewModel(),
        builder: (context, model, child) => Scaffold(
              backgroundColor: AppColors.white,
              appBar: const TefzonAppBar(
                text: "",
                useXIcon: false,
              ),
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 35,
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "I want to update Squad",
                        style: TextStyle(
                            color: AppColors.text60,
                            fontSize: 19,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    RichText(
                      text: const TextSpan(
                        text: 'Restaurants earn the ',
                        style: TextStyle(
                          fontSize: 16,
                          color: AppColors.textgrey,
                        ),
                        children: <InlineSpan>[
                          TextSpan(
                            text: 'Super Restaurant badge. ',
                            style: TextStyle(
                              fontSize: 16,
                              color: AppColors.text60,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          TextSpan(
                            text:
                                ' If they are recieving a lot of orders, have high customer ratings and low order cancellation rates.',
                            style: TextStyle(
                              fontSize: 16,
                              color: AppColors.textgrey,
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                            "Restaurants earn the Super Restaurant badge.")),
                    const SizedBox(
                      height: 25,
                    ),
                    RichText(
                      text: const TextSpan(
                        text: 'Restaurants earn',
                        style: TextStyle(
                          fontSize: 16,
                          color: AppColors.text60,
                        ),
                        children: <InlineSpan>[
                          TextSpan(
                            text:
                                ' the Super Restaurant badge. If they are recieving a lot of orders, have high customer ratings and low order cancellation rates.Restaurants earn the Super Restaurant badge. If they are recieving a lot of orders, have high customer ratings and low order cancellation rates.',
                            style: TextStyle(
                              fontSize: 16,
                              color: AppColors.textgrey,
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    const Center(
                      child: Text(
                        "Was this helpful?",
                        style: TextStyle(
                            color: AppColors.text60,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: CustomButton(
                          text: "No",
                          onTap: () {},
                          isFilled: false,
                          isPrimary: false,
                        )),
                        const SizedBox(
                          width: 15,
                        ),
                        Expanded(
                            child: CustomButton(
                          text: "Yes",
                          onTap: () {},
                          isFilled: true,
                          isPrimary: false,
                        )),
                      ],
                    )
                  ],
                ),
              ),
            ));
  }
}
