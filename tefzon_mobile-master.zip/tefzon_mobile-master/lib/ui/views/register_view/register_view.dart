import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/register_view/register_view.form.dart';
import 'package:tefzon_mobile/ui/views/register_view/register_viewmodel.dart';

import '../../../helpers/utils/custom_editing_controller.dart';
import '../../../helpers/utils/validator.dart';
import '../../widgets/custom_container.dart';

final country = List<StaticDropdownItem>;

@FormView(
  fields: [
    FormTextField(
      name: 'firstName',
    ),
    FormTextField(
      name: 'lastName',
    ),
    FormTextField(
      name: 'email',
      validator: FormValidators.emailValidator,
    ),
    FormTextField(
        name: 'userName',
        customTextEditingController:
            CustomEditingController.getCustomEditingController),
    FormTextField(
      name: 'password',
      validator: FormValidators.passwordValidator,
    ),
    FormTextField(
      name: 'phone',
    ),
    FormDateField(name: 'birthDate'),
    FormDropdownField(
      name: 'Gender',
      items: [
        StaticDropdownItem(
          title: 'Male',
          value: 'male',
        ),
        StaticDropdownItem(
          title: 'Female',
          value: 'female',
        ),
      ],
    ),
    FormDropdownField(
      name: 'Country',
      items: [
        StaticDropdownItem(
          title: 'Nigeria',
          value: 'nigeria',
        ),
        StaticDropdownItem(
          title: 'Nigeria',
          value: 'nigeria',
        ),
        StaticDropdownItem(
          title: 'Nigeria',
          value: 'nigeria',
        ),
      ],
    )
  ],
  autoTextFieldValidation: false,
)
class RegisterView extends StatelessWidget with $RegisterView {
  RegisterView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<RegisterViewModel>.reactive(
        viewModelBuilder: () => RegisterViewModel(),
        onModelReady: (model) {
          // #3: Listen to text updates by calling listenToFormUpdated(model);
          listenToFormUpdated(model);
          GenderValueToTitleMap.addAll({'others': 'Others'});
          model.setGender(GenderValueToTitleMap.keys.first);
        },
        builder: (context, model, child) => Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: AppColors.white,
              body: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: Form(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: context.heightPercent(0.12),
                        ),
                        Center(
                          child: Text(
                            "Sign up to start your journey",
                            style: TextStyle(
                                color: AppColors.primary,
                                letterSpacing: 0.4,
                                fontSize: context.widthPercent(
                                  0.04,
                                ),
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.06),
                        ),
                        TextField(
                          controller: firstNameController,
                          keyboardType: TextInputType.name,
                          decoration: InputDecoration(
                            hintText: "First Name",
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        TextField(
                          controller: lastNameController,
                          keyboardType: TextInputType.name,
                          decoration: InputDecoration(
                            hintText: "Last Name",
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            errorText: model.emailValidationMessage,
                            hintText: "Email Address",
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        TextField(
                          controller: userNameController,
                          keyboardType: TextInputType.name,
                          decoration: InputDecoration(
                            errorText: model.userNameValidationMessage,
                            hintText: "Username",
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        TextField(
                          controller: passwordController,
                          keyboardType: TextInputType.visiblePassword,
                          obscureText: model.isVisible,
                          decoration: InputDecoration(
                            hintText: "Choose Password",
                            suffixIcon: IconButton(
                              icon: Icon(
                                // Based on passwordVisible state choose the icon
                                model.isVisible
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: AppColors.primary,
                              ),
                              onPressed: model.toggleVisibility,
                            ),
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          decoration: InputDecoration(
                            errorText: model.phoneValidationMessage,
                            hintText: "Phone Number",
                            hintStyle: TextStyle(
                              color: AppColors.primary,
                              fontSize: context.widthPercent(0.04),
                              fontStyle: FontStyle.normal,
                              letterSpacing: 0.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        Row(
                          children: [
                            Expanded(
                                child: TextField(
                              keyboardType: TextInputType.datetime,
                              decoration: InputDecoration(
                                hintText: model.hasBirthDate
                                    ? model.birthDateValue.toString()
                                    : 'Select your Date of birth',
                                hintStyle: TextStyle(
                                  color: AppColors.primary,
                                  fontSize: context.widthPercent(0.04),
                                  fontStyle: FontStyle.normal,
                                  letterSpacing: 0.5,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              readOnly: true,
                              onTap: () => model.selectBirthDate(
                                  context: context,
                                  firstDate: DateTime(1950),
                                  initialDate: DateTime(2000),
                                  lastDate: DateTime(2003)),
                            )),
                            const SizedBox(
                              width: 9,
                            ),
                            Expanded(
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  border:
                                      Border(bottom: BorderSide(width: 0.5)),
                                ),
                                child: DropdownButton(
                                  dropdownColor:
                                      AppColors.backgroundGrey.withOpacity(0.9),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(6)),
                                  value: model.genderValue,
                                  onChanged: (value) {
                                    model.setGender(value!);
                                  },
                                  items: GenderValueToTitleMap.keys
                                      .map(
                                        (value) => DropdownMenuItem<String>(
                                          key: ValueKey('$value key'),
                                          value: value,
                                          child: Text(
                                              GenderValueToTitleMap[value]!),
                                        ),
                                      )
                                      .toList(),
                                  isExpanded: true,
                                  underline: const SizedBox(),
                                ),
                              ),
                              // CustomFormField(
                              //   controller: controller.genderController,
                              //   type: TextInputType.name,
                              //   text: "gender",
                              // ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: context.widthPercent(0.06),
                        ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(width: 0.5)),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 5),
                            child: DropdownButton(
                              hint: Text("select Country"),
                              dropdownColor:
                                  AppColors.backgroundGrey.withOpacity(0.9),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(6)),
                              value: model.countryValue,
                              onChanged: (value) {
                                print(CountryValueToTitleMap[value]);
                                model.setCountry(value!);
                              },
                              items: CountryValueToTitleMap.keys
                                  .map(
                                    (value) => DropdownMenuItem<String>(
                                      key: ValueKey('$value key'),
                                      value: value,
                                      child:
                                          Text(CountryValueToTitleMap[value]!),
                                    ),
                                  )
                                  .toList(),
                              isExpanded: true,
                              underline: const SizedBox(),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: context.widthPercent(0.06),
                        ),
                        model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : CustomContainer(
                                title: "Register",
                                function: model.showBasicDialog,
                              ),
                        SizedBox(
                          height: context.widthPercent(0.02),
                        ),
                        InkWell(
                          onTap: model.goToLogin,
                          child: Center(
                            child: Text(
                              "Already have an account? Login",
                              style: TextStyle(
                                  color: AppColors.primary,
                                  letterSpacing: 0.4,
                                  fontSize: context.widthPercent(
                                    0.04,
                                  ),
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
            ));
  }
}
