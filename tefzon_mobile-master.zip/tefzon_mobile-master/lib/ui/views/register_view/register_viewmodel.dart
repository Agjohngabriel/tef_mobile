import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import '../../../app/locator.dart';
import '../../../helpers/constants/app_keys.dart';
import '../../../helpers/constants/colors.dart';
import '../../../helpers/constants/routes.dart';
import '../../../services/core_services/auth_service.dart';
import '../../../services/core_services/shared_storage.dart';
import 'register_view.form.dart';

class RegisterViewModel extends FormViewModel {
  final _router = locator<GoRouter>();
  final _auth = locator<AuthService>();
  final _sharedStorage = locator<SharedStorage>();
  bool isVisible = false;

  void toggleVisibility() {
    isVisible ? isVisible = false : isVisible = true;
    notifyListeners();
  }

  void goToLogin() {
    _router.push(AppRoutes.login);
  }

  @override
  void setFormStatus() {
    // log.i('Set form Status with data: $formValueMap');

    if (hasPasswordValidationMessage) {
      setValidationMessage('Error in the form, please check again');
    }
  }

  Future showBasicDialog() async {
    await OneContext().dialog.showDialog(
      builder: (BuildContext context) {
        bool? terms1 = false;
        bool? terms2 = false;
        return StatefulBuilder(builder: (context, setState) {
          return Scaffold(
              backgroundColor: AppColors.white,
              body: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: ListView(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          onPressed: () => OneContext().dialog.popDialog(),
                          icon: const Icon(
                            Icons.close,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        "Newsletter",
                        style: TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w700,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                          "This apartment is an inviting choice. Created as a space to spend time in, there's extra room in the open-plan living area, allowing guests to stretch out; whether relaxing on the sofa or enjoying the kitchen. The bedroom and bathroom are also spacious, and continue the sense of warm yet contemporary design, with touches of colour. This apartment is an inviting choice. Created as a space to spend time in, there's extra room in the open-plan living area, allowing guests to stretch out; whether relaxing on the sofa or enjoying the kitchen. "),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Checkbox(
                              value: terms1,
                              onChanged: (checked) {
                                setState(() {
                                  terms1 = checked;
                                });
                              }),
                          const SizedBox(
                            width: 10,
                          ),
                          const Text("I agree to receive football related news")
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        "Privacy Policy",
                        style: TextStyle(
                            color: AppColors.primary,
                            fontWeight: FontWeight.w700,
                            fontSize: 18),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                          "This apartment is an inviting choice. Created as a space to spend time in, there's extra room in the open-plan living area, allowing guests to stretch out; whether relaxing on the sofa or enjoying the kitchen. The bedroom and bathroom are also spacious, and continue the sense of warm yet contemporary design, with touches of colour. This apartment is an inviting choice. Created as a space to spend time in, there's extra room in the open-plan living area, allowing guests to stretch out; whether relaxing on the sofa or enjoying the kitchen. "),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Checkbox(
                              value: terms2,
                              onChanged: (checked) {
                                setState(() {
                                  terms2 = checked;
                                });
                              }),
                          const SizedBox(
                            width: 10,
                          ),
                          const Text("I agree to receive football related news")
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      GestureDetector(
                        onTap: () {
                          if (terms2 == true) {
                            OneContext().dialog.popDialog();
                            saveData();
                          } else {
                            Fluttertoast.showToast(
                                msg: "You need to accept privacy policy",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.CENTER,
                                timeInSecForIosWeb: 1,
                                backgroundColor: Colors.red,
                                textColor: Colors.white,
                                fontSize: 16.0);
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: const BoxDecoration(
                              color: AppColors.primary,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(7))),
                          child: const Center(
                            child: Text(
                              "Register",
                              style: TextStyle(color: AppColors.white),
                            ),
                          ),
                        ),
                      )
                    ],
                  )));
        });
      }, // DialogPlatform.Material
    );
  }

  Future saveData() async {
    final result = await runBusyFuture(_auth.register({
      "email": emailValue,
      "password": passwordValue,
      "username": userNameValue,
      "first_name": firstNameValue,
      "last_name": lastNameValue,
      "gender": genderValue,
      "country": countryValue,
      "dob": birthDateValue.toString(),
    }));
    if (result.isSuccess) {
      _sharedStorage.saveToDisk(AppKeys.LoggedInKey, true);
      _router.go(AppRoutes.favouritesLeagues);
    } else if (result.statsCode == 422) {
      var e = jsonDecode(result.message);
      if (result.message.contains("errors")) {
        if (e["errors"]["email"] != null) {
          setEmailValidationMessage(e["errors"]["email"][0]);
        }
        if (e["errors"]["username"] != null) {
          setUserNameValidationMessage(e["errors"]["username"][0]);
        }
        if (e["errors"]["phone"] != null) {
          setPhoneValidationMessage(e["errors"]["phone"][0]);
        }
      }
      if (result.message.contains("message")) {
        setPasswordValidationMessage(e["message"]);
        if (kDebugMode) {
          print(passwordValidationMessage);
        }
      }
    }
  }

  void checkStatus() {}
}
