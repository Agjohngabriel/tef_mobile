import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/ui/views/support_request/support_request_viewmodel.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/app_bar.dart';


class SupportRequestView extends StatelessWidget {
  const SupportRequestView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SupportRequestViewModel>.nonReactive(
        viewModelBuilder: () => SupportRequestViewModel(),
        builder: (context, model, child) => Scaffold(
              backgroundColor: AppColors.white,
              appBar: const TefzonAppBar(
                text: "Live Support",
                useXIcon: false,
              ),
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        "All Clear!",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text("you have no recent requests"),
                    ],
                  ),
                ),
              ),
            ));
  }
}
