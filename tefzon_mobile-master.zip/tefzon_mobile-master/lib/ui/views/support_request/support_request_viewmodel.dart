import 'package:stacked/stacked.dart';

class SupportRequestViewModel extends BaseViewModel {}
