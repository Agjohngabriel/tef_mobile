import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:tefzon_mobile/ui/views/favourites/favourites_viewmodel.dart';
import 'package:tefzon_mobile/ui/widgets/custom_container.dart';

import '../../../model/league.dart';

class FavouritesView extends StatelessWidget {
  const FavouritesView({Key? key, required this.leagues}) : super(key: key);
  final Leagues leagues;

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<FavouritesViewModel>.reactive(
        viewModelBuilder: () =>
            FavouritesViewModel(id: '${leagues.currentSeasonId}'),
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColors.backgroundGrey,
            appBar: AppBar(
              leading: IconButton(
                onPressed: model.goBack,
                icon: Icon(
                  Icons.arrow_back_outlined,
                  color: AppColors.white,
                ),
              ),
              title: const Text(
                "Select Favourite Team",
                style: TextStyle(color: AppColors.white),
              ),
              centerTitle: true,
              elevation: 0,
            ),
            body: model.hasError
                ? Container(
                    color: Colors.red,
                    alignment: Alignment.center,
                    child: const Text(
                      'An error has occered while running the future',
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : Stack(children: [
                    ListView(
                      children: [
                        const Text(
                            "Please type carefully and fill out the form with your personal details. You can’t edit these details once you submitted the form."),
                        const SizedBox(
                          height: 20,
                        ),
                        model.isBusy
                            ? const Center(child: CircularProgressIndicator())
                            : SizedBox(
                                height: context.heightPercent(0.75),
                                width: 400,
                                child: GridView.builder(
                                  physics:
                                      const AlwaysScrollableScrollPhysics(),
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 4,
                                    childAspectRatio: 3 / 5,
                                  ),
                                  itemCount: model.data?.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    String word = "${model.data![index].name}";
                                    return InkWell(
                                      onTap: () => model.update(word),
                                      child: Stack(
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.all(10),
                                            alignment: Alignment.center,
                                            child: Column(
                                              children: [
                                                Image.network(
                                                  "${model.data![index].logoPath}",
                                                  scale: 3,
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  word,
                                                  overflow: TextOverflow.clip,
                                                )
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                              right: 0,
                                              top: 0,
                                              child: Icon(
                                                model.isSaved(word) == true
                                                    ? Icons.favorite
                                                    : Icons.favorite_border,
                                                color:
                                                    model.isSaved(word) == true
                                                        ? AppColors.primary
                                                        : null,
                                              ))
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              )
                      ],
                    ),
                    Positioned(
                        bottom: 10,
                        right: 10,
                        left: 10,
                        child: model.isBusy
                            ? const SizedBox()
                            : CustomContainer(
                                title: "Proceed", function: model.gotoTerms))
                  ])));
  }
}
