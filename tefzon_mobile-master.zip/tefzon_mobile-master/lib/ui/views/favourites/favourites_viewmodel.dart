import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';
import 'package:tefzon_mobile/model/favourite_league.dart';

import '../../../services/api.dart';

class FavouritesViewModel extends FutureViewModel<List<Favourite>> {
  final String id;
  FavouritesViewModel({required this.id});
  final _router = locator<GoRouter>();
  Set<String> saveFav = <String>{};

  bool isSaved(word) {
    return saveFav.contains(word);
  }

  void update(word) {
    if (isSaved(word)) {
      saveFav.remove(word);
    } else {
      saveFav.add(word);
    }
    notifyListeners();
  }

  void goBack() {
    _router.pop();
  }

  void gotoTerms() {
    _router.go(AppRoutes.selectSqaud);
  }

  @override
  void onError(error) {}

  @override
  Future<List<Favourite>> futureToRun() => locator<Api>().getTeams(id);
}
