import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/text_theme.dart';
import 'package:tefzon_mobile/ui/views/dashboard/dashboard_viewmodel.dart';

import '../../widgets/fixture_widget.dart';
import '../../widgets/heading_item.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    return ViewModelBuilder<DashboardViewModel>.reactive(
        viewModelBuilder: () => DashboardViewModel(),
        onModelReady: (model) => model.fetchFixture(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.backgroundGrey,
              appBar: AppBar(
                backgroundColor: AppColors.backgroundGrey,
                automaticallyImplyLeading: false,
                centerTitle: true,
                title: Text(
                  "Tefzon",
                  style: context.textTheme.headline5?.copyWith(
                      color: AppColors.primary, fontWeight: FontWeight.bold),
                ),
                // SizedBox(
                //   height: 45,
                //   child: ListView(
                //     scrollDirection: Axis.horizontal,
                //     children: [
                //       TopNav(title: "Fixtures", isActive: true,),
                //       TopNav(title: "Transfer"),
                //       TopNav(title: "Rewards"),
                //       TopNav(title: "Profile"),
                //     ],
                //   ),
                // ),
                leadingWidth: 0,
              ),
              body: ListView(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    decoration: const BoxDecoration(
                        color: AppColors.backgroundGrey,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                    child: Column(
                      children: [
                        HeadingItems(
                          title: "Fixtures",
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            child: Center(
                              child: Text(
                                  "Gameweek ${model.fixture.length} - ${DateFormat('EEE d MMM').format(
                                DateTime.parse(model.fixture.isEmpty
                                    ? DateTime.now().toString()
                                    : model.fixture.last.date_time!),
                              )} ${DateFormat('hh:mm').format(
                                DateTime.parse(model.fixture.isEmpty
                                    ? DateTime.now().toString()
                                    : model.fixture.last.date_time!),
                              )}"),
                            )),
                        //checker for loading state

                        model.isBusy
                            ? const Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : model.fixture.isEmpty
                                ? const SizedBox()
                                : Container(
                                    height: height * 0.4,
                                    width: width,
                                    child: ListView.separated(
                                        itemBuilder:
                                            (BuildContext context, index) {
                                          return FixtureGameWidget(
                                            model: model.fixture.reversed
                                                .toList()[index],
                                            index: index,
                                            fixList: model.fixture,
                                          );
                                        },
                                        separatorBuilder:
                                            (BuildContext context, index) {
                                          return const Divider(
                                            thickness: 1,
                                            color: AppColors.grey,
                                          );
                                        },
                                        itemCount: 5),
                                  ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 15),
                    decoration: BoxDecoration(
                        color: AppColors.lightBlue,
                        gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [AppColors.white, AppColors.lightBlue]),
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Entry History",
                          style: TextStyle(
                              color: AppColors.blue,
                              fontSize: 18,
                              fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text(
                          "This Season",
                          style: TextStyle(
                              color: AppColors.blue,
                              fontSize: 16,
                              fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Table(
                          columnWidths: const {
                            0: FractionColumnWidth(.15),
                            1: FractionColumnWidth(.10),
                            2: FractionColumnWidth(.10),
                            3: FractionColumnWidth(.20),
                            4: FractionColumnWidth(.10),
                            5: FractionColumnWidth(.07),
                            6: FractionColumnWidth(.07),
                            7: FractionColumnWidth(.15),
                            8: FractionColumnWidth(.05),
                            9: FractionColumnWidth(.05),
                          },
                          defaultVerticalAlignment:
                              TableCellVerticalAlignment.middle,
                          children: [
                            const TableRow(
                              decoration: BoxDecoration(color: AppColors.grey),
                              children: <Widget>[
                                Text("GW"),
                                Text("GP"),
                                Text("PB"),
                                Text("GR"),
                                Text("TM"),
                                Text("TC"),
                                Text("OP"),
                                Text("OR"),
                                Text("@"),
                                Text("#")
                              ],
                            ),
                            buildTableRow(),
                            buildTableRow(),
                            buildTableRow(),
                          ],
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 15),
                    decoration: BoxDecoration(
                        color: AppColors.lightBlue,
                        gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [AppColors.white, AppColors.lightBlue]),
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [HeadingItems(title: "League 1842965")],
                    ),
                  )
                ],
              ),
            )));
  }

  TableRow buildTableRow() {
    return const TableRow(
      children: <Widget>[
        Text("GW24"),
        Text("62"),
        Text("5"),
        Text("3,934,456"),
        Text("0"),
        Text("0"),
        Text("0"),
        Text("0"),
        Text("0"),
        Icon(
          Icons.arrow_drop_down,
          color: AppColors.primary,
        )
      ],
    );
  }
}
