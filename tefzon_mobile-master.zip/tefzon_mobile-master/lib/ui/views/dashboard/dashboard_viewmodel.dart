import 'dart:convert';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/model/fixture/livematch2.dart';
import 'package:tefzon_mobile/model/fixture/new_fixture.dart';
import 'package:tefzon_mobile/services/api.dart';

class DashboardViewModel extends FutureViewModel<List<NewFixture>> {
  final _api = locator<Api>();
  final _router = locator<GoRouter>();
  int index = 0;
  var fixture = <NewFixture>[];

  Future<List<NewFixture>> fetchFixture() async {
    setBusy(true);
    fixture = <NewFixture>[];
    var response = await _api.fetchFixtures("get-fixtures-by-date");

    var responseData = json.decode(response.body) as List<dynamic>;

    for (Map fix in responseData) {
      print(fix["visitorTeam"]['data']["logo_path"]);
      NewFixture fixtureData = NewFixture(
        round_id: fix["round_id"],
        date_time: fix['time']['starting_at']["date_time"],
        localTeam: fix["localTeam"]['data']['name'],
        localTeamLogo: fix["localTeam"]['data']["logo_path"],
        visitorTeam: fix["visitorTeam"]['data']['name'],
        visitorTeamLogo: fix["visitorTeam"]['data']["logo_path"],
      );

      fixture.add(fixtureData);
      // fixture.add(Fixture.fromJson(leaguw));
    }
    setBusy(false);
    print("loading fixtures");
    return fixture;
  }

  // void createLeague() {
  //   _router.push(AppRoutes.createLeague);
  // }

  @override
  Future<List<NewFixture>> futureToRun() => fetchFixture();
}
