import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/select_captain/select_captain_viewmodel.dart';

import '../../../helpers/constants/assets.dart';
import '../../../helpers/constants/colors.dart';
import '../../widgets/player_widget.dart';

class SelectCaptain extends StatelessWidget {
  const SelectCaptain({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SelectCaptainViewModel>.reactive(
        viewModelBuilder: () => SelectCaptainViewModel(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
                backgroundColor: AppColors.primary,
                appBar: AppBar(
                  title: const Text("Choose Captain"),
                  elevation: 0,
                  backgroundColor: Colors.deepPurpleAccent,
                ),
                floatingActionButton: IconButton(
                  onPressed: model.selectViceCaptain,
                  icon: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: const BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.all(Radius.circular(15))),
                    child: const Icon(
                      Icons.arrow_forward,
                      color: AppColors.primary,
                    ),
                  ),
                ),
                body: Stack(
                  children: [
                    SizedBox(
                        child: Stack(
                      alignment: Alignment.topCenter,
                      children: [
                        Container(
                          width: double.infinity,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(AppAssets.pitch),
                                  fit: BoxFit.cover)),
                        ),
                        const Positioned(
                            top: 20,
                            left: 10,
                            child: Text(
                              "Pick any player to assign Captain",
                              style: TextStyle(color: AppColors.white),
                            )),
                        model.squad?.goalkeepers == null
                            ? const SizedBox()
                            : Positioned(
                                top: context.heightPercent(0.18),
                                child: Row(
                                  children: [
                                    ...?model.squad?.goalkeepers
                                        ?.map((e) => InkWell(
                                              onTap: () =>
                                                  model.makeCaptain(e.id),
                                              child: e.isCaptain == 1
                                                  ? Container(
                                                      decoration: const BoxDecoration(
                                                          color:
                                                              AppColors.primary,
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          16))),
                                                      padding:
                                                          const EdgeInsets.all(
                                                              3),
                                                      child: PlayerWidget(
                                                        onTap: (){

                                                        },
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                      ),
                                                    )
                                                  : PlayerWidget(
                                                onTap: (){

                                                },
                                                      name: "${e.playerName}",
                                                      imagePath:
                                                          "${e.imagePath}",
                                                    ),
                                            ))
                                        .toList(),
                                  ],
                                )),
                        model.squad?.defenders == null
                            ? const SizedBox()
                            : Positioned(
                                top: context.heightPercent(0.29),
                                child: Row(
                                  children: [
                                    ...?model.squad?.defenders
                                        ?.map((e) => InkWell(
                                              onTap: () =>
                                                  model.makeCaptain(e.id),
                                              child: e.isCaptain == 1
                                                  ? Container(
                                                      decoration: const BoxDecoration(
                                                          color:
                                                              AppColors.primary,
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          16))),
                                                      padding:
                                                          const EdgeInsets.all(
                                                              3),
                                                      child: PlayerWidget(
                                                        onTap: (){

                                                        },
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                      ),
                                                    )
                                                  : PlayerWidget(
                                                onTap: (){

                                                },
                                                      name: "${e.playerName}",
                                                      imagePath:
                                                          "${e.imagePath}",
                                                    ),
                                            ))
                                        .toList(),
                                  ],
                                )),
                        model.squad?.midfielders == null
                            ? const SizedBox()
                            : Positioned(
                                top: context.heightPercent(0.39),
                                child: Row(
                                  children: [
                                    ...?model.squad?.midfielders
                                        ?.map((e) => InkWell(
                                              onTap: () =>
                                                  model.makeCaptain(e.id),
                                              child: e.isCaptain == 1
                                                  ? Container(
                                                      decoration: const BoxDecoration(
                                                          color:
                                                              AppColors.primary,
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          16))),
                                                      padding:
                                                          const EdgeInsets.all(
                                                              3),
                                                      child: PlayerWidget(
                                                        onTap: (){

                                                        },
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                      ),
                                                    )
                                                  : PlayerWidget(
                                                onTap: (){

                                                },
                                                      name: "${e.playerName}",
                                                      imagePath:
                                                          "${e.imagePath}",
                                                    ),
                                            ))
                                        .toList(),
                                  ],
                                )),
                        model.squad?.forwards == null
                            ? const SizedBox()
                            : Positioned(
                                top: context.heightPercent(0.49),
                                child: Row(
                                  children: [
                                    ...?model.squad?.forwards
                                        ?.map((e) => InkWell(
                                              onTap: () =>
                                                  model.makeCaptain(e.id),
                                              child: e.isCaptain == 1
                                                  ? Container(
                                                      decoration: const BoxDecoration(
                                                          color:
                                                              AppColors.primary,
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          16))),
                                                      padding:
                                                          const EdgeInsets.all(
                                                              3),
                                                      child: PlayerWidget(
                                                        onTap: (){

                                                        },
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                      ),
                                                    )
                                                  : PlayerWidget(
                                                onTap: (){

                                                },
                                                      name: "${e.playerName}",
                                                      imagePath:
                                                          "${e.imagePath}",
                                                    ),
                                            ))
                                        .toList(),
                                  ],
                                )),
                        model.squad?.subs == null
                            ? const SizedBox()
                            : Positioned(
                                top: context.heightPercent(0.59),
                                child: Row(
                                  children: [
                                    ...?model.squad?.subs
                                        ?.map((e) => InkWell(
                                              onTap: () =>
                                                  model.makeCaptain(e.id),
                                              child: e.isCaptain == 1
                                                  ? Container(
                                                      decoration: const BoxDecoration(
                                                          color:
                                                              AppColors.primary,
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          16))),
                                                      padding:
                                                          const EdgeInsets.all(
                                                              3),
                                                      child: PlayerWidget(
                                                        onTap: (){

                                                        },
                                                        name: "${e.playerName}",
                                                        imagePath:
                                                            "${e.imagePath}",
                                                      ),
                                                    )
                                                  : PlayerWidget(
                                                onTap: (){

                                                },
                                                      name: "${e.playerName}",
                                                      imagePath:
                                                          "${e.imagePath}",
                                                    ),
                                            ))
                                        .toList(),
                                  ],
                                )),
                      ],
                    )),
                    Positioned(
                      top: 50,
                      left: 10,
                      child: model.isBusy
                          ? const Center(
                              child: SpinKitThreeBounce(
                              color: AppColors.primary,
                            ))
                          : const SizedBox(),
                    ),
                  ],
                ))));
  }
}
