import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/material.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';

import '../../../model/squad.dart';
import '../../../services/api.dart';
import '../../../services/core_services/squad_service.dart';

class SelectCaptainViewModel extends ReactiveViewModel {
  final _api = locator<Api>();
  final SquadService _squadService = locator<SquadService>();

  Squad? squad;

  void makeCaptain(int? id) async {
    setBusy(true);
    await _api.getData("select/captain/$id").then((value) {
      if (value.statusCode == 200) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
  }

  void selectViceCaptain() {
    locator<GoRouter>().push(AppRoutes.chooseViceCaptain);
  }

  @override
  List<ReactiveServiceMixin> get reactiveServices => [_squadService];
}
