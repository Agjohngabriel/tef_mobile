import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';

import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';

class SupportViewModel extends BaseViewModel {
  final _router = locator<GoRouter>();

  void goToLiveSupportView() {
    _router.push(AppRoutes.supports);
  }

  void goToFaqView() {
    _router.push(AppRoutes.liveSupportFaq);
  }

  void goToPaymentSupportView() {
    _router.push(AppRoutes.onlinePaymentHelpDesk);
  }

  void goToSupportRequestView() {
    _router.push(AppRoutes.supportRequestHelpDesk);
  }

  void goToOrderSupportView() {
    _router.push(AppRoutes.orderSupportHelpDesk);
  }
}
