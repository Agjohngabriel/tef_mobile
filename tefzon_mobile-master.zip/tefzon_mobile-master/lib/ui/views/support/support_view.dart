import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/ui/views/support/support_view_model.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/custom_tile.dart';

class SupportView extends StatelessWidget {
  const SupportView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SupportViewModel>.nonReactive(
        viewModelBuilder: () => SupportViewModel(),
        builder: (context, model, child) => Scaffold(
              appBar: AppBar(
                centerTitle: true,
                title: RichText(
                  text: const TextSpan(
                    text: 'Tef',
                    style: TextStyle(
                      fontSize: 20,
                      color: AppColors.white,
                      fontWeight: FontWeight.w700,
                    ),
                    children: <InlineSpan>[
                      TextSpan(
                        text: 'zon',
                        style: TextStyle(
                          fontSize: 20,
                          color: AppColors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      )
                    ],
                  ),
                ),
                elevation: 0,
                backgroundColor: AppColors.primary,
                actionsIconTheme: const IconThemeData(color: Colors.black),
              ),
              body: Padding(
                padding: const EdgeInsets.all(15.0),
                child: ListView(
                  children: [
                    const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Live Support",
                          style: TextStyle(
                              color: AppColors.text60,
                              fontWeight: FontWeight.w700),
                        )),
                    const SizedBox(
                      height: 40,
                    ),
                    const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "How can we help you?",
                          style: TextStyle(
                              color: AppColors.primary,
                              fontWeight: FontWeight.w700),
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    CustomMenuTile(
                      onTap: model.goToPaymentSupportView,
                      leading: const Icon(Icons.monetization_on_outlined),
                      title: "Payments",
                    ),
                    CustomMenuTile(
                      onTap: model.goToSupportRequestView,
                      leading: const Center(child: Icon(Icons.support)),
                      title: "My Support Requests",
                    ),
                    CustomMenuTile(
                      onTap: model.goToFaqView,
                      leading: const Center(child: Icon(Icons.question_answer)),
                      title: "Frequently Asked Question",
                    ),
                  ],
                ),
              ),
            ));
  }
}
