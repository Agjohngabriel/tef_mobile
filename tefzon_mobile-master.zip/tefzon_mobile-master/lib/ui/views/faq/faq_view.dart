import 'package:flutter/material.dart';

import '../../../helpers/constants/colors.dart';

class FaqView extends StatelessWidget {
  const FaqView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        child: Scaffold(
          backgroundColor: AppColors.white,
          appBar: AppBar(
            title: const Text("FAQ"),
          ),
          body: const Padding(
            padding: EdgeInsets.only(left: 30, right: 30, top: 40),
            child: Text(
                "On the date 25.03.2021 before noon, we have detected a data breach into yemeksepeti user database by unidentified cyber attackers. The attackers managed to copy some info of Yemeksepeti users accounts.",
                style: TextStyle(
                    fontSize: 16, color: AppColors.text50, letterSpacing: 0.6)),
          ),
        ));
  }
}
