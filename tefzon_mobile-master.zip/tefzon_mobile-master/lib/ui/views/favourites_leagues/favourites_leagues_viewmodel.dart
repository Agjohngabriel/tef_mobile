import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';

import '../../../model/league.dart';
import '../../../services/api.dart';

class FavouritesLeaguesViewModel extends FutureViewModel<List<Leagues>> {
  final _router = locator<GoRouter>();
  void goBack() {
    _router.pop();
  }

  void gotoTeams(Leagues league) {
    _router.push(AppRoutes.favourites, extra: league);
  }

  @override
  void onError(error) {}

  @override
  Future<List<Leagues>> futureToRun() => locator<Api>().getleagues();
}
