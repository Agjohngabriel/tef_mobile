import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';

import 'favourites_leagues_viewmodel.dart';

class FavouritesLeaguesView extends StatelessWidget {
  const FavouritesLeaguesView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<FavouritesLeaguesViewModel>.reactive(
        viewModelBuilder: () => FavouritesLeaguesViewModel(),
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColors.backgroundGrey,
            appBar: AppBar(
              title: const Text(
                "Select Favourite Leagues",
                style: TextStyle(color: AppColors.white),
              ),
              centerTitle: true,
              elevation: 0,
            ),
            body: model.hasError
                ? Container(
                    color: Colors.red,
                    alignment: Alignment.center,
                    child: const Text(
                      'An error has occered while running the future',
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : Stack(children: [
                    ListView(
                      children: [
                        const SizedBox(
                          height: 20,
                        ),
                        model.isBusy
                            ? Center(
                                child: SpinKitThreeBounce(
                                color: AppColors.primary,
                              ))
                            : SizedBox(
                                height: context.heightPercent(0.75),
                                width: 400,
                                child: GridView.builder(
                                  physics:
                                      const AlwaysScrollableScrollPhysics(),
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 4,
                                    childAspectRatio: 3 / 5,
                                  ),
                                  itemCount: model.data?.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    String word = "${model.data![index].name}";
                                    return InkWell(
                                      onTap: () =>
                                          model.gotoTeams(model.data![index]),
                                      child: Container(
                                        padding: const EdgeInsets.all(10),
                                        alignment: Alignment.center,
                                        child: Column(
                                          children: [
                                            Expanded(
                                              child: Image.network(
                                                "${model.data![index].logoPath}",
                                                scale: 3,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              word,
                                              overflow: TextOverflow.clip,
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              )
                      ],
                    ),
                  ])));
  }
}
