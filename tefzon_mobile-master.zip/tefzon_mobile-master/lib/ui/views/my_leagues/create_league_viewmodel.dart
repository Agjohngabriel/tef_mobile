import 'dart:convert';

import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';
import '../../../services/api.dart';
import 'create_league_view.form.dart';
import 'package:flutter/material.dart';

class CreateLeagueViewModel extends FormViewModel {
  final _api = locator<Api>();
  final _router = locator<GoRouter>();
  @override
  void setFormStatus() {
    // TODO: implement setFormStatus
  }

  Future saveData() async {
    setBusy(true);
    await _api.postData("leagues", {
      "name": nameValue,
      "participants": participantsValue,
      "type": typeValue,
      "duration": durationValue,
      "start": startValue.toString(),
      "end": endValue.toString(),
      "entry_fee": entryFeeValue,
      "winner_type": winnerTypeValue,
      "entry_type": entryTypeValue,
    }).then((value) {
      print(value.body);
      print(value.statusCode);
      if (value.statusCode == 200) {
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext).pop();
                        _router.go(AppRoutes.home); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      } else if (value.statusCode == 422) {
        var e = jsonDecode(value.body);
        if (value.body.contains("errors")) {
          if (e["errors"]["name"] != null) {
            setNameValidationMessage(e["errors"]["name"][0]);
          }
          if (e["errors"]["participants"] != null) {
            setParticipantsValidationMessage(e["errors"]["participants"][0]);
          }
        }
      } else if (value.statusCode == 405) {
        if (value.body.contains("message")) {
          setEntryFeeValidationMessage(jsonDecode(value.body)["message"]);
        }
      }
    });
    setBusy(false);
  }
}
