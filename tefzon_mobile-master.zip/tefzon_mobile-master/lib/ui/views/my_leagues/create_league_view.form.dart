// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// StackedFormGenerator
// **************************************************************************

// ignore_for_file: public_member_api_docs,  constant_identifier_names, non_constant_identifier_names,unnecessary_this

import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

const String NameValueKey = 'name';
const String ParticipantsValueKey = 'participants';
const String EntryFeeValueKey = 'entryFee';
const String StartValueKey = 'start';
const String EndValueKey = 'end';
const String TypeValueKey = 'type';
const String WinnerTypeValueKey = 'winnerType';
const String EntryTypeValueKey = 'entryType';
const String DurationValueKey = 'duration';

final Map<String, String> TypeValueToTitleMap = {
  'public': 'Public',
  'private': 'Private',
};
final Map<String, String> WinnerTypeValueToTitleMap = {
  'single': 'Single',
  'double': 'Double',
};
final Map<String, String> EntryTypeValueToTitleMap = {
  'paid': 'Paid',
  'free': 'Free',
};
final Map<String, String> DurationValueToTitleMap = {
  'daily': 'Daily',
  'weekly': 'Weekly',
  'monthly': 'Monthly',
};

final Map<String, TextEditingController> _CreateLeagueTextEditingControllers =
    {};

final Map<String, FocusNode> _CreateLeagueFocusNodes = {};

final Map<String, String? Function(String?)?> _CreateLeagueTextValidations = {
  NameValueKey: null,
  ParticipantsValueKey: null,
  EntryFeeValueKey: null,
};

mixin $CreateLeague on StatelessWidget {
  TextEditingController get nameController =>
      _getFormTextEditingController(NameValueKey);
  TextEditingController get participantsController =>
      _getFormTextEditingController(ParticipantsValueKey);
  TextEditingController get entry_feeController =>
      _getFormTextEditingController(EntryFeeValueKey);
  FocusNode get nameFocusNode => _getFormFocusNode(NameValueKey);
  FocusNode get participantsFocusNode =>
      _getFormFocusNode(ParticipantsValueKey);
  FocusNode get entry_feeFocusNode => _getFormFocusNode(EntryFeeValueKey);

  TextEditingController _getFormTextEditingController(String key,
      {String? initialValue}) {
    if (_CreateLeagueTextEditingControllers.containsKey(key)) {
      return _CreateLeagueTextEditingControllers[key]!;
    }
    _CreateLeagueTextEditingControllers[key] =
        TextEditingController(text: initialValue);
    return _CreateLeagueTextEditingControllers[key]!;
  }

  FocusNode _getFormFocusNode(String key) {
    if (_CreateLeagueFocusNodes.containsKey(key)) {
      return _CreateLeagueFocusNodes[key]!;
    }
    _CreateLeagueFocusNodes[key] = FocusNode();
    return _CreateLeagueFocusNodes[key]!;
  }

  /// Registers a listener on every generated controller that calls [model.setData()]
  /// with the latest textController values
  void listenToFormUpdated(FormViewModel model) {
    nameController.addListener(() => _updateFormData(model));
    participantsController.addListener(() => _updateFormData(model));
    entry_feeController.addListener(() => _updateFormData(model));
  }

  final bool _autoTextFieldValidation = false;
  bool validateFormFields(FormViewModel model) {
    _updateFormData(model, forceValidate: true);
    return model.isFormValid;
  }

  /// Updates the formData on the FormViewModel
  void _updateFormData(FormViewModel model, {bool forceValidate = false}) {
    model.setData(
      model.formValueMap
        ..addAll({
          NameValueKey: nameController.text,
          ParticipantsValueKey: participantsController.text,
          EntryFeeValueKey: entry_feeController.text,
        }),
    );
    if (_autoTextFieldValidation || forceValidate) {
      _updateValidationData(model);
    }
  }

  /// Updates the fieldsValidationMessages on the FormViewModel
  void _updateValidationData(FormViewModel model) =>
      model.setValidationMessages({
        NameValueKey: _getValidationMessage(NameValueKey),
        ParticipantsValueKey: _getValidationMessage(ParticipantsValueKey),
        EntryFeeValueKey: _getValidationMessage(EntryFeeValueKey),
      });

  /// Returns the validation message for the given key
  String? _getValidationMessage(String key) {
    final validatorForKey = _CreateLeagueTextValidations[key];
    if (validatorForKey == null) return null;
    String? validationMessageForKey =
        validatorForKey(_CreateLeagueTextEditingControllers[key]!.text);
    return validationMessageForKey;
  }

  /// Calls dispose on all the generated controllers and focus nodes
  void disposeForm() {
    // The dispose function for a TextEditingController sets all listeners to null

    for (var controller in _CreateLeagueTextEditingControllers.values) {
      controller.dispose();
    }
    for (var focusNode in _CreateLeagueFocusNodes.values) {
      focusNode.dispose();
    }

    _CreateLeagueTextEditingControllers.clear();
    _CreateLeagueFocusNodes.clear();
  }
}

extension ValueProperties on FormViewModel {
  bool get isFormValid =>
      this.fieldsValidationMessages.values.every((element) => element == null);
  String? get nameValue => this.formValueMap[NameValueKey] as String?;
  String? get participantsValue =>
      this.formValueMap[ParticipantsValueKey] as String?;
  String? get entryFeeValue => this.formValueMap[EntryFeeValueKey] as String?;
  DateTime? get startValue => this.formValueMap[StartValueKey] as DateTime?;
  DateTime? get endValue => this.formValueMap[EndValueKey] as DateTime?;
  String? get typeValue => this.formValueMap[TypeValueKey] as String?;
  String? get winnerTypeValue =>
      this.formValueMap[WinnerTypeValueKey] as String?;
  String? get entryTypeValue => this.formValueMap[EntryTypeValueKey] as String?;
  String? get durationValue => this.formValueMap[DurationValueKey] as String?;

  bool get hasName => this.formValueMap.containsKey(NameValueKey);
  bool get hasParticipants =>
      this.formValueMap.containsKey(ParticipantsValueKey);
  bool get hasEntryFee => this.formValueMap.containsKey(EntryFeeValueKey);
  bool get hasStart => this.formValueMap.containsKey(StartValueKey);
  bool get hasEnd => this.formValueMap.containsKey(EndValueKey);
  bool get hasType => this.formValueMap.containsKey(TypeValueKey);
  bool get hasWinnerType => this.formValueMap.containsKey(WinnerTypeValueKey);
  bool get hasEntryType => this.formValueMap.containsKey(EntryTypeValueKey);
  bool get hasDuration => this.formValueMap.containsKey(DurationValueKey);

  bool get hasNameValidationMessage =>
      this.fieldsValidationMessages[NameValueKey]?.isNotEmpty ?? false;
  bool get hasParticipantsValidationMessage =>
      this.fieldsValidationMessages[ParticipantsValueKey]?.isNotEmpty ?? false;
  bool get hasEntryFeeValidationMessage =>
      this.fieldsValidationMessages[EntryFeeValueKey]?.isNotEmpty ?? false;
  bool get hasStartValidationMessage =>
      this.fieldsValidationMessages[StartValueKey]?.isNotEmpty ?? false;
  bool get hasEndValidationMessage =>
      this.fieldsValidationMessages[EndValueKey]?.isNotEmpty ?? false;
  bool get hasTypeValidationMessage =>
      this.fieldsValidationMessages[TypeValueKey]?.isNotEmpty ?? false;
  bool get hasWinnerTypeValidationMessage =>
      this.fieldsValidationMessages[WinnerTypeValueKey]?.isNotEmpty ?? false;
  bool get hasEntryTypeValidationMessage =>
      this.fieldsValidationMessages[EntryTypeValueKey]?.isNotEmpty ?? false;
  bool get hasDurationValidationMessage =>
      this.fieldsValidationMessages[DurationValueKey]?.isNotEmpty ?? false;

  String? get nameValidationMessage =>
      this.fieldsValidationMessages[NameValueKey];
  String? get participantsValidationMessage =>
      this.fieldsValidationMessages[ParticipantsValueKey];
  String? get entryFeeValidationMessage =>
      this.fieldsValidationMessages[EntryFeeValueKey];
  String? get startValidationMessage =>
      this.fieldsValidationMessages[StartValueKey];
  String? get endValidationMessage =>
      this.fieldsValidationMessages[EndValueKey];
  String? get typeValidationMessage =>
      this.fieldsValidationMessages[TypeValueKey];
  String? get winnerTypeValidationMessage =>
      this.fieldsValidationMessages[WinnerTypeValueKey];
  String? get entryTypeValidationMessage =>
      this.fieldsValidationMessages[EntryTypeValueKey];
  String? get durationValidationMessage =>
      this.fieldsValidationMessages[DurationValueKey];
}

extension Methods on FormViewModel {
  Future<void> selectStart(
      {required BuildContext context,
      required DateTime initialDate,
      required DateTime firstDate,
      required DateTime lastDate}) async {
    final selectedDate = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate);
    if (selectedDate != null) {
      this.setData(this.formValueMap..addAll({StartValueKey: selectedDate}));
    }
  }

  Future<void> selectEnd(
      {required BuildContext context,
      required DateTime initialDate,
      required DateTime firstDate,
      required DateTime lastDate}) async {
    final selectedDate = await showDatePicker(
        context: context,
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate);
    if (selectedDate != null) {
      this.setData(this.formValueMap..addAll({EndValueKey: selectedDate}));
    }
  }

  void setType(String type) {
    this.setData(this.formValueMap..addAll({TypeValueKey: type}));
  }

  void setWinnerType(String winnerType) {
    this.setData(this.formValueMap..addAll({WinnerTypeValueKey: winnerType}));
  }

  void setEntryType(String entryType) {
    this.setData(this.formValueMap..addAll({EntryTypeValueKey: entryType}));
  }

  void setDuration(String duration) {
    this.setData(this.formValueMap..addAll({DurationValueKey: duration}));
  }

  setNameValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[NameValueKey] = validationMessage;
  setParticipantsValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[ParticipantsValueKey] = validationMessage;
  setEntryFeeValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[EntryFeeValueKey] = validationMessage;
  setStartValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[StartValueKey] = validationMessage;
  setEndValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[EndValueKey] = validationMessage;
  setTypeValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[TypeValueKey] = validationMessage;
  setWinnerTypeValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[WinnerTypeValueKey] = validationMessage;
  setEntryTypeValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[EntryTypeValueKey] = validationMessage;
  setDurationValidationMessage(String? validationMessage) =>
      this.fieldsValidationMessages[DurationValueKey] = validationMessage;
}
