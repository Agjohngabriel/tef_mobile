import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/my_leagues/create_league_viewmodel.dart';

import '../../../helpers/constants/colors.dart';
import 'create_league_view.form.dart';

@FormView(
  fields: [
    FormTextField(
      name: 'name',
    ),
    FormTextField(
      name: 'participants',
    ),
    FormTextField(
      name: 'entry_fee',
    ),
    FormDateField(name: 'start'),
    FormDateField(name: 'end'),
    FormDropdownField(
      name: 'type',
      items: [
        StaticDropdownItem(
          title: 'Public',
          value: 'public',
        ),
        StaticDropdownItem(
          title: 'Private',
          value: 'private',
        ),
      ],
    ),
    FormDropdownField(
      name: 'winner_type',
      items: [
        StaticDropdownItem(
          title: 'Single',
          value: 'single',
        ),
        StaticDropdownItem(
          title: 'Double',
          value: 'double',
        ),
      ],
    ),
    FormDropdownField(
      name: 'entry_type',
      items: [
        StaticDropdownItem(
          title: 'Paid',
          value: 'paid',
        ),
        StaticDropdownItem(
          title: 'Free',
          value: 'free',
        ),
      ],
    ),
    FormDropdownField(
      name: 'duration',
      items: [
        StaticDropdownItem(
          title: 'Daily',
          value: 'daily',
        ),
        StaticDropdownItem(
          title: 'Weekly',
          value: 'weekly',
        ),
        StaticDropdownItem(
          title: 'Monthly',
          value: 'monthly',
        ),
      ],
    )
  ],
  autoTextFieldValidation: false,
)
class CreateLeague extends StatelessWidget with $CreateLeague {
  CreateLeague({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CreateLeagueViewModel>.reactive(
        viewModelBuilder: () => CreateLeagueViewModel(),
        disposeViewModel: true,
        onModelReady: (model) {
          // #3: Listen to text updates by calling listenToFormUpdated(model);
          listenToFormUpdated(model);
          model.setType(TypeValueToTitleMap.keys.first);
          TypeValueToTitleMap.addAll({'others': 'Others'});
          model.setDuration(DurationValueToTitleMap.keys.first);
          DurationValueToTitleMap.addAll({'others': 'Others'});
          model.setEntryType(EntryTypeValueToTitleMap.keys.first);
          EntryTypeValueToTitleMap.addAll({'others': 'Others'});
          model.setWinnerType(WinnerTypeValueToTitleMap.keys.first);
          WinnerTypeValueToTitleMap.addAll({'others': 'Others'});
        },
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColors.white,
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(
                  Icons.arrow_back,
                  color: AppColors.white,
                ),
                onPressed: () => context.pop(),
              ),
              backgroundColor: AppColors.primary,
              title: Text(
                "Create League",
                style: context.textTheme.headline5
                    ?.copyWith(color: AppColors.white),
              ),
              centerTitle: true,
              elevation: 0,
            ),
            body: Form(
              child: Padding(
                padding: const EdgeInsets.all(25.0),
                child: ListView(
                  children: [
                    const Center(
                      child: Text(
                        "Please type carefully and fill out the form with Personal details. You can't edit these details once you submit the form.",
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("League Type"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                    color: AppColors.backgroundGrey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 3),
                                    child: DropdownButton(
                                      dropdownColor: AppColors.backgroundGrey
                                          .withOpacity(0.9),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(6)),
                                      value: model.typeValue,
                                      onChanged: (value) {
                                        model.setType(value!);
                                      },
                                      items: TypeValueToTitleMap.keys
                                          .map(
                                            (value) => DropdownMenuItem<String>(
                                              key: ValueKey('$value key'),
                                              value: value,
                                              child: Text(
                                                  TypeValueToTitleMap[value]!),
                                            ),
                                          )
                                          .toList(),
                                      isExpanded: true,
                                      underline: const SizedBox(),
                                    )),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Entry Type"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: const BoxDecoration(
                                    color: AppColors.backgroundGrey),
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 3),
                                    child: DropdownButton(
                                      dropdownColor: AppColors.backgroundGrey
                                          .withOpacity(0.9),
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(6)),
                                      value: model.entryTypeValue,
                                      onChanged: (value) {
                                        model.setEntryType(value!);
                                      },
                                      items: EntryTypeValueToTitleMap.keys
                                          .map(
                                            (value) => DropdownMenuItem<String>(
                                              key: ValueKey('$value key'),
                                              value: value,
                                              child: Text(
                                                  EntryTypeValueToTitleMap[
                                                      value]!),
                                            ),
                                          )
                                          .toList(),
                                      isExpanded: true,
                                      underline: const SizedBox(),
                                    )),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("League Title"),
                        const SizedBox(
                          height: 10,
                        ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                              color: AppColors.backgroundGrey,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            child: TextFormField(
                              controller: nameController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        model.hasNameValidationMessage
                            ? Text(
                                "${model.nameValidationMessage}",
                                style: const TextStyle(color: Colors.red),
                              )
                            : const SizedBox(),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Duration"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                    color: AppColors.backgroundGrey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  child: DropdownButton(
                                    dropdownColor: AppColors.backgroundGrey
                                        .withOpacity(0.9),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(6)),
                                    value: model.durationValue,
                                    onChanged: (value) {
                                      model.setDuration(value!);
                                    },
                                    items: DurationValueToTitleMap.keys
                                        .map(
                                          (value) => DropdownMenuItem<String>(
                                            key: ValueKey('$value key'),
                                            value: value,
                                            child: Text(DurationValueToTitleMap[
                                                value]!),
                                          ),
                                        )
                                        .toList(),
                                    isExpanded: true,
                                    underline: const SizedBox(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Winning Type"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                    color: AppColors.backgroundGrey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  child: DropdownButton(
                                    dropdownColor: AppColors.backgroundGrey
                                        .withOpacity(0.9),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(6)),
                                    value: model.winnerTypeValue,
                                    onChanged: (value) {
                                      model.setWinnerType(value!);
                                    },
                                    items: WinnerTypeValueToTitleMap.keys
                                        .map(
                                          (value) => DropdownMenuItem<String>(
                                            key: ValueKey('$value key'),
                                            value: value,
                                            child: Text(
                                                WinnerTypeValueToTitleMap[
                                                    value]!),
                                          ),
                                        )
                                        .toList(),
                                    isExpanded: true,
                                    underline: const SizedBox(),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Participants"),
                        const SizedBox(
                          height: 10,
                        ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                              color: AppColors.backgroundGrey,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            child: TextFormField(
                              controller: participantsController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        model.hasParticipantsValidationMessage
                            ? Text(
                                "${model.participantsValidationMessage}",
                                style: const TextStyle(color: Colors.red),
                              )
                            : const SizedBox(),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Start Date"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                    color: AppColors.backgroundGrey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: TextFormField(
                                  keyboardType: TextInputType.datetime,
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: model.hasStart
                                        ? DateFormat('dd-MM-yyyy')
                                            .format(model.startValue!)
                                        : 'Select start date',
                                  ),
                                  readOnly: true,
                                  onTap: () => model.selectStart(
                                      context: context,
                                      firstDate: DateTime.now(),
                                      initialDate: DateTime.now(),
                                      lastDate: DateTime(2023)),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("End Date"),
                              const SizedBox(
                                height: 10,
                              ),
                              DecoratedBox(
                                decoration: BoxDecoration(
                                    color: AppColors.backgroundGrey,
                                    borderRadius: BorderRadius.circular(10)),
                                child: TextFormField(
                                  keyboardType: TextInputType.datetime,
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: model.hasEnd
                                        ? DateFormat('dd-MM-yyyy')
                                            .format(model.endValue!)
                                        : 'Select end date',
                                  ),
                                  readOnly: true,
                                  onTap: () => model.selectEnd(
                                      context: context,
                                      firstDate: DateTime.now(),
                                      initialDate: DateTime.now(),
                                      lastDate: DateTime(2023)),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Amount"),
                        const SizedBox(
                          height: 10,
                        ),
                        DecoratedBox(
                          decoration: BoxDecoration(
                              color: AppColors.backgroundGrey,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            child: TextFormField(
                              controller: entry_feeController,
                              decoration: const InputDecoration(
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        model.hasEntryFeeValidationMessage
                            ? Text(
                                "${model.entryFeeValidationMessage}",
                                style: const TextStyle(color: Colors.red),
                              )
                            : const SizedBox(),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    model.isBusy
                        ? const Center(
                            child: SpinKitThreeBounce(
                            color: AppColors.primary,
                          ))
                        : InkWell(
                            onTap: model.saveData,
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              margin: const EdgeInsets.symmetric(horizontal: 5),
                              decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.8),
                                  borderRadius: BorderRadius.circular(10)),
                              child: const Center(
                                  child: Text(
                                "Create",
                                style: TextStyle(color: AppColors.white),
                              )),
                            ),
                          )
                  ],
                ),
              ),
            )));
  }
}
