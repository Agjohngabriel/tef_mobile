import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutterwave_standard/core/flutterwave.dart';
import 'package:flutterwave_standard/models/requests/customer.dart';
import 'package:flutterwave_standard/models/requests/customizations.dart';
import 'package:flutterwave_standard/models/responses/charge_response.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/model/user.dart';
import 'package:tefzon_mobile/model/wallet.dart';
import 'package:tefzon_mobile/services/api.dart';
import 'package:tefzon_mobile/services/core_services/user_services.dart';

class WalletViewModel extends FutureViewModel<User> {
  final _api = locator<Api>();
  final _user = locator<UserService>();
  var wallet = <WalletModel>[];
  final amountController = TextEditingController();
  bool isVisible = false;

  Future<User> getProfile() async {
    final id = _user.user?.id;
    var response = await _api.getData('gamers/$id');
    var parsed = json.decode(response.body)["data"];
    final user = (User.fromJson(parsed));

    getWallet();

    return user;
  }

  void setVisible() {
    isVisible ? isVisible = false : isVisible = true;
    notifyListeners();
  }

  Future<List<WalletModel>> getWallet() async {
    setBusy(true);

    var response = await _api.getWallet("get-account-details");
    var responseData = json.decode(response.body);

    WalletModel walletModel = WalletModel(
      id: responseData["id"],
      user_id: responseData["user_id"].toString(),
      balance: responseData['balance'].toString(),
      wins: responseData['wins'].toString(),
      loss: responseData["loss"].toString(),
      draw: responseData['draw'].toString(),
      cancelled: responseData['cancelled'].toString(),
      created_at: responseData["created_at"],
      account_name: responseData['account_name'],
      account_no: responseData["account_no"],
      bank_name: responseData['bank_name'],
    );

    wallet.add(walletModel);

    setBusy(false);

    return wallet;
  }

  @override
  Future<User> futureToRun() => getProfile();

  //   @override
  // Future<User> futureToRun() => getProfile();

  handlePaymentInitialization(BuildContext context) async {
    final Customer customer = Customer(
        name: "${_user.user?.lastName} ${_user.user?.lastName}",
        phoneNumber: "${_user.user?.phone}",
        email: "${_user.user?.email}");
    final Flutterwave flutterwave = Flutterwave(
        context: context,
        publicKey: "FLWPUBK_TEST-7efad3e0c3c6837e1ea6a2c237da50c2-X",
        currency: "NGN",
        amount: "3000",
        customer: customer,
        paymentOptions: "ussd, card, barter, payattitude",
        customization: Customization(title: "tefzon"),
        isTestMode: true,
        txRef:
            "${_user.user?.lastName}${DateTime.now()}${_user.user?.firstName}",
        redirectUrl: 'tefzon.com');
    final ChargeResponse response = await flutterwave.charge();
    if (response != null) {
      print("${response.toJson()}");
    } else {
      print(response);
    }
  }
}
