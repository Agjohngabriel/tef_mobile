import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/wallet/wallet_viewmodel.dart';
import 'package:tefzon_mobile/ui/widgets/custom_buttons.dart';

class WalletView extends StatelessWidget {
  const WalletView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<WalletViewModel>.reactive(
        viewModelBuilder: () => WalletViewModel(),
        builder: (context, model, child) => Scaffold(
            appBar: AppBar(
              title: const Text("Wallet"),
              elevation: 0,
              backgroundColor: AppColors.primary,
              centerTitle: true,
            ),
            body: model.hasError
                ? Container(
                    color: Colors.red,
                    alignment: Alignment.center,
                    child: const Text(
                      'An error has occered while running the future',
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : model.isBusy
                    ? const Center(
                        child: SpinKitThreeBounce(
                        color: AppColors.primary,
                      ))
                    : model.wallet.isEmpty
                        ? const Center(
                            child: SpinKitThreeBounce(
                            color: AppColors.primary,
                          ))
                        : ListView(
                            physics: const BouncingScrollPhysics(),
                            children: [
                              const SizedBox(height: 34),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 25.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Welcome!",
                                          style: const TextStyle(
                                              color: Colors.grey),
                                        ),
                                        Text(
                                          "${model.data?.firstName} ${model.data?.lastName}",
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 22),
                                        ),
                                        const SizedBox(height: 4),
                                      ],
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                          color: Colors.grey.shade200,
                                          borderRadius:
                                              BorderRadius.circular(5)),
                                      width: 50,
                                      height: 50,
                                      child: Icon(Icons.person),
                                    )
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(
                                  left:
                                      MediaQuery.of(context).size.width * 0.07,
                                  right:
                                      MediaQuery.of(context).size.width * 0.07,
                                ),
                                margin: EdgeInsets.only(
                                    top: 20,
                                    bottom: 20,
                                    left: MediaQuery.of(context).size.width *
                                        0.05,
                                    right: MediaQuery.of(context).size.width *
                                        0.05),
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    image: DecorationImage(
                                        image:
                                            AssetImage("asset/images/bg-3.png"),
                                        fit: BoxFit.cover),
                                    borderRadius: BorderRadius.circular(10)),
                                width: MediaQuery.of(context).size.width,
                                height:
                                    MediaQuery.of(context).size.width * 0.32,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Text(
                                          "NGN${double.parse(model.wallet.first.balance ?? "0").toStringAsFixed(2)}",
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 24,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Text(
                                          "Wallet Balance",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ],
                                    ),
                                    ConstrainedBox(
                                        constraints: BoxConstraints(
                                            maxHeight: 100, maxWidth: 100),
                                        child: CustomButton(
                                          text: "Fund",
                                          onTap: model.setVisible,
                                          isFilled: true,
                                        ))
                                  ],
                                ),
                              ),
                              Visibility(
                                visible: model.isVisible,
                                child: Padding(
                                  padding: EdgeInsets.all(20),
                                  child: Column(
                                    children: [
                                      TextField(
                                        controller: model.amountController,
                                        keyboardType: TextInputType.name,
                                        decoration: InputDecoration(
                                          hintText: "Enter Amount",
                                          hintStyle: TextStyle(
                                            color: AppColors.primary,
                                            fontSize:
                                                context.widthPercent(0.04),
                                            fontStyle: FontStyle.normal,
                                            letterSpacing: 0.5,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      CustomButton(
                                        text: "Proceed",
                                        onTap: () =>
                                            model.handlePaymentInitialization(
                                                context),
                                        isFilled: true,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal:
                                      MediaQuery.of(context).size.width * 0.05,
                                ),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      WalletBox(
                                          title: "Wins",
                                          icon: Icons.checklist_rtl,
                                          count: model.wallet.first.wins!,
                                          color: Colors.green),
                                      WalletBox(
                                        title: "Loss",
                                        icon: Icons.thumb_down,
                                        color: Colors.red,
                                        count: model.wallet.first.loss!,
                                      ),
                                      WalletBox(
                                        title: "Draws",
                                        icon: Icons.equalizer,
                                        color: Colors.blueAccent,
                                        count: model.wallet.first.draw!,
                                      ),
                                      WalletBox(
                                        title: "Cancelled",
                                        icon: Icons.cancel,
                                        color: Colors.orangeAccent,
                                        count: model.wallet.first.cancelled!,
                                      ),
                                    ]),
                              ),
                              SizedBox(
                                  height:
                                      MediaQuery.of(context).size.width * 0.05),
                              Divider(
                                height: 5,
                                thickness: 1,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left:
                                      MediaQuery.of(context).size.width * 0.05,
                                  right:
                                      MediaQuery.of(context).size.width * 0.05,
                                  top: MediaQuery.of(context).size.width * 0.05,
                                  bottom:
                                      MediaQuery.of(context).size.width * 0.07,
                                ),
                                child: Text(
                                  "Account Details",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20),
                                ),
                              ),
                              DetailBox(
                                caption: "Account Name",
                                icon: Icons.contacts,
                                color: Colors.amberAccent,
                                data: model.wallet.first.account_name ??
                                    "${model.data?.firstName} ${model.data?.lastName}",
                              ),
                              DetailBox(
                                caption: "Account Number",
                                icon: Icons.account_balance_wallet,
                                color: Colors.lightGreen,
                                data: model.wallet.first.account_no ??
                                    "xxx-xxx-xxxx",
                              ),
                              DetailBox(
                                caption: "Bank Name",
                                icon: Icons.account_balance,
                                color: Colors.lightBlueAccent,
                                data: model.wallet.first.bank_name ?? "_ _",
                              ),
                              DetailBox(
                                caption: "Account Created",
                                icon: Icons.calendar_month,
                                color: Colors.purpleAccent,
                                data: DateFormat('MMM yyyy').format(
                                  DateTime.parse(
                                      model.wallet.first.created_at!),
                                ),
                              ),
                            ],
                          )));
  }

  Widget buildEditIcon() => buildCircle(
        color: Colors.white,
        all: 3,
        child: buildCircle(
          color: AppColors.primary,
          all: 8,
          child: const Icon(
            Icons.edit,
            color: AppColors.white,
            size: 20,
          ),
        ),
      );

  Widget buildCircle({
    required Widget child,
    required double all,
    required Color color,
  }) =>
      ClipOval(
        child: Container(
          padding: EdgeInsets.all(all),
          color: color,
          child: child,
        ),
      );
  Widget buildAbout(String title, String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
          ],
        ),
      );
}

class WalletBox extends StatelessWidget {
  final String title;
  final IconData icon;
  final String count;
  final Color color;
  const WalletBox({
    super.key,
    required this.title,
    required this.icon,
    required this.color,
    this.count = "0",
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width * 0.17,
          height: MediaQuery.of(context).size.width * 0.17,
          decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 28,
              ),
              Text(count)
            ],
          ),
        ),
        SizedBox(
          height: 6,
        ),
        Text(title)
      ],
    );
  }
}

class DetailBox extends StatelessWidget {
  final String caption;
  final String data;
  final IconData icon;
  final String count;
  final Color color;
  const DetailBox({
    super.key,
    required this.caption,
    required this.icon,
    required this.color,
    required this.data,
    this.count = "0",
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: MediaQuery.of(context).size.width * 0.05,
        right: MediaQuery.of(context).size.width * 0.05,
        bottom: MediaQuery.of(context).size.width * 0.05,
      ),
      child: Row(
        children: [
          Container(
            margin: EdgeInsets.only(right: 12),
            width: MediaQuery.of(context).size.width * 0.12,
            height: MediaQuery.of(context).size.width * 0.12,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(10)),
            child: Icon(
              icon,
              color: Colors.white,
              size: 28,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                caption,
                style: TextStyle(color: Colors.grey),
              ),
              Text(
                data,
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
              )
            ],
          ),
        ],
      ),
    );
  }
}
