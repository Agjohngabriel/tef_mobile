// import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';

import '../../../app/locator.dart';
import '../../../helpers/constants/routes.dart';
import 'widgets/info_bottomsheet.dart';

class AboutViewModel extends BaseViewModel {
  final _router = locator<GoRouter>();
  void openInfoBottomSheet({int index = 0}) {
    OneContext.instance.showModalBottomSheet(
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(10))),
        builder: (context) => InfoBottomSheet(index));
  }

  void openUserAgreement() {
    openInfoBottomSheet(index: 0);
  }

  void openInformationNotice() {
    openInfoBottomSheet(index: 2);
  }

  void goToFaq() {
    _router.push(AppRoutes.faqView);
  }
}
