import 'package:flutter/material.dart';
import '../../../helpers/constants/colors.dart';
import 'about_viewmodel.dart';

import 'widgets/about_app_tile.dart';

import 'package:stacked/stacked.dart';

class AboutView extends StatelessWidget {
  const AboutView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AboutViewModel>.reactive(
      builder: (context, model, child) => Scaffold(
        backgroundColor: AppColors.white,
        appBar: AppBar(title: Text("About App"),),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            children: [
              const SizedBox(
                height: 35,
              ),
              AboutAppTile(
                title: 'Web (yemeksepetl.com)',
                onTap: () {},
              ),
              const Divider(height: 50),
              AboutAppTile(
                title: 'User Agreement & Data Protection Policy',
                onTap: model.openUserAgreement,
              ),
              const Divider(height: 50),
              AboutAppTile(
                title: 'Information Notice',
                onTap: model.openInformationNotice,
              ),
              const Divider(height: 50),
              AboutAppTile(
                title: 'Information Society Services',
                onTap: () {},
              ),
              const Divider(height: 50),
              AboutAppTile(
                title: 'FAQs/ App Guide',
                onTap: model.goToFaq,
              ),
              const Divider(height: 50),
              AboutAppTile(
                title: 'Contact',
                onTap: () {},
              ),
              const Divider(height: 50),
            ],
          ),
        ),
      ),
      viewModelBuilder: () => AboutViewModel(),
    );
  }
}
