import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';

import '../../../../helpers/constants/colors.dart';

class AboutAppTile extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  const AboutAppTile({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(title,
                style: TextStyle(
                  color: AppColors.text,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.1,
                  fontSize: context.widthPercent(0.037),
                )),
          ),
          const Icon(Icons.arrow_forward_ios_rounded, size: 20,),
        ],
      ),
    );
  }
}
