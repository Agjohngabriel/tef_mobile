import 'package:flutter/material.dart';

import '../../../../helpers/constants/colors.dart';
import '../../../widgets/custom_tab_view.dart';

class InfoBottomSheet extends StatelessWidget {
  const InfoBottomSheet(
    this.index, {
    Key? key,
  }) : super(key: key);
  final int index;
  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
        initialChildSize: 0.4,
        minChildSize: 0.3,
        maxChildSize: 0.9,
        builder: (_, controller) => Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.circular(25),
              ),
              child: CustomTabView(
                index: index,
                tabTitles: const [
                  'User Agreement',
                  'Personal Data Protection Policy',
                  'Information Notice'
                ],
                tabViews: [_tabItem, _tabItem, _tabItem],
              ),
            ));
  }
}

final _tabItem = RichText(
    text: const TextSpan(children: [
  TextSpan(
    text: "Resturants earn ",
    style: TextStyle(color: AppColors.black, fontWeight: FontWeight.w600),
  ),
  TextSpan(
    text:
        "the Super Restaurant badge. If they are recieving a lot of orders, have high customer ratings and low order cancellation rates. ",
    style: TextStyle(color: AppColors.text, fontWeight: FontWeight.w400),
  ),
]));
