import 'dart:async';
import 'dart:io';
import 'package:stacked/stacked.dart';
import 'package:webview_flutter/webview_flutter.dart';

class LiveSupportWebViewModel extends BaseViewModel {
  final controller = Completer<WebViewController>();

  void checkPlatform() {
    if (Platform.isAndroid) {
      WebView.platform = SurfaceAndroidWebView();
    }
  }

  NavigationDecision navigationDelegate(NavigationRequest request) {
    if (request.url.startsWith('https://www.youtube.com/')) {
      print('blocking navigation to $request}');
      return NavigationDecision.prevent;
    }
    print('allowing navigation to $request');
    return NavigationDecision.navigate;
  }
}
