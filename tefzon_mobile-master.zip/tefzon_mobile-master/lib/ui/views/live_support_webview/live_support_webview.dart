import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../widgets/app_bar.dart';
import 'live_supports_viewmodel.dart';

class LiveSupportWebView extends StatelessWidget {
  const LiveSupportWebView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LiveSupportWebViewModel>.nonReactive(
        viewModelBuilder: () => LiveSupportWebViewModel(),
        onModelReady: (model) => model.checkPlatform,
        builder: (context, model, child) => Scaffold(
              appBar: const TefzonAppBar(
                text: "Live Support",
                useXIcon: true,
              ),
              body: WebView(
                initialUrl: 'https://flutter.dev',
                javascriptMode: JavascriptMode.unrestricted,
                onWebViewCreated: (WebViewController webViewController) {
                  model.controller.complete(webViewController);
                },
                navigationDelegate: (NavigationRequest request) {
                  return model.navigationDelegate(request);
                },
                gestureNavigationEnabled: true,
              ),
            ));
  }
}
