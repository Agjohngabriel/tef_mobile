import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:iconify_flutter/iconify_flutter.dart';
import 'package:iconify_flutter/icons/bx.dart';

import '../../../widgets/custom_tile.dart';
import '../../../widgets/page_section.dart';
import '../account_viewmodel.dart';

class SettingsSection extends ViewModelWidget<AccountViewModel> {
  const SettingsSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, AccountViewModel viewModel) {
    return ViewModelBuilder<AccountViewModel>.reactive(
      builder: (context, model, child) => PageSection(
        title: "Settings",
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomMenuTile(
                onTap: () => {},
                leading: Icon(Icons.rate_review),
                title: "Rate App"),
            const Divider(),
            CustomMenuTile(
                onTap: model.goToAbout,
                leading: Iconify(Bx.bx_info_circle),
                title: "About App"),
            const Divider(),
          ],
        ),
      ),
      viewModelBuilder: () => AccountViewModel(),
    );
  }
}
