import 'package:iconify_flutter/iconify_flutter.dart';
import 'package:iconify_flutter/icons/emojione_monotone.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';

import '../../../../helpers/constants/colors.dart';
import '../../../widgets/custom_tile.dart';
import '../account_viewmodel.dart';

class AccountSection extends ViewModelWidget<AccountViewModel> {
  const AccountSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, AccountViewModel viewModel) {
    return ViewModelBuilder<AccountViewModel>.reactive(
      builder: (context, model, child) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: model.gotoProfile,
            child: Container(
              padding: const EdgeInsets.all(15.0),
              decoration: BoxDecoration(
                  color: AppColors.backgroundGrey,
                  borderRadius: BorderRadius.circular(8.0)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              "${viewModel.user?.firstName} ${viewModel.user?.lastName}",
                              style: TextStyle(
                                color: AppColors.text,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.1,
                                fontSize: context.widthPercent(0.046),
                              )),
                          const SizedBox(
                            height: 10,
                          ),
                          Text("${viewModel.user?.username}",
                              style: TextStyle(
                                color: AppColors.text50,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 0.7,
                                fontSize: context.widthPercent(0.032),
                              ))
                        ],
                      )
                    ],
                  ),
                  const Icon(Icons.arrow_forward_ios_rounded),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          CustomMenuTile(
            onTap: model.goToWallet,
            leading: const Icon(
              Icons.wallet,
              color: AppColors.primary,
            ),
            title: "Wallet",
            subtitle: "Total Balance: 0.00 NGN",
          ),
          const Divider(),
          CustomMenuTile(
              onTap: model.gotoProfile,
              leading: const Icon(
                Icons.person,
                color: AppColors.primary,
              ),
              title: "My Info"),
          // const Divider(),
          // CustomMenuTile(
          //     onTap: () {},
          //     leading: const Icon(
          //       Icons.list,
          //       color: AppColors.primary,
          //     ),
          //     title: "Leagues"),
          const Divider(),
          // CustomMenuTile(
          //     onTap: () {},
          //     leading: const Icon(
          //       Icons.wallet,
          //       color: AppColors.primary,
          //     ),
          //     title: "Games"),
          // const Divider(),
          CustomMenuTile(
              onTap: viewModel.goToSquad,
              leading: Iconify(
                EmojioneMonotone.soccer_ball,
                color: AppColors.primary,
              ),
              title: "My Squad"),
          const Divider(),
          // CustomMenuTile(
          //     onTap: () {},
          //     leading: const Icon(
          //       Icons.wallet,
          //       color: AppColors.primary,
          //     ),
          //     title: "My Credit Cards"),
        ],
      ),
      viewModelBuilder: () => AccountViewModel(),
    );
  }
}
