import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:iconify_flutter/iconify_flutter.dart';
import 'package:iconify_flutter/icons/bx.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/account/account_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/account/widgets/account_section.dart';
import 'package:tefzon_mobile/ui/views/account/widgets/setting_section.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/custom_tile.dart';

class AccountView extends StatelessWidget {
  const AccountView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AccountViewModel>.nonReactive(
        viewModelBuilder: () => AccountViewModel(),
        onModelReady: (model) => model.getUser,
        builder: (context, model, child) => SafeArea(
              top: false,
              child: Scaffold(
                backgroundColor: AppColors.backgroundGrey,
                body: Padding(
                  padding: const EdgeInsets.all(19.0),
                  child: ListView(
                    children: [
                      const AccountSection(),
                      const Divider(),
                      CustomMenuTile(
                          onTap: model.goToSupport,
                          leading: Iconify(
                            Bx.bx_support,
                            color: AppColors.primary,
                          ),
                          title: "Support"),
                      const SizedBox(
                        height: 30,
                      ),
                      const SettingsSection(),
                      const SizedBox(
                        height: 20,
                      ),
                      Center(
                        child: GestureDetector(
                          onTap: () => model.logout(),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.logout),
                              const SizedBox(
                                width: 15,
                              ),
                              Text("Log out",
                                  style: TextStyle(
                                    color: AppColors.text,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.1,
                                    fontSize: context.widthPercent(0.043),
                                  ))
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                    ],
                  ),
                ),
              ),
            ));
  }
}
