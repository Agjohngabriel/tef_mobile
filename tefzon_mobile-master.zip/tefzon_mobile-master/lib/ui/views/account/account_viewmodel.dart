import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';
import 'package:tefzon_mobile/services/core_services/auth_service.dart';

import '../../../model/user.dart';
import '../../../services/core_services/user_services.dart';

class AccountViewModel extends ReactiveViewModel {
  final _router = locator<GoRouter>();
  final _auth = locator<AuthService>();
  final _userService = locator<UserService>();

  User? get user => _userService.user;

  void gotoProfile() {
    _router.push(AppRoutes.profile);
  }

  void goToWallet() {
    _router.push(AppRoutes.wallet);
  }

  void logout() {
    _auth.logout();
    _router.go(AppRoutes.splashScreen);
  }

  void goToAbout() {
    _router.push(AppRoutes.about);
  }

  void goToSquad() {
    _router.push(AppRoutes.mySquad);
  }

  void goToSupport() {
    _router.push(AppRoutes.supportView);
  }

  void getUser() {
    _userService.getUserDetails();
  }

  @override
  List<ReactiveServiceMixin> get reactiveServices => [_userService];
}
