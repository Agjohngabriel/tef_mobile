import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter/material.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';
import 'package:tefzon_mobile/model/squad.dart';
import 'package:tefzon_mobile/services/core_services/squad_service.dart';

import '../../../app/locator.dart';
import '../../../services/api.dart';
import '../../widgets/custom_scrollable_sheet.dart';

class SelectSquadViewModel extends ReactiveViewModel {
  final _api = locator<Api>();
  final SquadService _squadService = locator<SquadService>();

  List<GoalKeepers> get goalkeepers => _squadService.goalkeepers;
  List<Defender> get defenders => _squadService.defenders;
  List<MidFielders> get midfielders => _squadService.midfielders;
  List<Forwards> get forwards => _squadService.forwards;
  List<Subs> get subs => _squadService.subs;

  void getSquad() {
    _squadService.fetchSquad();
  }

  Future fetchPlayerById(int id) async {
    //   Response response = await _api.getData("get/all/players/$id");
    //   if (response.statusCode == 200) {
    //     var result = jsonDecode(response.body);
    //     _nPlayers = List<Player>.from(result.map((x) => Player.fromJson(x)));
    //   } else {
    //     throw Exception(response.body);
    //   }
    //   return _nPlayers;
  }

  void autoFill() async {
    setBusy(true);
    notifyListeners();
    await _api.getData("use-autocomplete").then((value) {
      if (value.statusCode == 200) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
    notifyListeners();
  }

  void reset() async {
    setBusy(true);
    await _api.getData("reset/team").then((value) {
      if (value.statusCode == 200) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
  }

  void removePlayer(int? playerId) async {
    await _api.deleteData("remove/player/$playerId").then((value) {
      if (value.statusCode == 200) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
  }

  void selectStartingEleven() {
    locator<GoRouter>().push(AppRoutes.startingEleven);
  }

  void openBottomSheet({required Widget sheet}) {
    OneContext.instance.showModalBottomSheet(
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(10))),
        builder: (context) => CustomScrollableSheet(
              child: sheet,
            ));
  }

  @override
  List<ReactiveServiceMixin> get reactiveServices => [_squadService];
}
