import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/media_query.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:tefzon_mobile/ui/views/select_squad/widgets/select_player/select_player_viewmodel.dart';

import '../../../../../helpers/constants/colors.dart';
import '../../../../widgets/custom_button.dart';

class SelectPlayer extends StatelessWidget {
  const SelectPlayer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SelectPlayerViewModel>.reactive(
        viewModelBuilder: () => SelectPlayerViewModel(),
        builder: (context, model, child) => Padding(
              padding: const EdgeInsets.all(15.0),
              child: model.hasError
                  ? Container(
                      color: Colors.red,
                      alignment: Alignment.center,
                      child: const Text(
                        'An error has occered while running the future',
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                  : model.isBusy
                      ? Center(
                          child: SpinKitFadingCircle(
                          color: AppColors.primary,
                        ))
                      : Column(
                          children: [
                            Container(
                              color: AppColors.primary,
                              padding: const EdgeInsets.all(15),
                              child: Column(
                                children: [
                                  DecoratedBox(
                                    decoration: BoxDecoration(
                                        color: AppColors.white
                                            .withOpacity(0.6),
                                        border: Border.all(
                                            color: AppColors.black, width: 1),
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 5),
                                      child: DropdownButton(
                                        dropdownColor: AppColors.white
                                            .withOpacity(0.9),
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(6)),
                                        value: model.seasonId,
                                        onChanged: (value) {
                                          model.setSeasionId(value!);
                                        },
                                        items: model.data!
                                            .map(
                                              (value) =>
                                                  DropdownMenuItem<String>(
                                                key: ValueKey('$value key'),
                                                value: value.currentSeasonId,
                                                child: Text("${value.name}"),
                                              ),
                                            )
                                            .toList(),
                                        isExpanded: true,
                                        underline: const SizedBox(),
                                      ),
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                              color: AppColors.white,
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 8, vertical: 3),
                                            child: TextFormField(
                                              decoration: const InputDecoration(
                                                  border: InputBorder.none,
                                                  prefixIcon:
                                                      Icon(Icons.search)),
                                              onChanged: model.searchPlayer,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 13,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      SquadPositionFetch(
                                        title: "GK",
                                        onTap: () => model.fetchPlayerById(1),
                                        isActive: false,
                                      ),
                                      SquadPositionFetch(
                                        title: "DEF",
                                        onTap: () => model.fetchPlayerById(2),
                                        isActive: false,
                                      ),
                                      SquadPositionFetch(
                                        title: "MID",
                                        onTap: () => model.fetchPlayerById(3),
                                        isActive: false,
                                      ),
                                      SquadPositionFetch(
                                        title: "FWD",
                                        onTap: () => model.fetchPlayerById(4),
                                        isActive: false,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 30,
                            ),
                            model.isBusy
                                ? const Center(
                                    child: SpinKitThreeBounce(
                                    color: AppColors.primary,
                                  ))
                                : model.players.isNotEmpty
                                    ? SizedBox(
                                        child: Container(
                                        padding: const EdgeInsets.all(10),
                                        height: context.heightPercent(0.35),
                                        child: ListView.builder(
                                            itemCount: model.players.length,
                                            itemBuilder: (BuildContext context,
                                                    int index) =>
                                                InkWell(
                                                  onTap: () => model.joinSquad(
                                                      model.players[index]
                                                          .playerId),
                                                  child: ListTile(
                                                    title: Text(
                                                        "${model.players[index].displayName}"),
                                                    subtitle: Text(
                                                        "${model.players[index].nationality}"),
                                                    leading: CircleAvatar(
                                                      child: Image.network(
                                                          "${model.players[index].imagePath}"),
                                                    ),
                                                    trailing: Text(
                                                        "${model.players[index].teamName}"),
                                                  ),
                                                )),
                                      ))
                                    : const SizedBox(),
                          ],
                        ),
            ));
  }
}
