import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/model/player.dart';
import 'package:tefzon_mobile/services/core_services/squad_service.dart';

import '../../../../../model/league.dart';
import '../../../../../services/api.dart';

class SelectPlayerViewModel extends FutureViewModel<List<Leagues>> {
  final _api = locator<Api>();
  final _squadService = locator<SquadService>();
  var players = <Player>[];
  String seasonId = "19699";

  void setSeasionId(String value) {
    seasonId = value;
    print(seasonId);
    notifyListeners();
    print(seasonId);
  }

  void searchPlayer(String query) {
    final suggestion = players.where((element) {
      final name = element.displayName?.toLowerCase();
      final input = query.toLowerCase();
      return name!.contains(input);
    }).toList();

    players = suggestion;
    notifyListeners();
  }

  void joinSquad(int? id) async {
    setBusy(true);
    final data = {
      "player_id": id,
    };
    await _api.postData("add/player", data).then((value) {
      print(value.statusCode);
      if (value.statusCode == 201) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      } else if (value.statusCode == 422) {
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: Text(jsonDecode(value.body)["message"]),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
  }

  Future<void> fetchPlayerById(int id) async {
    print(seasonId);
    setBusy(true);
    players = <Player>[];
    var response = await _api.getData("get/all/players/${seasonId}/$id");
    var parsed = json.decode(response.body) as List<dynamic>;
    for (var favourite in parsed) {
      players.add(Player.fromJson(favourite));
    }
    setBusy(false);
  }

  @override
  Future<List<Leagues>> futureToRun() => locator<Api>().getleagues();
}
