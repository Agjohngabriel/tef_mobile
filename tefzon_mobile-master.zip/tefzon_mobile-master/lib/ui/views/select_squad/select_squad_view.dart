import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/text_theme.dart';
import 'package:tefzon_mobile/ui/views/select_squad/select_squad_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/select_squad/widgets/select_player/select_player_view.dart';
import 'package:tefzon_mobile/ui/widgets/pitch.dart';

class SelectSquadView extends StatelessWidget {
  const SelectSquadView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SelectSquadViewModel>.reactive(
        viewModelBuilder: () => SelectSquadViewModel(),
        onModelReady: (model) => model.getSquad,
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.primary,
              appBar: AppBar(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Select Squad"),
                  ],
                ),
                elevation: 0,
                backgroundColor: Colors.deepPurpleAccent,
                actions: [
                  TextButton(
                      onPressed: model.reset,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                            border: Border.all(color: AppColors.white)),
                        child: Text(
                          "Auto-FIll",
                          style: context.textTheme.button
                              ?.copyWith(color: AppColors.white),
                        ),
                      )),
                  TextButton(
                      onPressed: model.reset,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                            border: Border.all(color: AppColors.white)),
                        child: Text(
                          "Reset",
                          style: context.textTheme.button
                              ?.copyWith(color: AppColors.white),
                        ),
                      )),
                ],
              ),
              floatingActionButton: IconButton(
                onPressed: model.selectStartingEleven,
                icon: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: const BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.all(Radius.circular(15))),
                  child: const Icon(
                    Icons.arrow_forward,
                    color: AppColors.primary,
                  ),
                ),
              ),
              body: Stack(
                children: [
                  Pitch(
                    goalKeepers: model.goalkeepers,
                    defender: model.defenders,
                    midFielders: model.midfielders,
                    forwards: model.forwards,
                    subs: model.subs,
                  ),
                  Positioned.fill(
                    child: model.isBusy
                        ? const Center(
                            child: SpinKitThreeBounce(
                            color: AppColors.primary,
                          ))
                        : const SizedBox(),
                  ),
                ],
              ),
            )));
  }
}
