import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/build_context.dart';
import 'package:tefzon_mobile/ui/views/select_vice_captain/select_vice_captain_viewmodel.dart';

import '../../../helpers/constants/assets.dart';
import '../../../helpers/constants/colors.dart';
import '../../widgets/custom_container.dart';
import '../../widgets/player_widget.dart';

class SelectViceCaptain extends StatelessWidget {
  const SelectViceCaptain({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SelectViceCaptainViewModel>.reactive(
        viewModelBuilder: () => SelectViceCaptainViewModel(),
        builder: (context, model, child) => SafeArea(
            top: false,
            child: Scaffold(
              backgroundColor: AppColors.primary,
              appBar: AppBar(
                title: const Text("Choose Vice Captain"),
                elevation: 0,
                backgroundColor: Colors.deepPurpleAccent,
              ),
              // body: Stack(
              //   children: [
              //     SizedBox(
              //         child: Stack(
              //       alignment: Alignment.topCenter,
              //       children: [
              //         Container(
              //           width: double.infinity,
              //           decoration: const BoxDecoration(
              //               image: DecorationImage(
              //                   image: AssetImage(AppAssets.pitch),
              //                   fit: BoxFit.cover)),
              //         ),
              //         const Positioned(
              //             top: 20,
              //             left: 10,
              //             child: Text(
              //               "Pick any player to assign Vice Captain",
              //               style: TextStyle(color: AppColors.white),
              //             )),
              //         model.squad?.goalkeepers == null
              //             ? const SizedBox()
              //             : Positioned(
              //                 top: context.heightPercent(0.18),
              //                 child: Row(
              //                   children: [
              //                     ...?model.squad?.goalkeepers
              //                         ?.map((e) => InkWell(
              //                               onTap: () =>
              //                                   model.makeViceCaptain(e.id),
              //                               child: e.isCaptain == 1
              //                                   ? Container(
              //                                       decoration: const BoxDecoration(
              //                                           color:
              //                                               AppColors.primary,
              //                                           borderRadius:
              //                                               BorderRadius.all(
              //                                                   Radius.circular(
              //                                                       16))),
              //                                       padding:
              //                                           const EdgeInsets.all(3),
              //                                       child: PlayerWidget(
              //                                         onTap: (){},
              //                                         name: "${e.playerName}",
              //                                         imagePath:
              //                                             "${e.imagePath}",
              //                                       ),
              //                                     )
              //                                   : e.isViceCaptain == 1
              //                                       ? Container(
              //                                           decoration: const BoxDecoration(
              //                                               color: AppColors
              //                                                   .secondary,
              //                                               borderRadius:
              //                                                   BorderRadius
              //                                                       .all(Radius
              //                                                           .circular(
              //                                                               16))),
              //                                           padding:
              //                                               const EdgeInsets
              //                                                   .all(3),
              //                                           child: PlayerWidget(
              //                                             onTap: (){},
              //                                             name:
              //                                                 "${e.playerName}",
              //                                             imagePath:
              //                                                 "${e.imagePath}",
              //                                           ),
              //                                         )
              //                                       : PlayerWidget(
              //                                 onTap: (){},
              //                                           name: "${e.playerName}",
              //                                           imagePath:
              //                                               "${e.imagePath}",
              //                                         ),
              //                             ))
              //                         .toList(),
              //                   ],
              //                 )),
              //         model.squad?.defenders == null
              //             ? const SizedBox()
              //             : Positioned(
              //                 top: context.heightPercent(0.29),
              //                 child: Row(
              //                   children: [
              //                     ...?model.squad?.defenders
              //                         ?.map((e) => InkWell(
              //                               onTap: () =>
              //                                   model.makeViceCaptain(e.id),
              //                               child: e.isCaptain == 1
              //                                   ? Container(
              //                                       decoration: const BoxDecoration(
              //                                           color:
              //                                               AppColors.primary,
              //                                           borderRadius:
              //                                               BorderRadius.all(
              //                                                   Radius.circular(
              //                                                       16))),
              //                                       padding:
              //                                           const EdgeInsets.all(3),
              //                                       child: PlayerWidget(
              //                                         onTap: (){},
              //                                         name: "${e.playerName}",
              //                                         imagePath:
              //                                             "${e.imagePath}",
              //                                       ),
              //                                     )
              //                                   : e.isViceCaptain == 1
              //                                       ? Container(
              //                                           decoration: const BoxDecoration(
              //                                               color: AppColors
              //                                                   .secondary,
              //                                               borderRadius:
              //                                                   BorderRadius
              //                                                       .all(Radius
              //                                                           .circular(
              //                                                               16))),
              //                                           padding:
              //                                               const EdgeInsets
              //                                                   .all(3),
              //                                           child: PlayerWidget(
              //                                             onTap: (){},
              //                                             name:
              //                                                 "${e.playerName}",
              //                                             imagePath:
              //                                                 "${e.imagePath}",
              //                                           ),
              //                                         )
              //                                       : PlayerWidget(
              //                                 onTap: (){},
              //                                           name: "${e.playerName}",
              //                                           imagePath:
              //                                               "${e.imagePath}",
              //                                         ),
              //                             ))
              //                         .toList(),
              //                   ],
              //                 )),
              //         model.squad?.midfielders == null
              //             ? const SizedBox()
              //             : Positioned(
              //                 top: context.heightPercent(0.39),
              //                 child: Row(
              //                   children: [
              //                     ...?model.squad?.midfielders
              //                         ?.map((e) => InkWell(
              //                               onTap: () =>
              //                                   model.makeViceCaptain(e.id),
              //                               child: e.isCaptain == 1
              //                                   ? Container(
              //                                       decoration: const BoxDecoration(
              //                                           color:
              //                                               AppColors.primary,
              //                                           borderRadius:
              //                                               BorderRadius.all(
              //                                                   Radius.circular(
              //                                                       16))),
              //                                       padding:
              //                                           const EdgeInsets.all(3),
              //                                       child: PlayerWidget(
              //                                         onTap: (){},
              //                                         name: "${e.playerName}",
              //                                         imagePath:
              //                                             "${e.imagePath}",
              //                                       ),
              //                                     )
              //                                   : e.isViceCaptain == 1
              //                                       ? Container(
              //                                           decoration: const BoxDecoration(
              //                                               color: AppColors
              //                                                   .secondary,
              //                                               borderRadius:
              //                                                   BorderRadius
              //                                                       .all(Radius
              //                                                           .circular(
              //                                                               16))),
              //                                           padding:
              //                                               const EdgeInsets
              //                                                   .all(3),
              //                                           child: PlayerWidget(
              //                                             onTap: (){},
              //                                             name:
              //                                                 "${e.playerName}",
              //                                             imagePath:
              //                                                 "${e.imagePath}",
              //                                           ),
              //                                         )
              //                                       : PlayerWidget(
              //                                 onTap: (){},
              //                                           name: "${e.playerName}",
              //                                           imagePath:
              //                                               "${e.imagePath}",
              //                                         ),
              //                             ))
              //                         .toList(),
              //                   ],
              //                 )),
              //         model.squad?.forwards == null
              //             ? const SizedBox()
              //             : Positioned(
              //                 top: context.heightPercent(0.49),
              //                 child: Row(
              //                   children: [
              //                     ...?model.squad?.forwards
              //                         ?.map((e) => InkWell(
              //                               onTap: () =>
              //                                   model.makeViceCaptain(e.id),
              //                               child: e.isCaptain == 1
              //                                   ? Container(
              //                                       decoration: const BoxDecoration(
              //                                           color:
              //                                               AppColors.primary,
              //                                           borderRadius:
              //                                               BorderRadius.all(
              //                                                   Radius.circular(
              //                                                       16))),
              //                                       padding:
              //                                           const EdgeInsets.all(3),
              //                                       child: PlayerWidget(
              //                                         onTap: (){},
              //                                         name: "${e.playerName}",
              //                                         imagePath:
              //                                             "${e.imagePath}",
              //                                       ),
              //                                     )
              //                                   : e.isViceCaptain == 1
              //                                       ? Container(
              //                                           decoration: const BoxDecoration(
              //                                               color: AppColors
              //                                                   .secondary,
              //                                               borderRadius:
              //                                                   BorderRadius
              //                                                       .all(Radius
              //                                                           .circular(
              //                                                               16))),
              //                                           padding:
              //                                               const EdgeInsets
              //                                                   .all(3),
              //                                           child: PlayerWidget(
              //                                             onTap: (){},
              //                                             name:
              //                                                 "${e.playerName}",
              //                                             imagePath:
              //                                                 "${e.imagePath}",
              //                                           ),
              //                                         )
              //                                       : PlayerWidget(
              //                                 onTap: (){},
              //                                           name: "${e.playerName}",
              //                                           imagePath:
              //                                               "${e.imagePath}",
              //                                         ),
              //                             ))
              //                         .toList(),
              //                   ],
              //                 )),
              //         model.squad?.subs == null
              //             ? const SizedBox()
              //             : Positioned(
              //                 top: context.heightPercent(0.59),
              //                 child: Row(
              //                   children: [
              //                     ...?model.squad?.subs
              //                         ?.map((e) => InkWell(
              //                               onTap: () =>
              //                                   model.makeViceCaptain(e.id),
              //                               child: e.isCaptain == 1
              //                                   ? Container(
              //                                       decoration: const BoxDecoration(
              //                                           color:
              //                                               AppColors.primary,
              //                                           borderRadius:
              //                                               BorderRadius.all(
              //                                                   Radius.circular(
              //                                                       16))),
              //                                       padding:
              //                                           const EdgeInsets.all(3),
              //                                       child: PlayerWidget(
              //                                         onTap: (){},
              //                                         name: "${e.playerName}",
              //                                         imagePath:
              //                                             "${e.imagePath}",
              //                                       ),
              //                                     )
              //                                   : PlayerWidget(
              //                                 onTap: (){},
              //                                       name: "${e.playerName}",
              //                                       imagePath: "${e.imagePath}",
              //                                     ),
              //                             ))
              //                         .toList(),
              //                   ],
              //                 )),
              //       ],
              //     )),
              //     Positioned(
              //       top: 50,
              //       left: 10,
              //       child: model.isBusy
              //           ? const Center(
              //               child: SpinKitThreeBounce(
              //               color: AppColors.primary,
              //             ))
              //           : const SizedBox(),
              //     ),
              //     Positioned(
              //       bottom: 20,
              //       left: 10,
              //       right: 10,
              //       child: CustomContainer(
              //         title: "Confirm Squad Selection",
              //         function: model.confirmSquad,
              //       ),
              //     )
              //   ],
              // ),
            )));
  }
}
