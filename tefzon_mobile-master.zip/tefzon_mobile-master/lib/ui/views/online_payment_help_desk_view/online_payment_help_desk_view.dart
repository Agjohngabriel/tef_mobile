import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

import '../../../helpers/constants/colors.dart';
import '../../widgets/app_bar.dart';
import '../../widgets/custom_buttons.dart';
import 'online_payment_help_desk_viewmodel.dart';

class OnlinePaymentHelpDeskView extends StatelessWidget {
  const OnlinePaymentHelpDeskView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<OnlinePaymentHelpDeskViewModel>.nonReactive(
        viewModelBuilder: () => OnlinePaymentHelpDeskViewModel(),
        builder: (context, model, child) => Scaffold(
              backgroundColor: AppColors.white,
              appBar: const TefzonAppBar(
                text: "Live Support",
                useXIcon: false,
              ),
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 35,
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "I want to change my delivery address.",
                        style: TextStyle(
                            color: AppColors.text60,
                            fontSize: 19,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    const Text(
                      'Please write your new delivery address in the box below. After your entry, you will be transferred to our relevant agent.',
                      style: TextStyle(
                        fontSize: 16,
                        color: AppColors.textgrey,
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    SizedBox(
                      height: 250,
                      child: Row(
                        children: [
                          Column(
                            children: [
                              Container(
                                width: 28.0,
                                height: 28.0,
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(25.0)),
                                  border: Border.all(
                                    color: AppColors.primary,
                                    width: 1.0,
                                  ),
                                ),
                                child: const Center(
                                    child: Text(
                                  "1",
                                  style: TextStyle(color: AppColors.white),
                                )),
                              ),
                              Expanded(
                                child: Container(
                                  width: 2,
                                  color: AppColors.primary,
                                ),
                              ),
                              Container(
                                width: 28.0,
                                height: 28.0,
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(25.0)),
                                  border: Border.all(
                                    color: AppColors.primary,
                                    width: 1.0,
                                  ),
                                ),
                                child: const Center(
                                    child: Text(
                                  "2",
                                  style: TextStyle(color: AppColors.white),
                                )),
                              ),
                              Expanded(
                                child: Container(
                                  width: 2,
                                  color: AppColors.primary,
                                ),
                              ),
                              Container(
                                width: 28.0,
                                height: 28.0,
                                decoration: BoxDecoration(
                                  color: AppColors.primary,
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(25.0)),
                                  border: Border.all(
                                    color: AppColors.primary,
                                    width: 1.0,
                                  ),
                                ),
                                child: const Center(
                                    child: Text(
                                  "3",
                                  style: TextStyle(color: AppColors.white),
                                )),
                              ),
                            ],
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: const [
                                Text(
                                  "Check with your bank about adjusting daily withdrawal or purchase limits.",
                                  style: TextStyle(
                                      color: AppColors.text60,
                                      fontSize: 19,
                                      fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  "Make sure your bank has your most recent contact information.",
                                  style: TextStyle(
                                      color: AppColors.text60,
                                      fontSize: 19,
                                      fontWeight: FontWeight.w500),
                                ),
                                Text(
                                  "Check you have your current payment details stored in your account.",
                                  style: TextStyle(
                                      color: AppColors.text60,
                                      fontSize: 19,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 35,
                    ),
                    const Center(
                      child: Text(
                        "Was this helpful?",
                        style: TextStyle(
                            color: AppColors.text60,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: CustomButton(
                          text: "No",
                          onTap: () {},
                          isFilled: false,
                          isPrimary: false,
                        )),
                        const SizedBox(
                          width: 15,
                        ),
                        Expanded(
                            child: CustomButton(
                          text: "Yes",
                          onTap: () {},
                          isFilled: true,
                          isPrimary: false,
                        )),
                      ],
                    )
                  ],
                ),
              ),
            ));
  }
}
