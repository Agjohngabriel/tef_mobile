import 'package:stacked/stacked.dart';

class OnlinePaymentHelpDeskViewModel extends BaseViewModel {}
