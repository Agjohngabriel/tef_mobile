import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';

import '../../../model/squad.dart';
import '../../../services/core_services/squad_service.dart';

class ConfirmSquadViewModel extends BaseViewModel {
  final _router = locator<GoRouter>();
  final SquadService _squadService = locator<SquadService>();

  Squad? squad;

  void gotoHome() {
    _router.go(AppRoutes.home);
  }
}
