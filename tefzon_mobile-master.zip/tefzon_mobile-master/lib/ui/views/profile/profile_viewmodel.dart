import 'dart:convert';

import 'package:http/http.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/model/user.dart';
import 'package:tefzon_mobile/services/core_services/user_services.dart';

import '../../../app/locator.dart';
import '../../../services/api.dart';

class ProfileViewModel extends FutureViewModel<User> {
  final _api = locator<Api>();
  final _user = locator<UserService>();
  int? _leaguecount;
  int? get leaguecount => _leaguecount;

  Future<User> getProfile() async {
    final id = _user.user?.id;
    var response = await _api.getData('gamers/$id');
    var parsed = json.decode(response.body)["data"];
    final user = (User.fromJson(parsed));
    await getStats();
    return user;
  }

  Future<void> getStats() async {
    var response = await _api.getWallet("user/leagues");
    var responseData = json.decode(response.body);
    _leaguecount = responseData["data"].length;
    notifyListeners();
  }

  @override
  Future<User> futureToRun() => getProfile();
}
