import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/colors.dart';
import 'package:tefzon_mobile/ui/views/profile/profile_viewmodel.dart';
import 'package:tefzon_mobile/ui/views/wallet/widgets/numbers_widget.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<ProfileViewModel>.reactive(
        viewModelBuilder: () => ProfileViewModel(),
        builder: (context, model, child) => Scaffold(
            appBar: AppBar(
              title: const Text("Profile"),
              elevation: 0,
              backgroundColor: AppColors.primary,
              centerTitle: true,
            ),
            body: model.hasError
                ? Container(
                    color: Colors.red,
                    alignment: Alignment.center,
                    child: const Text(
                      'An error has occered while running the future',
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : model.isBusy
                    ? const Center(
                        child: SpinKitThreeBounce(
                        color: AppColors.primary,
                      ))
                    : ListView(
                        physics: const BouncingScrollPhysics(),
                        children: [
                          const SizedBox(height: 34),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 25.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  children: [
                                    Text(
                                      "${model.data?.firstName} ${model.data?.lastName}",
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 24),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      "${model.data?.email}",
                                      style:
                                          const TextStyle(color: Colors.grey),
                                    )
                                  ],
                                ),
                                InkWell(onTap: () {}, child: buildEditIcon())
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          const SizedBox(height: 24),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              buildDivider(),
                              buildButton(
                                  context, "${model.leaguecount}", 'Leagues'),
                              buildDivider(),
                              buildButton(
                                  context, "${model.leaguecount}", 'Games'),
                            ],
                          ),
                          const SizedBox(height: 48),
                          buildAbout(
                              "Phone",
                              model.data?.phone == null
                                  ? ""
                                  : "${model.data?.phone}"),
                          const SizedBox(height: 28),
                          buildAbout(
                              "Gender",
                              model.data?.gender == null
                                  ? ""
                                  : "${model.data?.gender}"),
                          const SizedBox(height: 28),
                          buildAbout(
                              "Date of Birth",
                              model.data?.dob == null
                                  ? ""
                                  : DateFormat('dd-MM-yyyy')
                                      .format(model.data!.dob!)),
                          const SizedBox(height: 28),
                          buildAbout(
                              "Country",
                              model.data?.country == null
                                  ? ""
                                  : "${model.data?.country}"),
                        ],
                      )));
  }

  Widget buildEditIcon() => buildCircle(
        color: Colors.white,
        all: 3,
        child: buildCircle(
          color: AppColors.primary,
          all: 8,
          child: const Icon(
            Icons.edit,
            color: AppColors.white,
            size: 20,
          ),
        ),
      );

  Widget buildCircle({
    required Widget child,
    required double all,
    required Color color,
  }) =>
      ClipOval(
        child: Container(
          padding: EdgeInsets.all(all),
          color: color,
          child: child,
        ),
      );
  Widget buildAbout(String title, String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
          ],
        ),
      );
  Widget buildDivider() => const SizedBox(
        height: 24,
        child: VerticalDivider(),
      );

  Widget buildButton(BuildContext context, String value, String text) =>
      MaterialButton(
        padding: const EdgeInsets.symmetric(vertical: 4),
        onPressed: () {},
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
            ),
            const SizedBox(height: 2),
            Text(
              text,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      );
}
