import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/extensions/build_context/text_theme.dart';
import 'package:tefzon_mobile/model/player_info.dart';
import 'package:tefzon_mobile/ui/views/pick_player/pick_player_viewmodel.dart';

import '../../../helpers/constants/colors.dart';

class PickPlayer extends StatelessWidget {
  const PickPlayer({Key? key, required this.id}) : super(key: key);

  final int id;

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PickPlayerViewModel>.reactive(
        viewModelBuilder: () => PickPlayerViewModel(),
        onModelReady: (model) async {
          await model.fetchPlayerById(id);
        },
        builder: (context, model, child) => Scaffold(
              appBar: AppBar(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("${getTitle(id)}"),
                  ],
                ),
                elevation: 0,
                backgroundColor: Colors.deepPurpleAccent,
              ),
              body: model.isBusy
                  ? Center(
                      child: SpinKitFadingCircle(
                      color: AppColors.primary,
                    ))
                  : Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: ListView(
                        children: [
                          ...model.players.map((e) => ListTile(
                                onTap: () => showModalBottomSheet(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return FutureBuilder<PlayerInfo>(
                                          future: model
                                              .fetchPlayerInfo(e.positionId),
                                          builder: (context, snap) {
                                            if (snap.connectionState ==
                                                ConnectionState.done) {
                                              // If we got an error
                                              if (snap.hasError) {
                                                print(snap.error);
                                                return Center(
                                                  child: Text(
                                                    '${snap.error} occurred',
                                                    style:
                                                        TextStyle(fontSize: 18),
                                                  ),
                                                );

                                                // if we got our data
                                              } else if (snap.hasData) {
                                                // Extracting data from snap object
                                                return Container(
                                                  padding: EdgeInsets.all(10),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      ListTile(
                                                        leading: CircleAvatar(
                                                          backgroundImage:
                                                              NetworkImage(
                                                                  "${snap.data?.imagePath}"),
                                                        ),
                                                        title: Row(
                                                          children: [
                                                            Text(
                                                                "${snap.data?.displayName}"),
                                                            SizedBox(
                                                              width: 10,
                                                            ),
                                                            Text(
                                                              "h - ${snap.data?.height} w -${snap.data?.weight}",
                                                              style: context
                                                                  .textTheme
                                                                  .caption,
                                                            ),
                                                          ],
                                                        ),
                                                        subtitle: Text(
                                                            "${snap.data?.nationality}"),
                                                      ),
                                                      SizedBox(
                                                        height: 20,
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          Navigator.pop(
                                                              context);
                                                          model.joinSquad(
                                                              e.playerId);
                                                        },
                                                        child: Container(
                                                          margin: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      10),
                                                          padding:
                                                              EdgeInsets.all(
                                                                  10),
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          17),
                                                              border:
                                                                  Border.all(
                                                                      color: AppColors
                                                                          .primary,
                                                                      width:
                                                                          1)),
                                                          child: Text("Select"),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }
                                            }

                                            // Displaying LoadingSpinner to indicate waiting state
                                            return Center(
                                                child: SpinKitFadingCircle(
                                              color: AppColors.primary,
                                            ));
                                          });
                                    }),
                                leading: CircleAvatar(
                                  backgroundImage:
                                      NetworkImage("${e.imagePath}"),
                                ),
                                title: Text("${e.displayName}"),
                                subtitle: Text("${e.nationality}"),
                                trailing: Text("${e.shortTeamName}"),
                              ))
                        ],
                      ),
                    ),
            ));
  }

  String getTitle(int id) {
    switch (id) {
      case 1:
        return "GoalKeepers";
      case 2:
        return "Defenders";

      case 3:
        return "Midfielders";

      case 4:
        return "Forwards";

      default:
        return "GoalKeeper";
    }
  }
}
