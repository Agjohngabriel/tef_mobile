import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/helpers/constants/routes.dart';

import '../../../app/locator.dart';
import '../../../model/player.dart';
import '../../../model/player_info.dart';
import '../../../services/api.dart';
import '../../../services/core_services/squad_service.dart';

class PickPlayerViewModel extends BaseViewModel {
  final _api = locator<Api>();
  final _squadService = locator<SquadService>();

  var players = <Player>[];
  String seasonId = "19699";
  Future<void> fetchPlayerById(int id) async {
    print(seasonId);
    setBusy(true);
    players = <Player>[];
    var response = await _api.getData("get/all/players/${seasonId}/$id");
    var parsed = json.decode(response.body) as List<dynamic>;
    for (var favourite in parsed) {
      players.add(Player.fromJson(favourite));
    }
    setBusy(false);
  }

  Future<PlayerInfo> fetchPlayerInfo(int? id) async {
    var result = await _api.getData("get/player/$id");
    print("done");
    return PlayerInfo.fromJson(jsonDecode(result.body));
  }

  void joinSquad(int? id) async {
    setBusy(true);
    final data = {
      "player_id": id,
    };
    await _api.postData("add/player", data).then((value) {
      print(value.statusCode);
      if (value.statusCode == 201) {
        _squadService.fetchSquad();
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: const Text('Success'),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext).pop();
                        locator<GoRouter>()
                            .go(AppRoutes.selectSqaud); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      } else if (value.statusCode == 422) {
        OneContext().dialog.showDialog<void>(
              barrierDismissible: true,
              // false = user must tap button, true = tap outside dialog
              builder: (BuildContext dialogContext) {
                return AlertDialog(
                  title: Text(jsonDecode(value.body)["message"]),
                  actions: <Widget>[
                    TextButton(
                      child: const Text('Ok'),
                      onPressed: () {
                        Navigator.of(dialogContext)
                            .pop(); // Dismiss alert dialog
                      },
                    ),
                  ],
                );
              },
            );
      }
    });
    setBusy(false);
  }
}
