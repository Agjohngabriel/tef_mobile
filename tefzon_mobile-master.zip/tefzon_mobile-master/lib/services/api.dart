import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/model/favourite_league.dart';
import 'package:tefzon_mobile/model/league.dart';
import 'package:tefzon_mobile/model/user.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';

@LazySingleton()
class Api {
  static const endpoint = 'https://tefzon.com/api';
  // static const endpoint = 'http://127.0.0.1:8000/api';

  var client = http.Client();
  String? token = locator<SharedStorage>().token ?? "";
  Map<String, String> mainHeaders = {
    'Content-Type': 'application/json; charset=UTF-8',
    'Authorization':
        'Bearer ${locator<SharedStorage>().token?.replaceAll(RegExp(r'"'), '') ?? ""}'
  };

  Uri formatUri(string) {
    return Uri.parse(string);
  }

  Future<Response> postData(String url, Object data) async {
    Response response = await client.post(formatUri("$endpoint/$url"),
        body: jsonEncode(data), headers: mainHeaders);
    print(response.body);
    return response;
  }

  Future<Response> getData(String url) async {
    print(mainHeaders);
    Response response =
        await client.get(formatUri("$endpoint/$url"), headers: mainHeaders);
    print(response.body);
    return response;
  }

  Future<Response> deleteData(String url) async {
    print(mainHeaders);
    Response response =
        await client.delete(formatUri("$endpoint/$url"), headers: mainHeaders);
    print(response.body);
    return response;
  }

  Future<User> getUserProfile(int userId) async {
    var response = await client.get(formatUri("$endpoint" '/get/league/teams'));
    var result = jsonDecode(response.body);
    return User.fromJson(result.data);
  }

  Future<List<Favourite>> getTeams(String id) async {
    var favourites = <Favourite>[];
    var response =
        await client.get(formatUri("$endpoint" '/get/league/teams/$id'));
    var parsed = json.decode(response.body) as List<dynamic>;
    for (var favourite in parsed) {
      favourites.add(Favourite.fromJson(favourite));
    }

    return favourites;
  }

  Future<List<Leagues>> getleagues() async {
    var leagues = <Leagues>[];
    var response = await client.get(formatUri("$endpoint" '/get/leagues'));
    var parsed = json.decode(response.body) as List<dynamic>;
    for (var favourite in parsed) {
      leagues.add(Leagues.fromJson(favourite));
    }

    return leagues;
  }

  Future<Response> fetchFixtures(String url) async {
    Response response = await client.post(formatUri("$endpoint/$url"),
        body: jsonEncode({"start": "2022-2-14", "end": "2022-3-14"}),
        headers: mainHeaders);
    print(response.body);
    return response;
  }

  Future<Response> getWallet(String url) async {
    print(mainHeaders);
    Response response =
        await client.get(formatUri("$endpoint/$url"), headers: mainHeaders);
    print(response.body);
    return response;
  }
}
