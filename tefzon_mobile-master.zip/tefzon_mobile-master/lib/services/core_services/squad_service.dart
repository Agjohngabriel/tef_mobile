import 'dart:convert';

import 'package:http/http.dart';
import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/model/squad.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';

import '../../app/locator.dart';
import '../api.dart';

class SquadService with ReactiveServiceMixin {
  final _api = locator<Api>();
  final savedSquad = locator<SharedStorage>().squad;
  final ReactiveValue<List<GoalKeepers>> _goalkeepers =
      ReactiveValue<List<GoalKeepers>>(List<GoalKeepers>.empty());
  List<GoalKeepers> get goalkeepers => _goalkeepers.value;
  final ReactiveValue<List<Defender>> _defenders =
      ReactiveValue<List<Defender>>(List<Defender>.empty());
  List<Defender> get defenders => _defenders.value;
  final ReactiveValue<List<MidFielders>> _midfielders =
      ReactiveValue<List<MidFielders>>(List<MidFielders>.empty());
  List<MidFielders> get midfielders => _midfielders.value;
  final ReactiveValue<List<Forwards>> _forwards =
      ReactiveValue<List<Forwards>>(List<Forwards>.empty());
  List<Forwards> get forwards => _forwards.value;
  final ReactiveValue<List<Subs>> _subs =
      ReactiveValue<List<Subs>>(List<Subs>.empty());
  List<Subs> get subs => _subs.value;

  final ReactiveValue<Squad?> _squad = ReactiveValue<Squad?>(null);
  Squad? get squad => _squad.value;

  SquadService() {
    listenToReactiveValues([_goalkeepers, _defenders, _midfielders, _subs]);
    getSquadDetails();
  }

  void fetchSquad() async {
    fetchGoalkeepers();
    fetchDefenders();
    fetchMidfielders();
    fetchForwards();
  }

  void fetchAll() async {
    Response response = await _api.getData("get/my/squad");
    if (response.statusCode == 200) {
      _squad.value = Squad.fromJson(jsonDecode(response.body));
      notifyListeners();
    }
  }

  void fetchGoalkeepers() async {
    Response response = await _api.getData("get/my/goalkeepers");
    if (response.statusCode == 200) {
      final data = <GoalKeepers>[];
      for (var i in jsonDecode(response.body)) {
        data.add(GoalKeepers.fromJson(i));
      }
      _goalkeepers.value = data;
      notifyListeners();
    }
  }

  void fetchDefenders() async {
    Response response = await _api.getData("get/my/defenders");
    if (response.statusCode == 200) {
      final data = <Defender>[];
      for (var i in jsonDecode(response.body)) {
        data.add(Defender.fromJson(i));
      }
      _defenders.value = data;
      notifyListeners();
    }
  }

  void fetchMidfielders() async {
    Response response = await _api.getData("get/my/midfielders");
    if (response.statusCode == 200) {
      if (response.statusCode == 200) {
        final data = <MidFielders>[];
        for (var i in jsonDecode(response.body)) {
          data.add(MidFielders.fromJson(i));
        }
        _midfielders.value = data;
        notifyListeners();
      }
    }
  }

  void fetchForwards() async {
    Response response = await _api.getData("get/my/forwards");
    if (response.statusCode == 200) {
      final data = <Forwards>[];
      for (var i in jsonDecode(response.body)) {
        data.add(Forwards.fromJson(i));
      }
      _forwards.value = data;
      notifyListeners();
    }
  }

  void fetchSubs() async {
    Response response = await _api.getData("get/my/squad");
    if (response.statusCode == 200) {
      // _sharedStorage.saveToDisk(AppKeys.userSquad, response.body);
      // getSquad(Squad.fromJson(jsonDecode(response.body)));
    }
  }

  void getSquadDetails() {
    fetchSquad();
    // on app init
    // _squad.value = savedSquad;
  }
}
