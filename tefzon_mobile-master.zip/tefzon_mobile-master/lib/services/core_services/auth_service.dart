import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:stacked/stacked_annotations.dart';
import 'package:tefzon_mobile/helpers/constants/app_keys.dart';
import 'package:tefzon_mobile/model/user.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';
import 'package:tefzon_mobile/services/core_services/user_services.dart';

import '../../app/locator.dart';
import '../../model/response.dart';
import '../api.dart';

@LazySingleton()
class AuthService {
  final _api = locator<Api>();
  final _userService = locator<UserService>();
  Future<ResponseModel> login(Object data) async {
    final result = await _api.postData("login", data);
    if (kDebugMode) {
      print(result.body);
    }
    if (kDebugMode) {
      print(result.statusCode);
    }
    ResponseModel responseModel;
    if (result.statusCode == 200) {
      var it = jsonDecode(result.body);
      responseModel = ResponseModel(true, 'successful', 200);
      _userService.getUser(User.fromJson(it['user']));
      _api.mainHeaders = {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${jsonEncode(it['token']).replaceAll(RegExp(r'"'), '')}'
      };
      locator<SharedStorage>()
          .saveToDisk(AppKeys.userToken, jsonEncode(it['token']));
      locator<SharedStorage>()
          .saveToDisk(AppKeys.userKey, jsonEncode(it['user']));
    } else if (result.statusCode == 422) {
      responseModel = ResponseModel(false, result.body, 422);
    } else if (result.statusCode == 404) {
      responseModel = ResponseModel(false, "", 404);
    } else {
      responseModel = ResponseModel(false, "", 0);
    }
    return responseModel;
  }

  Future<ResponseModel> register(Object data) async {
    final result = await _api.postData("register", data);
    if (kDebugMode) {
      print(result.body);
    }
    if (kDebugMode) {
      print(result.statusCode);
    }
    ResponseModel responseModel;
    if (result.statusCode == 201) {
      var it = jsonDecode(result.body);
      responseModel = ResponseModel(true, 'successful', 200);
      _userService.getUser(User.fromJson(it['user']));
      _api.mainHeaders = {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization':
            'Bearer ${jsonEncode(it['token']).replaceAll(RegExp(r'"'), '')}'
      };
      locator<SharedStorage>()
          .saveToDisk(AppKeys.userToken, jsonEncode(it['token']));
      locator<SharedStorage>()
          .saveToDisk(AppKeys.userKey, jsonEncode(it['user']));
    } else if (result.statusCode == 422) {
      responseModel = ResponseModel(false, result.body, 422);
    } else if (result.statusCode == 404) {
      responseModel = ResponseModel(false, "", 404);
    } else {
      responseModel = ResponseModel(false, "", 0);
    }
    return responseModel;
  }

  Future<ResponseModel> logout() async {
    locator<SharedStorage>().clearFromDisk(AppKeys.userToken);
    locator<SharedStorage>().clearFromDisk(AppKeys.userKey);
    locator<SharedStorage>().clearFromDisk(AppKeys.LoggedInKey);
    final result = await _api.getData("logout");
    if (kDebugMode) {
      print(result.body);
    }
    if (kDebugMode) {
      print(result.statusCode);
    }
    ResponseModel responseModel;
    if (result.statusCode == 200) {
      responseModel = ResponseModel(true, 'successful', 200);
      locator<SharedStorage>().clearFromDisk(AppKeys.userToken);
      locator<SharedStorage>().clearFromDisk(AppKeys.userKey);
      locator<SharedStorage>().clearFromDisk(AppKeys.LoggedInKey);
    } else if (result.statusCode == 422) {
      responseModel = ResponseModel(false, result.body, 422);
    } else if (result.statusCode == 404) {
      responseModel = ResponseModel(false, "", 404);
    } else {
      responseModel = ResponseModel(false, "", 0);
    }
    return responseModel;
  }

  // void logout() async{
  //   final result = await _api.postData(", data)
  // }

  // Future<Data> getUserProfile(int userId) async {
  //   var response = await client.get(formatUri("$endpoint" '/get/league/teams'));
  //   var result = jsonDecode(response.body);
  //   return Data.fromJson(result.data);
  // }
  //
  // Future<List<Favourite>> getTeams() async {
  //   var favourites = <Favourite>[];
  //   var response = await client.get(formatUri("$endpoint" '/get/league/teams'));
  //   var parsed = json.decode(response.body) as List<dynamic>;
  //   for (var favourite in parsed) {
  //     favourites.add(Favourite.fromJson(favourite));
  //   }
  //
  //   return favourites;
  // }
}
