import 'package:stacked/stacked.dart';
import 'package:tefzon_mobile/app/locator.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';

import '../../model/user.dart';

class UserService with ReactiveServiceMixin {
  final savedUser = locator<SharedStorage>().user;
  final _user = ReactiveValue<User?>(null);

  User? get user => _user.value;

  UserService() {
    listenToReactiveValues([_user]);
    getUserDetails();
  }

  void getUserDetails() {
    // get user data here, from storage, etc.
    // on app init
    _user.value = savedUser;
    notifyListeners();
  }

  Future<void> getUser(User user) async {
    // //
    // await Future.delayed(const Duration(milliseconds: 500));
    _user.value = user;
    notifyListeners();
    //
  }

  void deauthenticate() => _user.value = null;
}
