import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tefzon_mobile/helpers/constants/app_keys.dart';

import '../../model/squad.dart';
import '../../model/user.dart';

class SharedStorage {
  static SharedStorage? _instance;
  static SharedPreferences? _preferences;
  static Future<SharedStorage> getInstance() async {
    _instance ??= SharedStorage();

    _preferences ??= await SharedPreferences.getInstance();

    return (_instance as SharedStorage);
  }

  User? get user {
    var userJson = _getFromDisk(AppKeys.userKey);
    if (userJson == null) {
      return null;
    }
    return User.fromJson(jsonDecode(userJson));
  }

  Squad? get squad {
    var userJson = _getFromDisk(AppKeys.userKey);
    if (userJson == null) {
      return null;
    }
    return Squad.fromJson(jsonDecode(userJson));
  }

  String? get token {
    var token = _getFromDisk(AppKeys.userToken);
    if (token == null) {
      return null;
    }
    return token;
  }

  set user(User? userToSave) {
    saveToDisk(AppKeys.userKey, jsonEncode(userToSave?.toJson()));
  }

  set squad(Squad? squadToSave) {
    saveToDisk(AppKeys.userSquad, jsonEncode(squadToSave?.toJson()));
  }

  dynamic _getFromDisk(String key) {
    final value = _preferences?.get(key);
    print('(TRACE) SharedStorage:_getFromDisk. key: $key value: $value');
    return value;
  }

  void clearFromDisk(String key) {
    final value = _preferences?.remove(key);
    if (kDebugMode) {
      print('(TRACE) SharedStorage:_getFromDisk. key: $key value: $value');
    }
  }

  void saveToDisk<T>(String key, T content) {
    print(
        '(TRACE) LocalStorageService:_saveStringToDisk. key: $key value: $content');
    if (content is String) {
      _preferences?.setString(key, content);
    }
    if (content is bool) {
      _preferences?.setBool(key, content);
    }
    if (content is int) {
      _preferences?.setInt(key, content);
    }
    if (content is double) {
      _preferences?.setDouble(key, content);
    }
    if (content is List<String>) {
      _preferences?.setStringList(key, content);
    }
  }

  bool get hasLoggedIn => _getFromDisk(AppKeys.LoggedInKey) ?? false;
  set hasLoggedIn(bool value) => saveToDisk(AppKeys.LoggedInKey, value);
}
