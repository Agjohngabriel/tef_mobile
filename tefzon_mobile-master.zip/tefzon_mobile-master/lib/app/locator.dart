import 'package:get_it/get_it.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked_services/stacked_services.dart';
import 'package:tefzon_mobile/app/router.dart';
import 'package:tefzon_mobile/services/api.dart';
import 'package:tefzon_mobile/services/core_services/auth_service.dart';
import 'package:tefzon_mobile/services/core_services/shared_storage.dart';
import 'package:tefzon_mobile/ui/views/home/home_viewmodel.dart';

import '../services/core_services/squad_service.dart';
import '../services/core_services/user_services.dart';

GetIt locator = GetIt.instance;

Future setUpLocator() async {
  locator.registerSingleton<GoRouter>(router());
  locator.registerSingleton(DialogService());

  var sharedStorage = await SharedStorage.getInstance();
  locator.registerSingleton(sharedStorage);
  locator.registerLazySingleton(() => Api());
  locator.registerLazySingleton(() => AuthService());
  locator.registerLazySingleton(() => UserService());
  locator.registerLazySingleton(() => SquadService());
  locator.registerLazySingleton<HomeViewModel>(() => HomeViewModel());
}
