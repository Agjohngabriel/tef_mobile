import 'package:go_router/go_router.dart';
import 'package:tefzon_mobile/ui/views/about_app/about_view.dart';
import 'package:tefzon_mobile/ui/views/faq/faq_view.dart';
import 'package:tefzon_mobile/ui/views/favourites/favourites.dart';
import 'package:tefzon_mobile/ui/views/favourites_leagues/favourites_leagues.dart';
import 'package:tefzon_mobile/ui/views/home/home_view.dart';
import 'package:tefzon_mobile/ui/views/login/login_view.dart';
import 'package:tefzon_mobile/ui/views/my_leagues/create_league_view.dart';
import 'package:tefzon_mobile/ui/views/profile/profile_view.dart';
import 'package:tefzon_mobile/ui/views/register_view/register_view.dart';
import 'package:tefzon_mobile/ui/views/select_captain/select_captain_view.dart';
import 'package:tefzon_mobile/ui/views/select_squad/select_squad_view.dart';
import 'package:tefzon_mobile/ui/views/splash/splash_view.dart';
import 'package:tefzon_mobile/ui/views/starting_eleven/starting_eleven_view.dart';

import '../helpers/constants/routes.dart';
import 'package:flutter/material.dart';

import '../model/league.dart';
import '../ui/views/confirm_squad/confirm_squad_view.dart';
import '../ui/views/live_support/live_support_view.dart';
import '../ui/views/live_support/q_a_view.dart';
import '../ui/views/live_support_webview/live_support_webview.dart';
import '../ui/views/my_squad/my_squad_view.dart';
import '../ui/views/online_payment_help_desk_view/online_payment_help_desk_view.dart';
import '../ui/views/pick_player/pick_player_view.dart';
import '../ui/views/wallet/wallet_view.dart';
import '../ui/views/select_vice_captain/select_vice_captain_view.dart';
import '../ui/views/support/support_view.dart';
import '../ui/views/support_request/support_request_view.dart';

GoRouter router() {
  return GoRouter(routes: <GoRoute>[
    GoRoute(
      name: 'splash',
      path: AppRoutes.splashScreen,
      builder: (BuildContext context, GoRouterState state) =>
          const SplashView(),
    ),
    GoRoute(
      name: 'patients',
      path: AppRoutes.home,
      builder: (BuildContext context, GoRouterState state) => const HomeView(),
    ),
    GoRoute(
      name: 'login',
      path: AppRoutes.login,
      builder: (BuildContext context, GoRouterState state) => LoginView(),
    ),
    GoRoute(
      name: 'register',
      path: AppRoutes.register,
      builder: (BuildContext context, GoRouterState state) => RegisterView(),
    ),
    GoRoute(
      name: 'favourites',
      path: AppRoutes.favourites,
      builder: (BuildContext context, GoRouterState state) => FavouritesView(
        leagues: state.extra as Leagues,
      ),
    ),
    GoRoute(
      name: 'favourites-leagues',
      path: AppRoutes.favouritesLeagues,
      builder: (BuildContext context, GoRouterState state) =>
          const FavouritesLeaguesView(),
    ),
    GoRoute(
      name: 'select-squad',
      path: AppRoutes.selectSqaud,
      builder: (BuildContext context, GoRouterState state) =>
          const SelectSquadView(),
    ),
    GoRoute(
      name: 'starting-eleven',
      path: AppRoutes.startingEleven,
      builder: (BuildContext context, GoRouterState state) => StartingEleven(),
    ),
    GoRoute(
      name: 'choose-captain',
      path: AppRoutes.chooseCaptain,
      builder: (BuildContext context, GoRouterState state) => SelectCaptain(),
    ),
    GoRoute(
      name: 'choose-vice-captain',
      path: AppRoutes.chooseViceCaptain,
      builder: (BuildContext context, GoRouterState state) =>
          const SelectViceCaptain(),
    ),
    GoRoute(
      name: 'confirm-squad',
      path: AppRoutes.confirmSquad,
      builder: (BuildContext context, GoRouterState state) =>
          const ConfirmSquad(),
    ),
    GoRoute(
      name: 'profile',
      path: AppRoutes.profile,
      builder: (BuildContext context, GoRouterState state) => ProfileView(),
    ),
    GoRoute(
      name: 'wallet',
      path: AppRoutes.wallet,
      builder: (BuildContext context, GoRouterState state) => WalletView(),
    ),
    GoRoute(
      name: 'about',
      path: AppRoutes.about,
      builder: (BuildContext context, GoRouterState state) => AboutView(),
    ),
    GoRoute(
      name: 'faq',
      path: AppRoutes.faqView,
      builder: (BuildContext context, GoRouterState state) => FaqView(),
    ),
    GoRoute(
        name: 'support-view',
        path: AppRoutes.supportView,
        builder: (BuildContext context, GoRouterState state) =>
            const SupportView()),
    GoRoute(
        name: 'live-support-faq',
        path: AppRoutes.liveSupportFaq,
        builder: (BuildContext context, GoRouterState state) =>
            const LiveSupportView()),
    GoRoute(
        name: 'q-a-views',
        path: AppRoutes.qAViews,
        builder: (BuildContext context, GoRouterState state) =>
            const QAViews()),
    GoRoute(
        name: 'supports',
        path: AppRoutes.supports,
        builder: (BuildContext context, GoRouterState state) =>
            const LiveSupportWebView()),
    GoRoute(
        name: 'online-payment-help-desk-view',
        path: AppRoutes.onlinePaymentHelpDesk,
        builder: (BuildContext context, GoRouterState state) =>
            const OnlinePaymentHelpDeskView()),
    GoRoute(
        name: 'support-request-help-desk-view',
        path: AppRoutes.supportRequestHelpDesk,
        builder: (BuildContext context, GoRouterState state) =>
            const SupportRequestView()),
    GoRoute(
        name: 'create-league',
        path: AppRoutes.createLeague,
        builder: (BuildContext context, GoRouterState state) => CreateLeague()),
    GoRoute(
        name: 'my-squad',
        path: AppRoutes.mySquad,
        builder: (BuildContext context, GoRouterState state) =>
            const MySquad()),
    GoRoute(
        name: AppRoutes.pickPlayer,
        path: AppRoutes.pickPlayer,
        builder: (BuildContext context, GoRouterState state) => PickPlayer(
              id: state.extra as int,
            )),
  ]);
}
