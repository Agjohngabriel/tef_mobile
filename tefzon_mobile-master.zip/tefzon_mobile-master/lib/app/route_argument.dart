import 'package:flutter/material.dart';

class SeeAllViewArguments {
  final String title;
  final List<Widget> children;

  SeeAllViewArguments({required this.title, required this.children});
}
