import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';

import '../helpers/constants/app_keys.dart';
import '../helpers/constants/colors.dart';
import '../services/core_services/shared_storage.dart';
import 'app_theme.dart';
import 'locator.dart';

class TefzonApp extends StatelessWidget {
  TefzonApp({Key? key}) : super(key: key);
  final _router = locator<GoRouter>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Tefzon',

      /// See (https://medium.com/flutter-community/create-a-theme-and-primary-color-switcher-for-your-flutter-app-using-provider-fd334dd7d761)
      /// See (https://github.com/Roaa94/flutter-theme-switcher)
      theme: AppThemes.main(primaryColor: AppColors.primaryColorOptions[0]),
      debugShowCheckedModeBanner: false,
      routeInformationParser: _router.routeInformationParser,
      routerDelegate: _router.routerDelegate,
      builder: OneContext().builder,
    );
  }
}
