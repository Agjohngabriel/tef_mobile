class NewFixture {
  NewFixture({
    this.round_id,
    this.date_time,
    this.localTeam,
    this.visitorTeam,
    this.localTeamLogo,
    this.visitorTeamLogo,
  });

  int? round_id;
  String? date_time;
  String? localTeam;
  String? visitorTeam;
  String? localTeamLogo;
  String? visitorTeamLogo;

  factory NewFixture.fromJson(Map<String, dynamic> json) => NewFixture(
        round_id: json["round_id"],
        date_time: json["date_time"],
        localTeam: json['localTeam'],
        visitorTeam: json['visitorTeam'],
        localTeamLogo: json["localTeamLogo"],
        visitorTeamLogo: json['visitorTeamLogo'],
      );

  Map<String, dynamic> toJson() => {
        "round_id": round_id,
        "date_time": date_time,
        "localTeam": localTeam,
        "visitorTeam": visitorTeam,
        "localTeamLogo": localTeamLogo,
        "visitorTeamLogo": visitorTeamLogo,
      };
}
