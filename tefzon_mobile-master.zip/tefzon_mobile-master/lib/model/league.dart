// To parse this JSON data, do
//
//     final leagues = leaguesFromJson(jsonString);

import 'dart:convert';

List<Leagues> leaguesFromJson(String str) =>
    List<Leagues>.from(json.decode(str).map((x) => Leagues.fromJson(x)));

String leaguesToJson(List<Leagues> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Leagues {
  Leagues({
    this.id,
    required this.leagueId,
    required this.currentSeasonId,
    this.name,
    this.currentRoundId,
    this.currentStageId,
    this.countryId,
    this.logoPath,
    this.isCup,
  });

  int? id;
  String leagueId;
  String currentSeasonId;
  String? name;
  String? currentRoundId;
  String? currentStageId;
  String? countryId;
  String? logoPath;
  int? isCup;

  factory Leagues.fromJson(Map<String, dynamic> json) => Leagues(
        id: json["id"] == null ? null : json["id"],
        leagueId: json["league_id"] == null ? null : json["league_id"],
        currentSeasonId: json["current_season_id"] == null
            ? null
            : json["current_season_id"],
        name: json["name"] == null ? null : json["name"],
        currentRoundId:
            json["current_round_id"] == null ? null : json["current_round_id"],
        currentStageId:
            json["current_stage_id"] == null ? null : json["current_stage_id"],
        countryId: json["country_id"] == null ? null : json["country_id"],
        logoPath: json["logo_path"] == null ? null : json["logo_path"],
        isCup: json["is_cup"] == null ? null : json["is_cup"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "league_id": leagueId == null ? null : leagueId,
        "current_season_id": currentSeasonId == null ? null : currentSeasonId,
        "name": name == null ? null : name,
        "current_round_id": currentRoundId == null ? null : currentRoundId,
        "current_stage_id": currentStageId == null ? null : currentStageId,
        "country_id": countryId == null ? null : countryId,
        "logo_path": logoPath == null ? null : logoPath,
        "is_cup": isCup == null ? null : isCup,
      };
}
