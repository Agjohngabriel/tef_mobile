class WalletModel {
  WalletModel({
    this.id,
    this.user_id,
    this.balance,
    this.wins,
    this.loss,
    this.draw,
    this.cancelled,
    this.created_at,
    this.account_name,
    this.account_no,
    this.bank_name,
  });

  int? id;
  String? user_id;
  String? balance;
  String? wins;
  String? loss;
  String? draw;
  String? cancelled;
  String? created_at;
  String? account_name;
  String? account_no;
  String? bank_name;

  factory WalletModel.fromJson(Map<String, dynamic> json) => WalletModel(
        id: json["id"],
        user_id: json["user_id"],
        balance: json['balance'],
        wins: json['wins'],
        loss: json["loss"],
        draw: json['draw'],
        cancelled: json['cancelled'],
        created_at: json["created_at"],
        account_name: json['account_name'],
        account_no: json["account_no"],
        bank_name: json['bank_name'],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": user_id,
        "balance": balance,
        "wins": wins,
        "loss": loss,
        "draw": draw,
        "cancelled": cancelled,
        "created_at": created_at,
        "account_name": account_name,
        "account_no": account_no,
        "bank_name": bank_name
      };
}
