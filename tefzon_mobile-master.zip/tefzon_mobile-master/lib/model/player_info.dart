import 'dart:convert';

PlayerInfo playerInfoFromJson(String str) =>
    PlayerInfo.fromJson(json.decode(str));

String playerInfoToJson(PlayerInfo data) => json.encode(data.toJson());

class PlayerInfo {
  PlayerInfo({
    this.playerId,
    this.teamId,
    this.countryId,
    this.positionId,
    this.commonName,
    this.displayName,
    this.fullname,
    this.firstname,
    this.lastname,
    this.nationality,
    this.birthdate,
    this.birthcountry,
    this.birthplace,
    this.height,
    this.weight,
    this.imagePath,
    this.stats,
    this.team,
  });

  int? playerId;
  int? teamId;
  int? countryId;
  int? positionId;
  String? commonName;
  String? displayName;
  String? fullname;
  String? firstname;
  String? lastname;
  String? nationality;
  String? birthdate;
  String? birthcountry;
  dynamic birthplace;
  dynamic height;
  dynamic weight;
  String? imagePath;
  Stats? stats;
  Team? team;

  factory PlayerInfo.fromJson(Map<String, dynamic> json) => PlayerInfo(
        playerId: json["player_id"] == null ? null : json["player_id"],
        teamId: json["team_id"] == null ? null : json["team_id"],
        countryId: json["country_id"] == null ? null : json["country_id"],
        positionId: json["position_id"] == null ? null : json["position_id"],
        commonName: json["common_name"] == null ? null : json["common_name"],
        displayName: json["display_name"] == null ? null : json["display_name"],
        fullname: json["fullname"] == null ? null : json["fullname"],
        firstname: json["firstname"] == null ? null : json["firstname"],
        lastname: json["lastname"] == null ? null : json["lastname"],
        nationality: json["nationality"] == null ? null : json["nationality"],
        birthdate: json["birthdate"] == null ? null : json["birthdate"],
        birthcountry:
            json["birthcountry"] == null ? null : json["birthcountry"],
        birthplace: json["birthplace"],
        height: json["height"],
        weight: json["weight"],
        imagePath: json["image_path"] == null ? null : json["image_path"],
        stats: Stats.fromJson(json["stats"]),
        team: json["team"] == null ? null : Team.fromJson(json["team"]),
      );

  Map<String, dynamic> toJson() => {
        "player_id": playerId == null ? null : playerId,
        "team_id": teamId == null ? null : teamId,
        "country_id": countryId == null ? null : countryId,
        "position_id": positionId == null ? null : positionId,
        "common_name": commonName == null ? null : commonName,
        "display_name": displayName == null ? null : displayName,
        "fullname": fullname == null ? null : fullname,
        "firstname": firstname == null ? null : firstname,
        "lastname": lastname == null ? null : lastname,
        "nationality": nationality == null ? null : nationality,
        "birthdate": birthdate == null ? null : birthdate,
        "birthcountry": birthcountry == null ? null : birthcountry,
        "birthplace": birthplace,
        "height": height,
        "weight": weight,
        "image_path": imagePath == null ? null : imagePath,
        "stats": stats?.toJson(),
        "team": team?.toJson(),
      };
}

class Stats {
  Stats({
    this.data,
  });

  List<Datum>? data;

  factory Stats.fromJson(Map<String, dynamic> json) => Stats(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.playerId,
    this.teamId,
    this.leagueId,
    this.seasonId,
    this.captain,
    this.minutes,
    this.appearences,
    this.lineups,
    this.substituteIn,
    this.substituteOut,
    this.substitutesOnBench,
    this.goals,
    this.owngoals,
    this.assists,
    this.saves,
    this.insideBoxSaves,
    this.dispossesed,
    this.interceptions,
    this.yellowcards,
    this.yellowred,
    this.redcards,
    this.type,
    this.tackles,
    this.blocks,
    this.hitPost,
    this.cleansheets,
    this.rating,
    this.fouls,
    this.crosses,
    this.dribbles,
    this.shots,
    this.duels,
    this.passes,
    this.penalties,
  });

  int? playerId;
  int? teamId;
  int? leagueId;
  int? seasonId;
  int? captain;
  int? minutes;
  int? appearences;
  int? lineups;
  int? substituteIn;
  int? substituteOut;
  int? substitutesOnBench;
  int? goals;
  int? owngoals;
  int? assists;
  int? saves;
  int? insideBoxSaves;
  int? dispossesed;
  int? interceptions;
  int? yellowcards;
  int? yellowred;
  int? redcards;
  String? type;
  int? tackles;
  int? blocks;
  dynamic hitPost;
  int? cleansheets;
  String? rating;
  Fouls? fouls;
  Crosses? crosses;
  Dribbles? dribbles;
  Shots? shots;
  Duels? duels;
  Passes? passes;
  Penalties? penalties;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        playerId: json["player_id"] == null ? null : json["player_id"],
        teamId: json["team_id"] == null ? null : json["team_id"],
        leagueId: json["league_id"] == null ? null : json["league_id"],
        seasonId: json["season_id"] == null ? null : json["season_id"],
        captain: json["captain"] == null ? null : json["captain"],
        minutes: json["minutes"] == null ? null : json["minutes"],
        appearences: json["appearences"] == null ? null : json["appearences"],
        lineups: json["lineups"] == null ? null : json["lineups"],
        substituteIn:
            json["substitute_in"] == null ? null : json["substitute_in"],
        substituteOut:
            json["substitute_out"] == null ? null : json["substitute_out"],
        substitutesOnBench: json["substitutes_on_bench"] == null
            ? null
            : json["substitutes_on_bench"],
        goals: json["goals"] == null ? null : json["goals"],
        owngoals: json["owngoals"] == null ? null : json["owngoals"],
        assists: json["assists"] == null ? null : json["assists"],
        saves: json["saves"] == null ? null : json["saves"],
        insideBoxSaves:
            json["inside_box_saves"] == null ? null : json["inside_box_saves"],
        dispossesed: json["dispossesed"] == null ? null : json["dispossesed"],
        interceptions:
            json["interceptions"] == null ? null : json["interceptions"],
        yellowcards: json["yellowcards"] == null ? null : json["yellowcards"],
        yellowred: json["yellowred"] == null ? null : json["yellowred"],
        redcards: json["redcards"] == null ? null : json["redcards"],
        type: json["type"] == null ? null : json["type"],
        tackles: json["tackles"] == null ? null : json["tackles"],
        blocks: json["blocks"] == null ? null : json["blocks"],
        hitPost: json["hit_post"],
        cleansheets: json["cleansheets"] == null ? null : json["cleansheets"],
        rating: json["rating"] == null ? null : json["rating"],
        fouls: Fouls.fromJson(json["fouls"]),
        crosses: Crosses.fromJson(json["crosses"]),
        dribbles: Dribbles.fromJson(json["dribbles"]),
        shots: Shots.fromJson(json["shots"]),
        duels: Duels.fromJson(json["duels"]),
        passes: Passes.fromJson(json["passes"]),
        penalties: Penalties.fromJson(json["penalties"]),
      );

  Map<String, dynamic> toJson() => {
        "player_id": playerId == null ? null : playerId,
        "team_id": teamId == null ? null : teamId,
        "league_id": leagueId == null ? null : leagueId,
        "season_id": seasonId == null ? null : seasonId,
        "captain": captain == null ? null : captain,
        "minutes": minutes == null ? null : minutes,
        "appearences": appearences == null ? null : appearences,
        "lineups": lineups == null ? null : lineups,
        "substitute_in": substituteIn == null ? null : substituteIn,
        "substitute_out": substituteOut == null ? null : substituteOut,
        "substitutes_on_bench":
            substitutesOnBench == null ? null : substitutesOnBench,
        "goals": goals == null ? null : goals,
        "owngoals": owngoals == null ? null : owngoals,
        "assists": assists == null ? null : assists,
        "saves": saves == null ? null : saves,
        "inside_box_saves": insideBoxSaves == null ? null : insideBoxSaves,
        "dispossesed": dispossesed == null ? null : dispossesed,
        "interceptions": interceptions == null ? null : interceptions,
        "yellowcards": yellowcards == null ? null : yellowcards,
        "yellowred": yellowred == null ? null : yellowred,
        "redcards": redcards == null ? null : redcards,
        "type": type == null ? null : type,
        "tackles": tackles == null ? null : tackles,
        "blocks": blocks == null ? null : blocks,
        "hit_post": hitPost,
        "cleansheets": cleansheets == null ? null : cleansheets,
        "rating": rating == null ? null : rating,
        "fouls": fouls == null ? null : fouls?.toJson(),
        "crosses": crosses == null ? null : crosses?.toJson(),
        "dribbles": dribbles == null ? null : dribbles?.toJson(),
        "shots": shots == null ? null : shots?.toJson(),
        "duels": duels == null ? null : duels?.toJson(),
        "passes": passes == null ? null : passes?.toJson(),
        "penalties": penalties == null ? null : penalties?.toJson(),
      };
}

class Crosses {
  Crosses({
    this.total,
    this.accurate,
  });

  int? total;
  dynamic accurate;

  factory Crosses.fromJson(Map<String, dynamic> json) => Crosses(
        total: json["total"] == null ? null : json["total"],
        accurate: json["accurate"],
      );

  Map<String, dynamic> toJson() => {
        "total": total == null ? null : total,
        "accurate": accurate,
      };
}

class Dribbles {
  Dribbles({
    this.attempts,
    this.success,
    this.dribbledPast,
  });

  int? attempts;
  int? success;
  int? dribbledPast;

  factory Dribbles.fromJson(Map<String, dynamic> json) => Dribbles(
        attempts: json["attempts"] == null ? null : json["attempts"],
        success: json["success"] == null ? null : json["success"],
        dribbledPast:
            json["dribbled_past"] == null ? null : json["dribbled_past"],
      );

  Map<String, dynamic> toJson() => {
        "attempts": attempts == null ? null : attempts,
        "success": success == null ? null : success,
        "dribbled_past": dribbledPast == null ? null : dribbledPast,
      };
}

class Duels {
  Duels({
    this.total,
    this.won,
  });

  int? total;
  int? won;

  factory Duels.fromJson(Map<String, dynamic> json) => Duels(
        total: json["total"] == null ? null : json["total"],
        won: json["won"] == null ? null : json["won"],
      );

  Map<String, dynamic> toJson() => {
        "total": total == null ? null : total,
        "won": won == null ? null : won,
      };
}

class Fouls {
  Fouls({
    this.committed,
    this.drawn,
  });

  int? committed;
  int? drawn;

  factory Fouls.fromJson(Map<String, dynamic> json) => Fouls(
        committed: json["committed"] == null ? null : json["committed"],
        drawn: json["drawn"] == null ? null : json["drawn"],
      );

  Map<String, dynamic> toJson() => {
        "committed": committed == null ? null : committed,
        "drawn": drawn == null ? null : drawn,
      };
}

class Passes {
  Passes({
    this.total,
    this.accuracy,
    this.keyPasses,
  });

  int? total;
  int? accuracy;
  int? keyPasses;

  factory Passes.fromJson(Map<String, dynamic> json) => Passes(
        total: json["total"] == null ? null : json["total"],
        accuracy: json["accuracy"] == null ? null : json["accuracy"],
        keyPasses: json["key_passes"] == null ? null : json["key_passes"],
      );

  Map<String, dynamic> toJson() => {
        "total": total == null ? null : total,
        "accuracy": accuracy == null ? null : accuracy,
        "key_passes": keyPasses == null ? null : keyPasses,
      };
}

class Penalties {
  Penalties({
    this.won,
    this.scores,
    this.missed,
    this.committed,
    this.saves,
  });

  dynamic won;
  dynamic scores;
  dynamic missed;
  int? committed;
  dynamic saves;

  factory Penalties.fromJson(Map<String, dynamic> json) => Penalties(
        won: json["won"],
        scores: json["scores"],
        missed: json["missed"],
        committed: json["committed"] == null ? null : json["committed"],
        saves: json["saves"],
      );

  Map<String, dynamic> toJson() => {
        "won": won,
        "scores": scores,
        "missed": missed,
        "committed": committed == null ? null : committed,
        "saves": saves,
      };
}

class Shots {
  Shots({
    this.shotsTotal,
    this.shotsOnTarget,
  });

  int? shotsTotal;
  int? shotsOnTarget;

  factory Shots.fromJson(Map<String, dynamic> json) => Shots(
        shotsTotal: json["shots_total"] == null ? null : json["shots_total"],
        shotsOnTarget:
            json["shots_on_target"] == null ? null : json["shots_on_target"],
      );

  Map<String, dynamic> toJson() => {
        "shots_total": shotsTotal == null ? null : shotsTotal,
        "shots_on_target": shotsOnTarget == null ? null : shotsOnTarget,
      };
}

class Team {
  Team({
    this.data,
  });

  Data? data;

  factory Team.fromJson(Map<String, dynamic> json) => Team(
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? null : data?.toJson(),
      };
}

class Data {
  Data({
    this.id,
    this.legacyId,
    this.name,
    this.shortCode,
    this.twitter,
    this.countryId,
    this.nationalTeam,
    this.founded,
    this.logoPath,
    this.venueId,
    this.currentSeasonId,
    this.isPlaceholder,
  });

  int? id;
  int? legacyId;
  String? name;
  String? shortCode;
  dynamic twitter;
  int? countryId;
  bool? nationalTeam;
  int? founded;
  String? logoPath;
  int? venueId;
  int? currentSeasonId;
  bool? isPlaceholder;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"] == null ? null : json["id"],
        legacyId: json["legacy_id"] == null ? null : json["legacy_id"],
        name: json["name"] == null ? null : json["name"],
        shortCode: json["short_code"] == null ? null : json["short_code"],
        twitter: json["twitter"],
        countryId: json["country_id"] == null ? null : json["country_id"],
        nationalTeam:
            json["national_team"] == null ? null : json["national_team"],
        founded: json["founded"] == null ? null : json["founded"],
        logoPath: json["logo_path"] == null ? null : json["logo_path"],
        venueId: json["venue_id"] == null ? null : json["venue_id"],
        currentSeasonId: json["current_season_id"] == null
            ? null
            : json["current_season_id"],
        isPlaceholder:
            json["is_placeholder"] == null ? null : json["is_placeholder"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "legacy_id": legacyId == null ? null : legacyId,
        "name": name == null ? null : name,
        "short_code": shortCode == null ? null : shortCode,
        "twitter": twitter,
        "country_id": countryId == null ? null : countryId,
        "national_team": nationalTeam == null ? null : nationalTeam,
        "founded": founded == null ? null : founded,
        "logo_path": logoPath == null ? null : logoPath,
        "venue_id": venueId == null ? null : venueId,
        "current_season_id": currentSeasonId == null ? null : currentSeasonId,
        "is_placeholder": isPlaceholder == null ? null : isPlaceholder,
      };
}
