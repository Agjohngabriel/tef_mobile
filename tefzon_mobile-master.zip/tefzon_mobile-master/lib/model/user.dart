class User {
  User({
    this.id,
    this.firstName,
    this.lastName,
    this.username,
    this.avatar,
    this.email,
    this.referralLink,
    this.phone,
    this.gender,
    this.dob,
    this.country,
  });

  int? id;
  String? firstName;
  String? lastName;
  String? username;
  dynamic avatar;
  String? email;
  String? referralLink;
  dynamic phone;
  String? gender;
  DateTime? dob;
  String? country;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        username: json["username"],
        avatar: json["avatar"],
        email: json["email"],
        referralLink: json["referral_link"],
        phone: json["phone"],
        gender: json["gender"],
        dob: json["dob"] == null ? null : DateTime.parse(json["dob"]),
        country: json["country"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "username": username,
        "avatar": avatar,
        "email": email,
        "referral_link": referralLink,
        "phone": phone,
        "gender": gender,
        "dob": dob,
        "country": country,
      };
}
