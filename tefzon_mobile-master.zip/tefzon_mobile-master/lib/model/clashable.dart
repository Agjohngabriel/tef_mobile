class Clashable {
  final String name;

  const Clashable(this.name);
}