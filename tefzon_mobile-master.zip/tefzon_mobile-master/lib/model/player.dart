// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

List<Player> playerFromJson(String str) =>
    List<Player>.from(json.decode(str).map((x) => Player.fromJson(x)));

String playerToJson(List<Player> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Player {
  Player({
    this.playerId,
    this.positionId,
    this.isInjured,
    this.rating,
    this.position,
    this.imagePath,
    this.teamId,
    this.teamName,
    this.shortTeamName,
    this.displayName,
    this.nationality,
    this.height,
    this.weight,
    this.value,
  });

  int? playerId;
  int? positionId;
  bool? isInjured;
  dynamic rating;
  Position? position;
  String? imagePath;
  int? teamId;
  String? teamName;
  String? shortTeamName;
  String? displayName;
  String? nationality;
  String? height;
  String? weight;
  int? value;

  factory Player.fromJson(Map<String, dynamic> json) => Player(
        playerId: json["player_id"],
        positionId: json["position_id"],
        isInjured: json["is_injured"],
        rating: json["rating"],
        position: json["position"] == null
            ? null
            : positionValues.map[json["position"]],
        imagePath: json["image_path"],
        teamId: json["team_id"],
        teamName: json["team_name"],
        shortTeamName: json["short_team_name"],
        displayName: json["display_name"],
        nationality: json["nationality"],
        height: json["height"],
        weight: json["weight"],
        value: json["value"],
      );

  Map<String, dynamic> toJson() => {
        "player_id": playerId,
        "position_id": positionId,
        "is_injured": isInjured,
        "rating": rating,
        "position": position == null ? null : positionValues.reverse![position],
        "image_path": imagePath,
        "team_id": teamId,
        "team_name": teamName,
        "short_team_name": shortTeamName,
        "display_name": displayName,
        "nationality": nationality,
        "height": height,
        "weight": weight,
        "value": value,
      };
}

enum Position { FORWARD, MIDFIELDER, DEFENDER, GOAL_KEEPER }
final positionValues = EnumValues({
  "Defender": Position.DEFENDER,
  "Forward": Position.FORWARD,
  "GoalKeeper": Position.GOAL_KEEPER,
  "Midfielder": Position.MIDFIELDER
});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String>? get reverse {
    reverseMap;
    return reverseMap;
  }
}
