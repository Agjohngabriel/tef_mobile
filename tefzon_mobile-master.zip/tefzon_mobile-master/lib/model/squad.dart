// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

Squad playerFromJson(String str) => Squad.fromJson(json.decode(str));

String playerToJson(Squad data) => json.encode(data.toJson());

class Squad {
  Squad({
    this.goalkeepers,
    this.defenders,
    this.midfielders,
    this.forwards,
    this.subs,
  });

  List<GoalKeepers>? goalkeepers;
  List<Defender>? defenders;
  List<MidFielders>? midfielders;
  List<Forwards>? forwards;
  List<Subs>? subs;

  factory Squad.fromJson(Map<String, dynamic> json) => Squad(
        goalkeepers: json["goalkeepers"] == null
            ? null
            : List<GoalKeepers>.from(
                json["goalkeepers"].map((x) => GoalKeepers.fromJson(x))),
        defenders: json["defenders"] == null
            ? null
            : List<Defender>.from(
                json["defenders"].map((x) => Defender.fromJson(x))),
        midfielders: json["midfielders"] == null
            ? null
            : List<MidFielders>.from(
                json["midfielders"].map((x) => MidFielders.fromJson(x))),
        forwards: json["forwards"] == null
            ? null
            : List<Forwards>.from(
                json["forwards"].map((x) => Forwards.fromJson(x))),
        subs: json["subs"] == null
            ? null
            : List<Subs>.from(json["subs"].map((x) => Subs.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "goalkeepers": goalkeepers == null
            ? null
            : List<dynamic>.from(goalkeepers!.map((x) => x.toJson())),
        "defenders": defenders == null
            ? null
            : List<dynamic>.from(defenders!.map((x) => x.toJson())),
        "midfielders": midfielders == null
            ? null
            : List<dynamic>.from(midfielders!.map((x) => x.toJson())),
        "forwards": forwards == null
            ? null
            : List<dynamic>.from(forwards!.map((x) => x.toJson())),
        "subs": subs == null
            ? null
            : List<dynamic>.from(subs!.map((x) => x.toJson())),
      };
}

class GoalKeepers {
  GoalKeepers({
    this.id,
    this.squadNo,
    this.playerName,
    this.playerPosition,
    this.playerId,
    this.positionId,
    this.value,
    this.teamId,
    this.team,
    this.isCaptain,
    this.isViceCaptain,
    this.isAbsent,
    this.isInjured,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.imagePath,
    this.starting,
    this.nextFixture,
  });

  int? id;
  dynamic squadNo;
  String? playerName;
  String? playerPosition;
  int? playerId;
  int? positionId;
  int? value;
  int? teamId;
  String? team;
  int? isCaptain;
  int? isViceCaptain;
  int? isAbsent;
  int? isInjured;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? imagePath;
  int? starting;
  dynamic nextFixture;

  factory GoalKeepers.fromJson(Map<String, dynamic> json) => GoalKeepers(
        id: json["id"],
        squadNo: json["squad_no"],
        playerName: json["player_name"],
        playerPosition: json["player_position"],
        playerId: json["player_id"],
        positionId: json["position_id"],
        value: json["value"],
        teamId: json["team_id"],
        team: json["team"],
        isCaptain: json["is_captain"],
        isViceCaptain: json["is_vice_captain"],
        isAbsent: json["is_absent"],
        isInjured: json["is_injured"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        imagePath: json["image_path"],
        starting: json["starting"],
        nextFixture: json["next_fixture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "squad_no": squadNo,
        "player_name": playerName,
        "player_position": playerPosition,
        "player_id": playerId,
        "position_id": positionId,
        "value": value,
        "team_id": teamId,
        "team": team,
        "is_captain": isCaptain,
        "is_vice_captain": isViceCaptain,
        "is_absent": isAbsent,
        "is_injured": isInjured,
        "user_id": userId,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "image_path": imagePath,
        "starting": starting,
        "next_fixture": nextFixture,
      };
}

class Defender {
  Defender({
    this.id,
    this.squadNo,
    this.playerName,
    this.playerPosition,
    this.playerId,
    this.positionId,
    this.value,
    this.teamId,
    this.team,
    this.isCaptain,
    this.isViceCaptain,
    this.isAbsent,
    this.isInjured,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.imagePath,
    this.starting,
    this.nextFixture,
  });

  int? id;
  dynamic squadNo;
  String? playerName;
  String? playerPosition;
  int? playerId;
  int? positionId;
  int? value;
  int? teamId;
  String? team;
  int? isCaptain;
  int? isViceCaptain;
  int? isAbsent;
  int? isInjured;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? imagePath;
  int? starting;
  dynamic nextFixture;

  factory Defender.fromJson(Map<String, dynamic> json) => Defender(
        id: json["id"],
        squadNo: json["squad_no"],
        playerName: json["player_name"],
        playerPosition: json["player_position"],
        playerId: json["player_id"],
        positionId: json["position_id"],
        value: json["value"],
        teamId: json["team_id"],
        team: json["team"],
        isCaptain: json["is_captain"],
        isViceCaptain: json["is_vice_captain"],
        isAbsent: json["is_absent"],
        isInjured: json["is_injured"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        imagePath: json["image_path"],
        starting: json["starting"],
        nextFixture: json["next_fixture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "squad_no": squadNo,
        "player_name": playerName,
        "player_position": playerPosition,
        "player_id": playerId,
        "position_id": positionId,
        "value": value,
        "team_id": teamId,
        "team": team,
        "is_captain": isCaptain,
        "is_vice_captain": isViceCaptain,
        "is_absent": isAbsent,
        "is_injured": isInjured,
        "user_id": userId,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "image_path": imagePath,
        "starting": starting,
        "next_fixture": nextFixture,
      };
}

class MidFielders {
  MidFielders({
    this.id,
    this.squadNo,
    this.playerName,
    this.playerPosition,
    this.playerId,
    this.positionId,
    this.value,
    this.teamId,
    this.team,
    this.isCaptain,
    this.isViceCaptain,
    this.isAbsent,
    this.isInjured,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.imagePath,
    this.starting,
    this.nextFixture,
  });

  int? id;
  dynamic squadNo;
  String? playerName;
  String? playerPosition;
  int? playerId;
  int? positionId;
  int? value;
  int? teamId;
  String? team;
  int? isCaptain;
  int? isViceCaptain;
  int? isAbsent;
  int? isInjured;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? imagePath;
  int? starting;
  dynamic nextFixture;

  factory MidFielders.fromJson(Map<String, dynamic> json) => MidFielders(
        id: json["id"],
        squadNo: json["squad_no"],
        playerName: json["player_name"],
        playerPosition: json["player_position"],
        playerId: json["player_id"],
        positionId: json["position_id"],
        value: json["value"],
        teamId: json["team_id"],
        team: json["team"],
        isCaptain: json["is_captain"],
        isViceCaptain: json["is_vice_captain"],
        isAbsent: json["is_absent"],
        isInjured: json["is_injured"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        imagePath: json["image_path"],
        starting: json["starting"],
        nextFixture: json["next_fixture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "squad_no": squadNo,
        "player_name": playerName,
        "player_position": playerPosition,
        "player_id": playerId,
        "position_id": positionId,
        "value": value,
        "team_id": teamId,
        "team": team,
        "is_captain": isCaptain,
        "is_vice_captain": isViceCaptain,
        "is_absent": isAbsent,
        "is_injured": isInjured,
        "user_id": userId,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "image_path": imagePath,
        "starting": starting,
        "next_fixture": nextFixture,
      };
}

class Forwards {
  Forwards({
    this.id,
    this.squadNo,
    this.playerName,
    this.playerPosition,
    this.playerId,
    this.positionId,
    this.value,
    this.teamId,
    this.team,
    this.isCaptain,
    this.isViceCaptain,
    this.isAbsent,
    this.isInjured,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.imagePath,
    this.starting,
    this.nextFixture,
  });

  int? id;
  dynamic squadNo;
  String? playerName;
  String? playerPosition;
  int? playerId;
  int? positionId;
  int? value;
  int? teamId;
  String? team;
  int? isCaptain;
  int? isViceCaptain;
  int? isAbsent;
  int? isInjured;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? imagePath;
  int? starting;
  dynamic nextFixture;

  factory Forwards.fromJson(Map<String, dynamic> json) => Forwards(
        id: json["id"],
        squadNo: json["squad_no"],
        playerName: json["player_name"],
        playerPosition: json["player_position"],
        playerId: json["player_id"],
        positionId: json["position_id"],
        value: json["value"],
        teamId: json["team_id"],
        team: json["team"],
        isCaptain: json["is_captain"],
        isViceCaptain: json["is_vice_captain"],
        isAbsent: json["is_absent"],
        isInjured: json["is_injured"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        imagePath: json["image_path"],
        starting: json["starting"],
        nextFixture: json["next_fixture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "squad_no": squadNo,
        "player_name": playerName,
        "player_position": playerPosition,
        "player_id": playerId,
        "position_id": positionId,
        "value": value,
        "team_id": teamId,
        "team": team,
        "is_captain": isCaptain,
        "is_vice_captain": isViceCaptain,
        "is_absent": isAbsent,
        "is_injured": isInjured,
        "user_id": userId,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "image_path": imagePath,
        "starting": starting,
        "next_fixture": nextFixture,
      };
}

class Subs {
  Subs({
    this.id,
    this.squadNo,
    this.playerName,
    this.playerPosition,
    this.playerId,
    this.positionId,
    this.value,
    this.teamId,
    this.team,
    this.isCaptain,
    this.isViceCaptain,
    this.isAbsent,
    this.isInjured,
    this.userId,
    this.createdAt,
    this.updatedAt,
    this.imagePath,
    this.starting,
    this.nextFixture,
  });

  int? id;
  dynamic squadNo;
  String? playerName;
  String? playerPosition;
  int? playerId;
  int? positionId;
  int? value;
  int? teamId;
  String? team;
  int? isCaptain;
  int? isViceCaptain;
  int? isAbsent;
  int? isInjured;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? imagePath;
  int? starting;
  dynamic nextFixture;

  factory Subs.fromJson(Map<String, dynamic> json) => Subs(
        id: json["id"],
        squadNo: json["squad_no"],
        playerName: json["player_name"],
        playerPosition: json["player_position"],
        playerId: json["player_id"],
        positionId: json["position_id"],
        value: json["value"],
        teamId: json["team_id"],
        team: json["team"],
        isCaptain: json["is_captain"],
        isViceCaptain: json["is_vice_captain"],
        isAbsent: json["is_absent"],
        isInjured: json["is_injured"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        imagePath: json["image_path"],
        starting: json["starting"],
        nextFixture: json["next_fixture"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "squad_no": squadNo,
        "player_name": playerName,
        "player_position": playerPosition,
        "player_id": playerId,
        "position_id": positionId,
        "value": value,
        "team_id": teamId,
        "team": team,
        "is_captain": isCaptain,
        "is_vice_captain": isViceCaptain,
        "is_absent": isAbsent,
        "is_injured": isInjured,
        "user_id": userId,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "image_path": imagePath,
        "starting": starting,
        "next_fixture": nextFixture,
      };
}
