import 'package:flutter/material.dart';

class CustomEditingController extends TextEditingController {
  static CustomEditingController getCustomEditingController() {
    return CustomEditingController();
  }
}