class AppKeys{
  static const String userToken = 'token';
  static const String userKey = 'user';
  static const String LoggedInKey = 'loggedIn';
  static const String userSquad = 'squad';
}