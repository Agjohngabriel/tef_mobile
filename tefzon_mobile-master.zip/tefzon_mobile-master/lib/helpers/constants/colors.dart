import 'package:flutter/material.dart';

import '../utils/color_utils/color_from_hex.dart';

class AppColors {
  // static const primary = Color(0xFFE7375B);
  static const secondary = Color(0xFFFFCA0F);
  static const lightBlue = Color(0xFF57BBF8);
  static const blue = Color(0xFF1778F2);
  static const green = Color(0xFF66D093);
  static const backgroundGrey = Color(0xFFF9F9F9);
  static const borderGrey = Color(0xFFEBECEF);
  static const grey = Color(0xFFE6E6E6);

  // #DB4437 - google red
  static const Color primary = Color(0xFF240155);
  static const Color primaryOption2 = Color(0xff03569b);
  static const Color primaryOption3 = Color(0xffd23156);

  static const Color white = Color(0xffffffff);
  static const Color white50 = Color(0x88ffffff);
  static const Color grayDark = Color(0xffeaeaea);
  static const Color gray = Color(0xfff3f3f3);
  static const Color text = Color(0xff000000);
  static const Color text50 = Color(0x88000000);
  static const Color text60 = Color(0xff0D0906);
  static const Color textgrey = Color(0xffA9ACBA);
  static const Color black = Color(0xff001424);
  static const Color black50 = Color(0x88001424);
  static const Color blackLight = Color(0xff011f35);
  static Color facebook = getColorFromHex('#4267B2');

  static List<Color> primaryColorOptions = const [
    primary,
    primaryOption2,
    primaryOption3,
  ];

  static Color getShade(Color color, {bool darker = false, double value = .1}) {
    assert(value >= 0 && value <= 1);

    final hsl = HSLColor.fromColor(color);
    final hslDark = hsl.withLightness(
        (darker ? (hsl.lightness - value) : (hsl.lightness + value))
            .clamp(0.0, 1.0));

    return hslDark.toColor();
  }

  static MaterialColor getMaterialColorFromColor(Color color) {
    Map<int, Color> _colorShades = {
      50: getShade(color, value: 0.5),
      100: getShade(color, value: 0.4),
      200: getShade(color, value: 0.3),
      300: getShade(color, value: 0.2),
      400: getShade(color, value: 0.1),
      500: color, //Primary value
      600: getShade(color, value: 0.1, darker: true),
      700: getShade(color, value: 0.15, darker: true),
      800: getShade(color, value: 0.2, darker: true),
      900: getShade(color, value: 0.25, darker: true),
    };
    return MaterialColor(color.value, _colorShades);
  }
}